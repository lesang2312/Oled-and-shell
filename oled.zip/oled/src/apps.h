// ============================================================
//  Ung dung: ghi chu, doc txt, viec can lam, file, hen gio,
//  tien ich, mat chop, cai dat, mang, thong tin, test nut
// ============================================================
#pragma once
#include "core.h"

// ============ Nen anime (anh 128x64, 1024 byte) ============
uint8_t wall[1024];
bool hasWall = false;
void loadWall() {
  File f = LittleFS.open("/wall.bin", "r");
  if (f) {
    if (f.size() == 1024) { f.read(wall, 1024); hasWall = true; }
    f.close();
  }
}
void saveWall() {
  File f = LittleFS.open("/wall.bin", "w");
  if (f) { f.write(wall, 1024); f.close(); }
}

// ============ 1. Ghi chu ============
#define MAX_NOTES 60
std::vector<String> notes;
int noteIdx = 0, noteScroll = 0;
bool noteDel = false;

void loadNotes() {
  notes.clear();
  File f = LittleFS.open("/notes.txt", "r");
  if (!f) return;
  while (f.available()) {
    String l = f.readStringUntil('\n');
    l.trim();
    if (l.length()) notes.push_back(l);
  }
  f.close();
}
void saveNotes() {
  File f = LittleFS.open("/notes.txt", "w");
  if (!f) return;
  for (size_t i = 0; i < notes.size(); i++) f.println(notes[i]);
  f.close();
}
void addNote(const String &t) {
  notes.push_back(t);
  if (notes.size() > MAX_NOTES) notes.erase(notes.begin());
  saveNotes();
  noteIdx = (int)notes.size() - 1;
  noteScroll = 0;
}
int noteMaxScroll() {
  if (notes.empty()) return 0;
  int lines = ((int)notes[noteIdx].length() + 20) / 21;
  return imax(0, lines - 6);
}
void drawNotes() {
  if (notes.empty()) {
    centerText("Chua co ghi chu", 18, 1);
    centerText("Gui tu may tinh:", 32, 1);
    centerText("Win+E trong shell", 42, 1);
    return;
  }
  oled.setCursor(0, 12 - noteScroll * 8);
  oled.print(notes[noteIdx]);
  oled.fillRect(0, 0, 128, 11, C_OFF);
  oled.setCursor(0, 1);
  oled.printf("Note %d/%d", noteIdx + 1, (int)notes.size());
  if (noteMaxScroll() > 0) { oled.setCursor(92, 1); oled.printf("[%d/%d]", noteScroll + 1, noteMaxScroll() + 1); }
  oled.drawFastHLine(0, 10, 128, C_ON);
  if (noteDel) {
    oled.fillRoundRect(10, 18, 108, 30, 5, C_ON);
    oled.setTextColor(C_OFF);
    oled.setCursor(18, 23); oled.print("Xoa ghi chu nay?");
    oled.setCursor(18, 35); oled.print("Giu A: xoa  khac: huy");
    oled.setTextColor(C_ON);
  }
}
void handleNotes(int e) {
  int n = (int)notes.size();
  if (noteDel) {
    if (e == EV_OK && n) {
      notes.erase(notes.begin() + noteIdx);
      saveNotes();
      if (noteIdx >= (int)notes.size()) noteIdx = (int)notes.size() - 1;
      if (noteIdx < 0) noteIdx = 0;
      noteScroll = 0;
    }
    noteDel = false;
    return;
  }
  if (e == EV_UP) {
    if (noteScroll > 0) noteScroll--;
    else if (noteIdx > 0) { noteIdx--; noteScroll = noteMaxScroll(); }
  } else if (e == EV_DOWN) {
    if (noteScroll < noteMaxScroll()) noteScroll++;
    else if (noteIdx < n - 1) { noteIdx++; noteScroll = 0; }
  } else if (e == EV_OK && n) noteDel = true;
  else if (e == EV_BACK) go(SC_MENU);
}

// ============ 2. Viec can lam (dong bo tu shell tren may tinh) ============
struct Todo { String t; bool d; };
std::vector<Todo> todos;
int todoSel = 0;

void loadTodos() {
  todos.clear();
  File f = LittleFS.open("/todo.txt", "r");
  if (!f) return;
  while (f.available()) {
    String l = f.readStringUntil('\n');
    l.trim();
    if (l.length() < 2) continue;
    Todo t;
    t.d = (l[0] == '1');
    t.t = l.substring(2);
    todos.push_back(t);
  }
  f.close();
}
void saveTodos() {
  File f = LittleFS.open("/todo.txt", "w");
  if (!f) return;
  for (size_t i = 0; i < todos.size(); i++) f.println(String(todos[i].d ? '1' : '0') + "|" + todos[i].t);
  f.close();
}
// arg: "0:Viec 1|1:Viec 2" (1 = da xong)
void setTodos(const String &arg) {
  todos.clear();
  int n = (int)arg.length(), i = 0;
  while (i < n && todos.size() < 30) {
    int e = arg.indexOf('|', i);
    if (e < 0) e = n;
    String tk = arg.substring(i, e);
    i = e + 1;
    if (tk.length() < 3 || tk[1] != ':') continue;
    Todo t;
    t.d = (tk[0] == '1');
    t.t = sanitize(tk.substring(2));
    if (t.t.length()) todos.push_back(t);
  }
  saveTodos();
  todoSel = 0;
}
void drawTodo() {
  int done = 0;
  for (size_t i = 0; i < todos.size(); i++) if (todos[i].d) done++;
  oled.setCursor(0, 1);
  oled.printf("Viec: %d/%d xong", done, (int)todos.size());
  oled.drawFastHLine(0, 10, 128, C_ON);
  if (todos.empty()) {
    centerText("Chua co viec nao", 22, 1);
    centerText("Shell se dong bo", 36, 1);
    return;
  }
  std::vector<String> names;
  for (size_t i = 0; i < todos.size(); i++) names.push_back(String(todos[i].d ? "[x] " : "[ ] ") + todos[i].t);
  drawRows(names, nullptr, todoSel, 13, 5);
}
void handleTodo(int e) {
  int n = (int)todos.size();
  if (e == EV_UP && n) todoSel = (todoSel + n - 1) % n;
  else if (e == EV_DOWN && n) todoSel = (todoSel + 1) % n;
  else if (e == EV_OK && n) { todos[todoSel].d = !todos[todoSel].d; saveTodos(); }
  else if (e == EV_BACK) go(SC_MENU);
}

// ============ 3. Doc file txt ============
#define RD_COLS 21
#define RD_ROWS 6
#define RD_MAX 48000
struct Seg { uint32_t s; uint16_t l; };
String rdPath, rdText;
std::vector<Seg> rdSegs;
int rdTop = 0;
int rdBack = SC_RDLIST;
std::vector<String> txtFiles;
int txtSel = 0;

void rdWrap() {                                       // cat dong theo tu, 21 cot
  rdSegs.clear();
  int n = (int)rdText.length(), i = 0;
  while (i < n) {
    int e = rdText.indexOf('\n', i);
    if (e < 0) e = n;
    int p = i;
    if (e == p) rdSegs.push_back({(uint32_t)p, 0});
    while (e - p > RD_COLS) {
      int sp = rdText.lastIndexOf(' ', p + RD_COLS);
      if (sp > p) { rdSegs.push_back({(uint32_t)p, (uint16_t)(sp - p)}); p = sp + 1; }
      else { rdSegs.push_back({(uint32_t)p, (uint16_t)RD_COLS}); p += RD_COLS; }
    }
    if (e - p > 0) rdSegs.push_back({(uint32_t)p, (uint16_t)(e - p)});
    i = e + 1;
  }
  if (rdSegs.empty()) rdSegs.push_back({0, 0});
}
String rdKey() {
  uint32_t h = 5381;
  for (unsigned i = 0; i < rdPath.length(); i++) h = h * 33 + (uint8_t)rdPath[i];
  return "r" + String((unsigned long)(h % 1000000UL));
}
bool openReader(const String &path) {
  File f = LittleFS.open(path, "r");
  if (!f) return false;
  if (f.size() > RD_MAX) { f.close(); return false; }
  rdText = "";
  rdText.reserve(imin((int)f.size(), RD_MAX) + 1);
  while (f.available() && (int)rdText.length() < RD_MAX) {
    int c = f.read();
    if (c < 0) break;
    if (c == '\r') continue;
    if (c == '\t') c = ' ';
    if (c == '\n' || (c >= 32 && c < 127)) rdText += (char)c;   // ky tu ngoai ASCII bi bo (PC se bo dau truoc khi gui)
  }
  f.close();
  rdPath = path;
  rdWrap();
  String k = rdKey();
  rdTop = clampi((int)prefs.getUInt(k.c_str(), 0), 0, imax(0, (int)rdSegs.size() - RD_ROWS));
  return true;
}
void closeReader() {
  String k = rdKey();
  if (rdTop > 0) prefs.putUInt(k.c_str(), (uint32_t)rdTop);
  else prefs.remove(k.c_str());
}
void refreshTxt() {
  txtFiles.clear();
  File root = LittleFS.open("/");
  File f = root.openNextFile();
  while (f) {
    if (!f.isDirectory()) {
      String n = f.name();
      if (!n.startsWith("/")) n = "/" + n;
      String l = n;
      l.toLowerCase();
      if (l.endsWith(".txt") || l.endsWith(".md") || l.endsWith(".log")) txtFiles.push_back(n);
    }
    f = root.openNextFile();
  }
  if (txtSel >= (int)txtFiles.size()) txtSel = 0;
}
void drawRdList() {
  oled.setCursor(0, 1);
  oled.printf("Doc file (%d)", (int)txtFiles.size());
  oled.drawFastHLine(0, 10, 128, C_ON);
  if (txtFiles.empty()) {
    centerText("Chua co file .txt", 20, 1);
    centerText("Gui tu shell (Win+E)", 34, 1);
    centerText("hoac trang web", 44, 1);
    return;
  }
  std::vector<String> names;
  for (size_t i = 0; i < txtFiles.size(); i++) names.push_back(txtFiles[i].substring(1));
  drawRows(names, nullptr, txtSel, 13, 5);
}
void handleRdList(int e) {
  int n = (int)txtFiles.size();
  if (e == EV_UP && n) txtSel = (txtSel + n - 1) % n;
  else if (e == EV_DOWN && n) txtSel = (txtSel + 1) % n;
  else if (e == EV_OK && n) { rdBack = SC_RDLIST; if (openReader(txtFiles[txtSel])) go(SC_READER); }
  else if (e == EV_BACK) go(SC_MENU);
}
void drawReader() {
  String nm = rdPath.substring(1);
  if (nm.length() > 14) nm = nm.substring(0, 14);
  oled.setCursor(0, 1);
  oled.print(nm);
  int n = (int)rdSegs.size();
  int pct = (n <= RD_ROWS) ? 100 : imin(100, (rdTop + RD_ROWS) * 100 / n);
  char b[8];
  snprintf(b, sizeof(b), "%d%%", pct);
  oled.setCursor(128 - 6 * (int)strlen(b), 1);
  oled.print(b);
  oled.drawFastHLine(0, 10, 128, C_ON);
  for (int k = 0; k < RD_ROWS; k++) {
    int i = rdTop + k;
    if (i >= n) break;
    oled.setCursor(0, 12 + k * 8);
    oled.print(rdText.substring(rdSegs[i].s, rdSegs[i].s + rdSegs[i].l));
  }
  if (n > RD_ROWS) {
    int h = imax(4, 52 * RD_ROWS / n);
    int y = 12 + (52 - h) * rdTop / imax(1, n - RD_ROWS);
    oled.drawFastVLine(127, y, h, C_ON);
  }
}
void handleReader(int e) {
  int mx = imax(0, (int)rdSegs.size() - RD_ROWS);
  if (e == EV_UP) rdTop = imax(0, rdTop - 1);
  else if (e == EV_DOWN) rdTop = imin(mx, rdTop + 1);
  else if (e == EV_OK) rdTop = (rdTop >= mx) ? 0 : imin(mx, rdTop + RD_ROWS);     // giu A: sang trang (het thi ve dau)
  else if (e == EV_BACK) { closeReader(); go(rdBack); }
}

// ============ 4. Quan ly file ============
std::vector<String> fNames;
std::vector<uint32_t> fSizes;
int fileSel = 0;
int fileMode = 0;           // 0 danh sach, 1 hop thao tac, 2 xac nhan xoa

void refreshFiles() {
  fNames.clear(); fSizes.clear();
  File root = LittleFS.open("/");
  File f = root.openNextFile();
  while (f) {
    if (!f.isDirectory()) {
      String n = f.name();
      if (!n.startsWith("/")) n = "/" + n;
      fNames.push_back(n);
      fSizes.push_back(f.size());
    }
    f = root.openNextFile();
  }
  if (fileSel >= (int)fNames.size()) fileSel = 0;
}
String sizeStr(uint32_t s) {
  if (s < 1024) return String((unsigned long)s) + "B";
  return String(s / 1024.0, 1) + "K";
}
void deleteFile(const String &p) {
  LittleFS.remove(p);
  if (p == "/notes.txt") { notes.clear(); noteIdx = 0; }
  if (p == "/wall.bin") hasWall = false;
  if (p == "/todo.txt") { todos.clear(); todoSel = 0; }
}
void drawFiles() {
  oled.setCursor(0, 1);
  oled.printf("Files %uK/%uK", (unsigned)(LittleFS.usedBytes() / 1024), (unsigned)(LittleFS.totalBytes() / 1024));
  oled.drawFastHLine(0, 10, 128, C_ON);
  if (fNames.empty()) { centerText("(trong)", 32, 1); return; }
  std::vector<String> names, vals;
  for (size_t i = 0; i < fNames.size(); i++) { names.push_back(fNames[i].substring(1)); vals.push_back(sizeStr(fSizes[i])); }
  drawRows(names, &vals, fileSel, 13, 5);
  if (fileMode) {
    oled.fillRoundRect(6, 14, 116, 42, 5, C_ON);
    oled.setTextColor(C_OFF);
    oled.setCursor(12, 18); oled.print(fNames[fileSel].substring(1, imin(18, (int)fNames[fileSel].length())));
    if (fileMode == 1) {
      oled.setCursor(12, 30); oled.print("Len : Doc file");
      oled.setCursor(12, 41); oled.print("Xuong: Xoa file");
    } else {
      oled.setCursor(12, 30); oled.print("Xoa that su?");
      oled.setCursor(12, 41); oled.print("Giu A: xoa  khac: huy");
    }
    oled.setTextColor(C_ON);
  }
}
void handleFiles(int e) {
  int n = (int)fNames.size();
  if (fileMode == 0) {
    if (e == EV_UP && n) fileSel = (fileSel + n - 1) % n;
    else if (e == EV_DOWN && n) fileSel = (fileSel + 1) % n;
    else if (e == EV_OK && n) fileMode = 1;
    else if (e == EV_BACK) go(SC_MENU);
  } else if (fileMode == 1) {
    if (e == EV_UP) {
      fileMode = 0;
      rdBack = SC_FILES;
      if (openReader(fNames[fileSel])) go(SC_READER);
      else showPopup("Loi", "Khong mo duoc file");
    } else if (e == EV_DOWN) fileMode = 2;
    else fileMode = 0;
  } else {
    if (e == EV_OK) { deleteFile(fNames[fileSel]); refreshFiles(); }
    fileMode = 0;
  }
}

// ============ 5. Bam gio ============
bool swRun = false;
uint32_t swStart = 0, swAcc = 0, laps[4] = {0, 0, 0, 0};
int lapN = 0;
uint32_t swElapsed() { return swAcc + (swRun ? millis() - swStart : 0); }
void fmtMs(char *b, size_t n, uint32_t ms) {
  uint32_t s = ms / 1000;
  snprintf(b, n, "%02u:%02u", (unsigned)(s / 60 % 100), (unsigned)(s % 60));
}
void drawStopwatch() {
  drawHeader("Bam gio");
  uint32_t el = swElapsed();
  char b[12];
  fmtMs(b, sizeof(b), el);
  oled.setTextSize(3);
  oled.setCursor(4, 14);
  oled.print(b);
  oled.setTextSize(1);
  oled.setCursor(106, 28);
  oled.printf(".%02u", (unsigned)(el % 1000 / 10));
  for (int i = 0; i < lapN; i++) {
    char l[12];
    fmtMs(l, sizeof(l), laps[i]);
    oled.setCursor(i < 2 ? 0 : 64, 42 + (i % 2) * 10);
    oled.printf("#%d %s", lapN - i, l);
  }
  oled.setCursor(0, 56);
  oled.print(swRun ? "Len:vong Xuong:dung" : "Len:xoa Xuong:chay");
}
void handleStopwatch(int e) {
  if (e == EV_UP) {
    if (swRun) {
      for (int i = 3; i > 0; i--) laps[i] = laps[i - 1];
      laps[0] = swElapsed();
      lapN = imin(lapN + 1, 4);
    } else { swAcc = 0; lapN = 0; }
  } else if (e == EV_DOWN) {
    if (swRun) { swAcc += millis() - swStart; swRun = false; }
    else { swStart = millis(); swRun = true; }
  } else if (e == EV_BACK) go(SC_MENU);
}

// ============ 6. Pomodoro ============
bool pmRun = false, pmBreak = false;
uint32_t pmEnd = 0, pmRemain = 25UL * 60000UL;
int pmCount = 0;
uint32_t pmLen() {
  if (!pmBreak) return 25UL * 60000UL;
  return (pmCount > 0 && pmCount % 4 == 0) ? 15UL * 60000UL : 5UL * 60000UL;
}
uint32_t pmLeft() {
  if (!pmRun) return pmRemain;
  int32_t d = (int32_t)(pmEnd - millis());
  return d > 0 ? (uint32_t)d : 0;
}
void drawPomo() {
  drawHeader(pmBreak ? "Pomodoro - NGHI" : "Pomodoro - TAP TRUNG");
  char b[12];
  fmtMs(b, sizeof(b), pmLeft());
  oled.setTextSize(3);
  oled.setCursor(19, 16);
  oled.print(b);
  oled.setTextSize(1);
  int w = (int)(120UL * (pmLen() - pmLeft()) / pmLen());
  oled.drawRect(3, 42, 122, 6, C_ON);
  oled.fillRect(4, 43, w, 4, C_ON);
  oled.setCursor(0, 52);
  oled.printf("Phien: %d  %s", pmCount, pmRun ? "Xuong:dung" : "Xuong:chay");
}
void handlePomo(int e) {
  if (e == EV_DOWN) {
    if (pmRun) { pmRemain = pmLeft(); pmRun = false; }
    else { pmEnd = millis() + pmRemain; pmRun = true; }
  } else if (e == EV_UP) { pmRun = false; pmBreak = false; pmRemain = pmLen(); }
  else if (e == EV_OK) { pmCount = 0; pmRun = false; pmBreak = false; pmRemain = pmLen(); }
  else if (e == EV_BACK) go(SC_MENU);
}

// ============ 7. Dem nguoc ============
int cdMin = 10, cdState = 0;       // 0 chinh, 1 chay, 2 tam dung
uint32_t cdEnd = 0, cdRemain = 600000UL;
String cdLabel;
uint32_t cdLeft() {
  if (cdState != 1) return cdRemain;
  int32_t d = (int32_t)(cdEnd - millis());
  return d > 0 ? (uint32_t)d : 0;
}
void cdStart(int minutes, const String &label) {
  cdMin = clampi(minutes, 1, 600);
  cdLabel = sanitize(label);
  cdRemain = (uint32_t)cdMin * 60000UL;
  cdEnd = millis() + cdRemain;
  cdState = 1;
}
void drawCountdown() {
  drawHeader(cdLabel.length() ? "Dem nguoc: " + cdLabel.substring(0, 9) : String("Dem nguoc"));
  char b[12];
  fmtMs(b, sizeof(b), cdState == 0 ? (uint32_t)cdMin * 60000UL : cdLeft());
  oled.setTextSize(3);
  oled.setCursor(19, 16);
  oled.print(b);
  oled.setTextSize(1);
  oled.setCursor(0, 46);
  if (cdState == 0) { oled.print("Len/Xuong: chinh phut"); oled.setCursor(0, 56); oled.print("Giu A: bat dau"); }
  else if (cdState == 1) { oled.print("Dang dem..."); oled.setCursor(0, 56); oled.print("Xuong:dung  Len:huy"); }
  else { oled.print("Tam dung"); oled.setCursor(0, 56); oled.print("Xuong:tiep  Len:huy"); }
}
void handleCountdown(int e) {
  if (cdState == 0) {
    int step = cdMin < 10 ? 1 : (cdMin < 60 ? 5 : 15);
    if (e == EV_UP) cdMin = imin(600, cdMin + step);
    else if (e == EV_DOWN) cdMin = imax(1, cdMin - step);
    else if (e == EV_OK) cdStart(cdMin, cdLabel);
    else if (e == EV_BACK) go(SC_MENU);
  } else if (cdState == 1) {
    if (e == EV_DOWN) { cdRemain = cdLeft(); cdState = 2; }
    else if (e == EV_UP) cdState = 0;
    else if (e == EV_BACK) go(SC_MENU);
  } else {
    if (e == EV_DOWN || e == EV_OK) { cdEnd = millis() + cdRemain; cdState = 1; }
    else if (e == EV_UP) cdState = 0;
    else if (e == EV_BACK) go(SC_MENU);
  }
}

// ============ 8. Bao thuc ============
int alField = -1;                  // -1 xem, 0 gio, 1 phut, 2 bat/tat
int lastAlarmKey = -1;
void drawAlarm() {
  drawHeader("Bao thuc");
  char b[8];
  snprintf(b, sizeof(b), "%02d:%02d", alH, alM);
  oled.setTextSize(3);
  oled.setCursor(19, 16);
  oled.print(b);
  oled.setTextSize(1);
  if (alField == 0) oled.drawFastHLine(19, 40, 34, C_ON);
  if (alField == 1) oled.drawFastHLine(73, 40, 34, C_ON);
  oled.setCursor(0, 46);
  oled.printf("Trang thai: %s%s", alOn ? "BAT" : "TAT", alField == 2 ? " <" : "");
  oled.setCursor(0, 56);
  oled.print(alField < 0 ? "Giu A: sua  Len: bat/tat" : "Len/Xuong: doi  Giu A: tiep");
}
void handleAlarm(int e) {
  if (alField < 0) {
    if (e == EV_OK) alField = 0;
    else if (e == EV_UP || e == EV_DOWN) { alOn = !alOn; saveAlarm(); }
    else if (e == EV_BACK) go(SC_MENU);
    return;
  }
  if (e == EV_UP || e == EV_DOWN) {
    int d = (e == EV_UP) ? 1 : -1;
    if (alField == 0) alH = (uint8_t)((alH + 24 + d) % 24);
    else if (alField == 1) alM = (uint8_t)((alM + 60 + d * 5) % 60);
    else alOn = !alOn;
  } else if (e == EV_OK) {
    alField++;
    if (alField > 2) { alField = -1; saveAlarm(); }
  } else if (e == EV_BACK) { alField = -1; saveAlarm(); }
}

// Chay moi vong lap: het gio, bao thuc, tu luu gio
void tickTimers() {
  uint32_t now = millis();
  if (pmRun && (int32_t)(now - pmEnd) >= 0) {
    pmRun = false;
    if (!pmBreak) { pmCount++; pmBreak = true; } else pmBreak = false;
    pmRemain = pmLen();
    startRing(pmBreak ? "Nghi ngoi thoi!" : "Vao tap trung");
  }
  if (cdState == 1 && (int32_t)(now - cdEnd) >= 0) {
    cdState = 0;
    cdRemain = (uint32_t)cdMin * 60000UL;
    startRing(cdLabel.length() ? cdLabel : String("HET GIO"));
  }
  static uint32_t lastChk = 0;
  if (now - lastChk >= 500) {
    lastChk = now;
    if (alOn && haveTime()) {
      struct tm t;
      getTm(t);
      int key = t.tm_yday * 1440 + t.tm_hour * 60 + t.tm_min;
      if (t.tm_hour == alH && t.tm_min == alM && key != lastAlarmKey) {
        lastAlarmKey = key;
        char b[24];
        snprintf(b, sizeof(b), "BAO THUC %02d:%02d", alH, alM);
        startRing(b);
      }
    }
    if (haveTime() && now - lastTimeSave > 600000UL) {      // luu gio moi 10 phut de khoi dong lai van gan dung
      prefs.putUInt("ep", (uint32_t)time(nullptr));
      lastTimeSave = now;
    }
  }
  if (ringing) {
    if (PIN_BUZZ >= 0) digitalWrite(PIN_BUZZ, ((now - ringStart) / 250) % 2 == 0 ? HIGH : LOW);
    if (now - ringStart > 60000UL) stopRing();
  }
}

// ============ 9. Tien ich: xuc xac, dong xu, bi 8, do phan xa ============
int diceType = 0;                  // 0 d6, 1 2d6, 2 d20, 3 d100
int dv[2] = {1, 1};
uint32_t diceEnd = 0, diceFlip = 0;
const char *DICE_N[4] = {"1 xuc xac", "2 xuc xac", "d20", "d100"};
int diceMax() { return diceType <= 1 ? 6 : (diceType == 2 ? 20 : 100); }
void diceRoll() { diceEnd = millis() + 800; }
void drawDie(int x, int y, int s, int v) {
  oled.drawRoundRect(x, y, s, s, 5, C_ON);
  if (v < 1 || v > 6) return;
  // bit: 0 tren-trai, 1 tren-phai, 2 giua-trai, 3 tam, 4 giua-phai, 5 duoi-trai, 6 duoi-phai
  static const uint8_t mask[7] = {0, 8, 65, 73, 99, 107, 119};
  static const uint8_t colOf[7] = {0, 2, 0, 1, 2, 0, 2};
  static const uint8_t rowOf[7] = {0, 0, 1, 1, 1, 2, 2};
  for (int bit = 0; bit < 7; bit++) {
    if (!(mask[v] & (1 << bit))) continue;
    oled.fillCircle(x + s / 4 + colOf[bit] * (s / 4), y + s / 4 + rowOf[bit] * (s / 4), imax(1, s / 10), C_ON);
  }
}
void drawDice() {
  drawHeader(String("Xuc xac: ") + DICE_N[diceType]);
  bool rolling = millis() < diceEnd;
  if (rolling && millis() - diceFlip > 70) {
    diceFlip = millis();
    dv[0] = random(1, diceMax() + 1);
    dv[1] = random(1, diceMax() + 1);
  }
  if (diceType == 0) drawDie(44, 14, 40, dv[0]);
  else if (diceType == 1) { drawDie(14, 16, 36, dv[0]); drawDie(78, 16, 36, dv[1]); }
  else centerText(String(dv[0]), 20, 4);
  if (diceType == 1) centerText(String("Tong: ") + String(dv[0] + dv[1]), 54, 1);
  else { oled.setCursor(0, 56); oled.print("Xuong:tung  Len:doi loai"); }
}
void handleDice(int e) {
  if (e == EV_DOWN || e == EV_OK) diceRoll();
  else if (e == EV_UP) { diceType = (diceType + 1) % 4; dv[0] = dv[1] = 1; }
  else if (e == EV_BACK) go(SC_MENU);
}

int coinRes = 0;
uint32_t coinStart = 0, coinEnd = 0;
void drawCoin() {
  drawHeader("Tung dong xu");
  uint32_t now = millis();
  if (now < coinEnd) {
    float w = fabsf(cosf((now - coinStart) / 90.0f)) * 26.0f + 2;
    oled.fillRoundRect(64 - (int)w, 16, (int)(w * 2), 30, 12, C_ON);
    centerText("...", 52, 1);
  } else {
    oled.drawCircle(64, 31, 15, C_ON);
    centerText(coinRes ? "SAP" : "NGUA", 50, 1);
    centerText(coinRes ? "S" : "N", 24, 2);
  }
}
void handleCoin(int e) {
  if (e == EV_DOWN || e == EV_OK || e == EV_UP) { coinStart = millis(); coinEnd = coinStart + 900; coinRes = random(2); }
  else if (e == EV_BACK) go(SC_MENU);
}

const char *EIGHT_A[10] = {"Chac chan roi", "Chua chac dau", "Co ve on day", "Hoi lai sau nhe", "Dung mong doi",
                           "Rat co the", "Khong dau", "Hay thu xem", "Tap trung roi hoi", "Chac la khong"};
int eightRes = -1;
void drawEight() {
  drawHeader("Qua cau bi 8");
  oled.fillCircle(64, 30, 17, C_ON);
  oled.setTextColor(C_OFF);
  centerText(eightRes < 0 ? "8" : "?", 22, 2);
  oled.setTextColor(C_ON);
  centerText(eightRes < 0 ? "Xuong: hoi di" : String(EIGHT_A[eightRes]), 52, 1);
}
void handleEight(int e) {
  if (e == EV_DOWN || e == EV_OK || e == EV_UP) eightRes = random(10);
  else if (e == EV_BACK) go(SC_MENU);
}

int reState = 0;                    // 0 cho bat dau, 1 cho, 2 bam ngay, 3 ket qua, 4 bam som
uint32_t reAt = 0, reMs = 0, reBest = 0;
void drawReact() {
  uint32_t now = millis();
  if (reState == 1 && now >= reAt) { reState = 2; reAt = now; }
  if (reState == 2) {
    oled.fillRect(0, 0, 128, 64, C_ON);
    oled.setTextColor(C_OFF);
    centerText("BAM!", 20, 3);
    oled.setTextColor(C_ON);
    return;
  }
  drawHeader("Do phan xa");
  if (reState == 0) { centerText("Cho man hinh doi mau", 22, 1); centerText("roi bam that nhanh", 32, 1); centerText("Bam de bat dau", 50, 1); }
  else if (reState == 1) centerText("Cho...", 28, 2);
  else if (reState == 3) { centerText(String((unsigned long)reMs) + " ms", 20, 2); centerText(String("Tot nhat: ") + String((unsigned long)reBest) + " ms", 44, 1); centerText("Bam de choi lai", 54, 1); }
  else { centerText("Bam som qua!", 24, 1); centerText("Bam de thu lai", 44, 1); }
}
void handleReact(int e) {
  if (e == EV_BACK) { go(SC_MENU); return; }
  if (reState == 1) reState = 4;
  else if (reState == 2) {
    reMs = millis() - reAt;
    if (reBest == 0 || reMs < reBest) { reBest = reMs; prefs.putUInt("reac", reBest); }
    reState = 3;
  } else { reState = 1; reAt = millis() + random(1500, 4500); }
}

// ============ 10. Mat chop ============
uint32_t eyeNext = 0, blinkAt = 0;
float eyeX = 0, eyeY = 0;
int eyeTx = 0, eyeTy = 0;
uint8_t eyeMood = 0;
void drawEyes() {
  uint32_t now = millis();
  if (now > eyeNext) {
    eyeTx = random(-8, 9); eyeTy = random(-5, 6);
    eyeNext = now + random(800, 2500);
    if (random(3) == 0) blinkAt = now;
  }
  eyeX += (eyeTx - eyeX) * 0.3f;
  eyeY += (eyeTy - eyeY) * 0.3f;
  uint32_t bl = now - blinkAt;
  int h = 34;
  if (bl < 160) {
    h = (bl < 80) ? 34 - (int)(bl * 34 / 80) : 34 - (int)((160 - bl) * 34 / 80);
    if (h < 3) h = 3;
  }
  for (int i = 0; i < 2; i++) {
    int cx = 38 + i * 52;
    if (eyeMood == 1) {
      for (int k = -1; k <= 1; k++) {
        oled.drawLine(cx - 14, 38 + k, cx, 24 + k, C_ON);
        oled.drawLine(cx, 24 + k, cx + 14, 38 + k, C_ON);
      }
    } else if (eyeMood == 2) {
      oled.fillRect(cx - 14, 34, 28, 4, C_ON);
    } else {
      oled.fillRoundRect(cx - 14, 32 - h / 2, 28, h, 8, C_ON);
      if (h > 20) oled.fillCircle(cx + (int)(eyeX * 0.8f), 32 + (int)eyeY, 6, C_OFF);
    }
  }
  if (eyeMood == 2) { oled.setCursor(106, 8); oled.print("z"); oled.setCursor(114, 2); oled.print("Z"); }
  if (eyeMood == 1) { oled.setCursor(56, 48); oled.print("^_^"); }
}
void handleEyes(int e) {
  if (e == EV_UP) eyeMood = (eyeMood + 1) % 3;
  else if (e == EV_DOWN) blinkAt = millis();
  else if (e == EV_BACK) go(SC_MENU);
}

// ============ 11. Thoi tiet / May tinh ============
const char *wxText(int c) {
  if (c == 0) return "Troi quang";
  if (c <= 2) return "It may";
  if (c == 3) return "Nhieu may";
  if (c == 45 || c == 48) return "Suong mu";
  if (c >= 51 && c <= 57) return "Mua phun";
  if (c >= 61 && c <= 65) return "Mua nhe";
  if (c >= 66 && c <= 67) return "Mua dong";
  if ((c >= 71 && c <= 77) || (c >= 85 && c <= 86)) return "Tuyet";
  if (c >= 80 && c <= 82) return "Mua rao";
  if (c >= 95) return "Dong bao";
  return "Thoi tiet";
}

// Icon thoi tiet ve truc tiep tren OLED don sac, khong can bitmap ton flash.
void wxDrawSun(int cx, int cy, int r) {
  oled.drawCircle(cx, cy, r, C_ON);
  for (int a = 0; a < 8; a++) {
    float ang = a * PI / 4.0f;
    int x1 = cx + (int)(cosf(ang) * (r + 3));
    int y1 = cy + (int)(sinf(ang) * (r + 3));
    int x2 = cx + (int)(cosf(ang) * (r + 7));
    int y2 = cy + (int)(sinf(ang) * (r + 7));
    oled.drawLine(x1, y1, x2, y2, C_ON);
  }
}
void wxDrawCloud(int x, int y) {
  oled.fillCircle(x + 9, y + 12, 6, C_ON);
  oled.fillCircle(x + 19, y + 8, 8, C_ON);
  oled.fillCircle(x + 29, y + 13, 5, C_ON);
  oled.fillRoundRect(x + 5, y + 11, 30, 9, 4, C_ON);
}
void wxDrawIcon(int code, bool day, int x, int y) {
  bool clear = (code == 0);
  bool partly = (code == 1 || code == 2);
  bool fog = (code == 45 || code == 48);
  bool snow = (code >= 71 && code <= 77) || (code >= 85 && code <= 86);
  bool storm = (code >= 95);
  bool rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82);

  if (clear && day) {
    wxDrawSun(x + 21, y + 17, 9);
    return;
  }
  if (clear && !day) {
    oled.fillCircle(x + 22, y + 17, 12, C_ON);
    oled.fillCircle(x + 28, y + 12, 11, C_OFF);
    oled.drawCircle(x + 22, y + 17, 12, C_ON);
    return;
  }
  if (partly) wxDrawSun(x + 13, y + 10, 7);
  wxDrawCloud(x + (partly ? 3 : 1), y + (partly ? 4 : 5));
  if (fog) {
    oled.drawFastHLine(x + 7, y + 25, 29, C_ON);
    oled.drawFastHLine(x + 12, y + 29, 21, C_ON);
  } else if (storm) {
    oled.fillTriangle(x + 22, y + 21, x + 17, y + 30, x + 24, y + 28, C_ON);
  } else if (snow) {
    for (int i = 0; i < 3; i++) {
      int cx = x + 11 + i * 12;
      int cy = y + 22 + (i % 2) * 2;
      oled.drawLine(cx - 3, cy, cx + 3, cy, C_ON);
      oled.drawLine(cx, cy - 3, cx, cy + 3, C_ON);
      oled.drawLine(cx - 2, cy - 2, cx + 2, cy + 2, C_ON);
    }
  } else if (rain) {
    oled.drawLine(x + 12, y + 25, x + 9, y + 30, C_ON);
    oled.drawLine(x + 23, y + 25, x + 20, y + 30, C_ON);
    oled.drawLine(x + 34, y + 25, x + 31, y + 30, C_ON);
  }
}
void drawWeather() {
  drawHeader("THOI TIET");
  oled.setCursor(104, 1);
  if (wxBusy || wxReq) oled.print("UPD");
  else if (wx.ok && millis() - wx.at < 1800000UL) oled.print("LIVE");
  else oled.print("OLD");

  if (wfState != WF_STA && !wx.ok) {
    centerText("Can WiFi Internet", 25, 1);
    centerText("Cai vi tri: GEO", 39, 1);
    centerText("Giu A de tai lai", 53, 1);
    return;
  }
  if (!wx.ok) {
    centerText((wxBusy || wxReq) ? "Dang lay du lieu..." : "Chua co du lieu", 25, 1);
    if (wxFailed) centerText("Tai that bai - thu lai", 39, 1);
    centerText("Giu A de tai lai", 53, 1);
    return;
  }

  // Nhiet do lon ben trai, icon dieu kien thoi tiet ben phai.
  oled.setTextSize(3);
  oled.setCursor(2, 14);
  oled.printf("%.0f", wx.t);
  int degX = oled.getCursorX();
  oled.setTextSize(1);
  oled.drawCircle(degX + 3, 18, 2, C_ON);
  oled.setCursor(degX + 8, 15);
  oled.print("C");
  wxDrawIcon(wx.code, wx.isDay, 86, 12);

  oled.setCursor(2, 43);
  oled.print(wxText(wx.code));
  oled.setCursor(76, 43);
  oled.printf("Cam %.0fC", wx.feels);
  oled.drawFastHLine(0, 52, 128, C_ON);
  oled.setCursor(2, 55);
  oled.printf("AM %d%%", clampi(wx.hum, 0, 100));
  oled.setCursor(63, 55);
  oled.printf("GIO %dkm/h", clampi((int)wx.wind, 0, 99));
}
void handleWeather(int e) {
  if (e == EV_OK || e == EV_DOWN) { wxFailed = false; wxReq = true; }
  else if (e == EV_BACK) go(SC_MENU);
}
void drawBar(int y, const char *label, int pct) {
  oled.setCursor(0, y);
  oled.print(label);
  oled.drawRect(28, y - 1, 84, 9, C_ON);
  oled.fillRect(29, y, (int)(82L * clampi(pct, 0, 100) / 100), 7, C_ON);
  oled.setCursor(114, y);
  oled.printf("%d", pct);
}
void drawPcMon() {
  drawHeader("May tinh (PC)");
  if (pcs.at == 0 || millis() - pcs.at > 30000UL) {
    centerText("Chua co du lieu", 24, 1);
    centerText("Bat 'Tu dong bo' trong", 38, 1);
    centerText("bang Buddy tren shell", 48, 1);
    return;
  }
  drawBar(15, "CPU", pcs.cpu);
  drawBar(27, "RAM", pcs.mem);
  oled.setCursor(0, 42);
  if (pcs.pState == 0) oled.print("Pomodoro: dung");
  else { oled.printf("%s %02d:%02d", pcs.pState == 1 ? "Tap trung" : "Nghi", pcs.pRem / 60, pcs.pRem % 60); }
  oled.setCursor(0, 54);
  oled.printf("Hom nay: %d phien", pcs.pToday);
}
void handlePcMon(int e) { if (e == EV_BACK) go(SC_MENU); }

// ============ 12. Mang & ket noi ============
int netSel = 0;
const char *wfName() {
  switch (wfState) { case WF_OFF: return "Tat"; case WF_CONNECTING: return "Dang noi"; case WF_STA: return "Online"; case WF_AP: return "AP"; }
  return "?";
}
void drawNet() {
  drawHeader("Mang & ket noi");
  std::vector<String> names, vals;
  names.push_back("WiFi");          vals.push_back(S.wifiOn ? "Bat" : "Tat");
  names.push_back("Trang thai");    vals.push_back(wfName());
  names.push_back("IP");            vals.push_back(wfIp().length() ? wfIp() : String("-"));
  names.push_back("Dong bo NTP");   vals.push_back(">");
  names.push_back("Tai thoi tiet"); vals.push_back(">");
  names.push_back("Bluetooth");     vals.push_back(S.btOn ? "Bat" : "Tat");
  names.push_back("Trang web");     vals.push_back(">");
  drawRows(names, &vals, netSel, 13, 5);
}
void handleNet(int e) {
  const int n = 7;
  if (e == EV_UP) netSel = (netSel + n - 1) % n;
  else if (e == EV_DOWN) netSel = (netSel + 1) % n;
  else if (e == EV_BACK) go(SC_MENU);
  else if (e == EV_OK) {
    switch (netSel) {
      case 0: S.wifiOn = !S.wifiOn; saveSettings(); wifiRestart(); break;
      case 1: wifiRestart(); break;
      case 2: showPopup("Dia chi IP", wfIp().length() ? wfIp() : String("Chua ket noi")); break;
      case 3: ntpSync(); showPopup("NTP", "Dang dong bo gio..."); break;
      case 4: wxReq = true; showPopup("Thoi tiet", "Dang tai..."); break;
      case 5: S.btOn = !S.btOn; saveSettings(); showPopup("Bluetooth", "Khoi dong lai de ap dung"); break;
      case 6:
        if (wfIp().length()) showPopup("Trang web", "http://" + wfIp() + "  hoac buddy.local");
        else showPopup("Trang web", "Chua co mang");
        break;
    }
  }
}

// ============ 13. Cai dat ============
const int SET_N = 12;
int setSel = 0;
bool clearConfirm = false;
void drawSettings() {
  std::vector<String> names, vals;
  names.push_back("Do sang");       vals.push_back(String(S.bright + 1) + "/5");
  names.push_back("Dao mau");       vals.push_back(S.invert ? "Bat" : "Tat");
  names.push_back("Xoay man 180");  vals.push_back(S.flip ? "Bat" : "Tat");
  names.push_back("Dong ho 24h");   vals.push_back(S.h24 ? "Bat" : "Tat");
  names.push_back("Hinh nen");      vals.push_back(S.wall ? "Bat" : "Tat");
  names.push_back("Tu tat man");    vals.push_back(SLEEP_TXT[S.sleepIdx]);
  names.push_back("Hien giay");     vals.push_back(S.secs ? "Bat" : "Tat");
  names.push_back("Mui gio");       vals.push_back(tzStr());
  names.push_back("WiFi");          vals.push_back(S.wifiOn ? "Bat" : "Tat");
  names.push_back("Bluetooth");     vals.push_back(S.btOn ? "Bat" : "Tat");
  names.push_back("Xoa ghi chu");   vals.push_back(clearConfirm ? "Chac chua?" : ">");
  names.push_back("Khoi dong lai"); vals.push_back(">");
  drawRows(names, &vals, setSel, 2, 6);
}
void handleSettings(int e) {
  if (e == EV_UP) { setSel = (setSel + SET_N - 1) % SET_N; clearConfirm = false; }
  else if (e == EV_DOWN) { setSel = (setSel + 1) % SET_N; clearConfirm = false; }
  else if (e == EV_BACK) { saveSettings(); go(SC_MENU); }
  else if (e == EV_OK) {
    switch (setSel) {
      case 0: S.bright = (S.bright + 1) % 5; applyDisplay(); break;
      case 1: S.invert = !S.invert; applyDisplay(); break;
      case 2: S.flip = !S.flip; applyDisplay(); break;
      case 3: S.h24 = !S.h24; break;
      case 4: S.wall = !S.wall; break;
      case 5: S.sleepIdx = (S.sleepIdx + 1) % 4; break;
      case 6: S.secs = !S.secs; break;
      case 7: S.tz += 3600; if (S.tz > 14 * 3600) S.tz = -12 * 3600; break;
      case 8: S.wifiOn = !S.wifiOn; saveSettings(); wifiRestart(); break;
      case 9: S.btOn = !S.btOn; showPopup("Bluetooth", "Khoi dong lai de ap dung"); break;
      case 10:
        if (clearConfirm) { notes.clear(); saveNotes(); noteIdx = 0; clearConfirm = false; showPopup("Ghi chu", "Da xoa tat ca ghi chu"); }
        else clearConfirm = true;
        break;
      case 11: saveSettings(); delay(100); ESP.restart(); break;
    }
  }
}

// ============ 14. Thong tin ============
void drawInfo() {
  uint32_t up = millis() / 1000;
  oled.setCursor(0, 2);  oled.printf("Buddy v%s  %dMHz", FW_VER, (int)getCpuFrequencyMhz());
  oled.setCursor(0, 12); oled.printf("Uptime %uh %02um %02us", (unsigned)(up / 3600), (unsigned)(up / 60 % 60), (unsigned)(up % 60));
  oled.setCursor(0, 22); oled.printf("RAM %uKB Flash %u/%uK", (unsigned)(ESP.getFreeHeap() / 1024), (unsigned)(LittleFS.usedBytes() / 1024), (unsigned)(LittleFS.totalBytes() / 1024));
  oled.setCursor(0, 32); oled.printf("Gio: %s %s", timeSrcTxt(), tzStr().c_str());
  oled.setCursor(0, 42); oled.printf("WiFi: %s", wfIp().length() ? wfIp().c_str() : wfName());
  oled.setCursor(0, 52); oled.printf("Note %d Viec %d Nen %s", (int)notes.size(), (int)todos.size(), hasWall ? "co" : "khong");
}
void handleInfo(int e) { if (e != EV_NONE) go(SC_MENU); }

// ============ 15. Test nut bam ============
String lastEvTxt = "-";
void drawBtnTest() {
  drawHeader("Test nut bam");
  const char *nm[2] = {"A (D4)", "B (D18)"};
  for (int i = 0; i < 2; i++) {
    int y = 14 + i * 14;
    bool on = btns[i].raw;
    if (on) oled.fillRect(0, y - 2, 128, 13, C_ON);
    oled.setTextColor(on ? C_OFF : C_ON);
    oled.setCursor(3, y);
    oled.printf("%s %s", nm[i], on ? "BAM" : "nha");
    oled.setCursor(80, y);
    oled.printf("pin=%d #%u", digitalRead(btns[i].pin), (unsigned)btns[i].count);
    oled.setTextColor(C_ON);
  }
  oled.setCursor(0, 44);
  oled.printf("Su kien: %s", lastEvTxt.c_str());
  oled.setCursor(0, 54);
  oled.print("Giu B: thoat");
}
void handleBtnTest(int e) {
  const char *nm[] = {"", "A ngan (LEN)", "B ngan (XUONG)", "A giu (CHON)", "B giu (LAI)"};
  lastEvTxt = nm[e];
  if (e == EV_BACK) go(SC_MENU);
}
