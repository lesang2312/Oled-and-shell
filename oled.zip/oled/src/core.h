// ============================================================
//  Cot loi: cai dat, gio, nut bam, popup, trang thai dung chung
// ============================================================
#pragma once
#include "config.h"

Adafruit_SSD1306 oled(128, 64, &Wire, -1);
Preferences prefs;

// ---------- cai dat ----------
struct Settings {
  uint8_t bright = 2;      // 0..4
  bool invert = false;
  bool flip = false;       // xoay man 180 do
  bool h24 = true;
  bool wall = true;
  uint8_t sleepIdx = 0;    // 0=tat, 1=30s, 2=60s, 3=120s
  bool secs = true;
  int32_t tz = 25200;      // giay lech so voi UTC (mac dinh UTC+7)
  bool wifiOn = true;
  bool btOn = false;       // Bluetooth (doi co hieu luc sau khi khoi dong lai)
} S;
const uint8_t BRIGHT_LV[5] = {1, 40, 100, 180, 255};
const uint16_t SLEEP_LV[4] = {0, 30, 60, 120};
const char *SLEEP_TXT[4] = {"Tat", "30s", "60s", "2p"};

String wifiSsid, wifiPass;
float geoLat = 10.8231f, geoLon = 106.6297f;   // mac dinh TP.HCM, doi bang lenh GEO
uint8_t alH = 7, alM = 0;
bool alOn = false;
uint32_t hiScore[5] = {0, 0, 0, 0, 0};

// ---------- trang thai chung ----------
int screen = SC_HOME;
int homeMode = 0;          // 0 nen anime, 1 so lon, 2 kim, 3 bang tong hop
bool dirty = true;
bool sleeping = false;
uint32_t lastActive = 0, lastRender = 0;

// ---------- mang / thoi tiet / may tinh ----------
enum { WF_OFF, WF_CONNECTING, WF_STA, WF_AP };
uint8_t wfState = WF_OFF;
struct Weather {
  bool ok;
  float t;
  float feels;
  int hum;
  float wind;
  int code;
  bool isDay;
  uint32_t at;
};
Weather wx = {false, 0, 0, 0, 0, 0, true, 0};
volatile bool wxReq = false;
volatile bool wxBusy = false;
volatile bool wxFailed = false;
struct PcStat { uint32_t at; int cpu; int mem; int pState; int pRem; int pToday; };
PcStat pcs = {0, 0, 0, 0, 0, 0};     // du lieu do shell tren may tinh day sang (pState: 0 dung, 1 tap trung, 2 nghi)

// ---------- tien ich chuoi ----------
String sanitize(const String &s) {                       // chi giu ky tu in duoc (ASCII)
  String o;
  for (unsigned i = 0; i < s.length(); i++) {
    uint8_t u = (uint8_t)s[i];
    if (u >= 32 && u < 127) o += (char)u;
    else if (u == '\t') o += ' ';
  }
  return o;
}
String cleanPath(String n) {                              // ten file an toan -> "/ten.txt" ("" neu khong hop le)
  n.trim();
  int sl = n.lastIndexOf('/');
  if (sl >= 0) n = n.substring(sl + 1);
  String o;
  for (unsigned i = 0; i < n.length() && o.length() < 28; i++) {
    char c = n[i];
    if (isalnum((unsigned char)c) || c == '.' || c == '-' || c == '_') o += c;
    else if (c == ' ') o += '_';
  }
  if (o.length() == 0 || o == "." || o == "..") return "";
  return "/" + o;
}
int hexVal(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  c |= 0x20;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}
String tzStr() {
  char b[20];
  int m = abs(S.tz) / 60 % 60;
  if (m) snprintf(b, sizeof(b), "UTC%c%d:%02d", S.tz < 0 ? '-' : '+', abs(S.tz) / 3600, m);
  else snprintf(b, sizeof(b), "UTC%+d", S.tz / 3600);
  return String(b);
}

// ---------- luu / doc cai dat ----------
void loadSettings() {
  S.bright = prefs.getUChar("br", 2);
  S.invert = prefs.getBool("inv", false);
  S.flip = prefs.getBool("flip", false);
  S.h24 = prefs.getBool("h24", true);
  S.wall = prefs.getBool("wall", true);
  S.sleepIdx = prefs.getUChar("slp", 0);
  S.secs = prefs.getBool("sec", true);
  S.tz = prefs.getInt("tz", 25200);
  S.wifiOn = prefs.getBool("wifi", true);
  S.btOn = prefs.getBool("bt", false);
  homeMode = prefs.getUChar("home", 0);
  wifiSsid = prefs.getString("ssid", "");
  wifiPass = prefs.getString("pass", "");
  geoLat = prefs.getFloat("lat", 10.8231f);
  geoLon = prefs.getFloat("lon", 106.6297f);
  alH = prefs.getUChar("alh", 7);
  alM = prefs.getUChar("alm", 0);
  alOn = prefs.getBool("alon", false);
  for (int i = 0; i < 5; i++) { char k[6]; snprintf(k, sizeof(k), "hi%d", i); hiScore[i] = prefs.getUInt(k, 0); }
  if (S.bright > 4) S.bright = 2;
  if (S.sleepIdx > 3) S.sleepIdx = 0;
  if (homeMode > 3) homeMode = 0;
}
void saveSettings() {
  prefs.putUChar("br", S.bright);
  prefs.putBool("inv", S.invert);
  prefs.putBool("flip", S.flip);
  prefs.putBool("h24", S.h24);
  prefs.putBool("wall", S.wall);
  prefs.putUChar("slp", S.sleepIdx);
  prefs.putBool("sec", S.secs);
  prefs.putInt("tz", S.tz);
  prefs.putBool("wifi", S.wifiOn);
  prefs.putBool("bt", S.btOn);
  prefs.putUChar("home", homeMode);
}
void saveAlarm() {
  prefs.putUChar("alh", alH);
  prefs.putUChar("alm", alM);
  prefs.putBool("alon", alOn);
}

// ---------- gio ----------
// Nguon gio: 0 chua co, 1 uoc luong (khoi phuc tu flash, co the lech), 2 may tinh (USB/mang), 3 NTP
uint8_t timeSrc = 0;
volatile bool ntpFlag = false;
uint32_t lastTimeSave = 0;

void applyTime(uint32_t ep, uint8_t src, bool save) {
  struct timeval tv;
  tv.tv_sec = ep;
  tv.tv_usec = 0;
  settimeofday(&tv, nullptr);
  timeSrc = src;
  if (save) { prefs.putUInt("ep", ep); lastTimeSave = millis(); }
}
bool haveTime() { return timeSrc > 0 && time(nullptr) > 1700000000; }
void getTm(struct tm &t) {
  time_t now = time(nullptr) + S.tz;
  gmtime_r(&now, &t);
}
void fmtTime(char *buf, size_t n, const struct tm &t, bool secs) {
  int h = t.tm_hour;
  if (!S.h24) { h %= 12; if (h == 0) h = 12; }
  if (secs) snprintf(buf, n, "%02d:%02d:%02d", h, t.tm_min, t.tm_sec);
  else snprintf(buf, n, "%02d:%02d", h, t.tm_min);
}
const char *DAYS[7] = {"CN", "T2", "T3", "T4", "T5", "T6", "T7"};
const char *timeSrcTxt() {
  switch (timeSrc) { case 1: return "uoc luong"; case 2: return "may tinh"; case 3: return "NTP"; }
  return "chua co";
}

// ---------- man hinh sang / tat, popup ----------
String popTitle, popText;
uint32_t popUntil = 0;

void wakeScreen() {
  if (sleeping) { oled.ssd1306_command(SSD1306_DISPLAYON); sleeping = false; }
  lastActive = millis();
  dirty = true;
}
void showPopup(const String &title, const String &text) {
  popTitle = sanitize(title);
  popText = sanitize(text);
  popUntil = millis() + 3500;
  wakeScreen();
}
void applyDisplay() {
  oled.ssd1306_command(SSD1306_SETCONTRAST);
  oled.ssd1306_command(BRIGHT_LV[S.bright]);
  oled.invertDisplay(S.invert);
  oled.setRotation(S.flip ? 2 : 0);
}

// ---------- chuong bao (bao thuc, het gio) ----------
bool ringing = false;
String ringTitle;
uint32_t ringStart = 0;
void startRing(const String &title) {
  ringing = true;
  ringTitle = sanitize(title);
  ringStart = millis();
  wakeScreen();
}
void stopRing() {
  ringing = false;
  if (PIN_BUZZ >= 0) digitalWrite(PIN_BUZZ, LOW);
}

// ---------- nut bam ----------
// Cach noi: 1 chan nut -> chan GPIO, chan kia -> GND (bam = muc THAP), dung pull-up noi.
// Neu noi nut vao 3V3: them -DBTN_ACTIVE_HIGH vao build_flags.
#ifdef BTN_ACTIVE_HIGH
  #define BTN_MODE INPUT_PULLDOWN
  #define BTN_PRESSED HIGH
#else
  #define BTN_MODE INPUT_PULLUP
  #define BTN_PRESSED LOW
#endif
#define DEBOUNCE_MS 25
#define LONG_MS 600

struct Btn {
  uint8_t pin;
  bool pressed;     // da loc nhieu
  bool raw;         // doc truc tiep
  bool longDone;
  uint32_t tRaw;
  uint32_t tDown;
  uint32_t count;
};
Btn btns[2] = {{PIN_A, false, false, false, 0, 0, 0}, {PIN_B, false, false, false, 0, 0, 0}};

// Che do game: nut tra su kien NGAY khi bam (khong cho nha), khong co bam-giu.
// Thoat game bang cach GIU CA HAI NUT 0.7 giay.
bool btnGame = false;
uint32_t comboT = 0;
bool comboDone = false;

void initButtons() {
  for (int i = 0; i < 2; i++) {
    pinMode(btns[i].pin, BTN_MODE);
    btns[i].raw = btns[i].pressed = (digitalRead(btns[i].pin) == BTN_PRESSED);
    btns[i].tRaw = millis();
  }
}

int pollBtn(int i) {
  Btn &b = btns[i];
  uint32_t now = millis();
  bool raw = (digitalRead(b.pin) == BTN_PRESSED);
  if (raw != b.raw) { b.raw = raw; b.tRaw = now; }
  int shortEv = (i == 0) ? EV_UP : EV_DOWN;
  int longEv = (i == 0) ? EV_OK : EV_BACK;
  if (raw != b.pressed && now - b.tRaw >= DEBOUNCE_MS) {
    b.pressed = raw;
    if (raw) {
      b.tDown = now; b.longDone = false; b.count++;
      if (btnGame) return shortEv;
    } else if (!b.longDone && !btnGame) return shortEv;
  }
  // Trong game: nut B bam ngan van la XUONG, nhung giu B se QUAY LAI.
  // Nut A giu trong game khong tao su kien de tranh kich hoat nham.
  if ((!btnGame || i == 1) && b.pressed && !b.longDone && now - b.tDown >= LONG_MS) {
    b.longDone = true;
    return longEv;
  }
  return EV_NONE;
}

int readEvent() {
  static int pending = EV_NONE;
  if (pending != EV_NONE) { int e = pending; pending = EV_NONE; return e; }
  int a = pollBtn(0);
  int b = pollBtn(1);
  if (btnGame) {
    uint32_t now = millis();
    if (btns[0].pressed && btns[1].pressed) {
      if (comboT == 0) comboT = now;
      else if (!comboDone && now - comboT >= 700) { comboDone = true; return EV_BACK; }
    } else { comboT = 0; comboDone = false; }
  }
  if (a != EV_NONE) { pending = b; return a; }
  return b;
}

// ---------- ve dung chung ----------
void drawHeader(const String &t) {
  oled.setCursor(0, 1);
  oled.print(t);
  oled.drawFastHLine(0, 10, 128, C_ON);
}
void centerText(const String &s, int y, int size) {
  oled.setTextSize(size);
  int w = (int)s.length() * 6 * size;
  oled.setCursor(imax(0, (128 - w) / 2), y);
  oled.print(s);
  oled.setTextSize(1);
}
// Danh sach dong co o chon; vals co the = nullptr
void drawRows(const std::vector<String> &names, const std::vector<String> *vals, int sel, int y0, int rows) {
  int n = (int)names.size();
  int top = sel - rows / 2;
  if (top > n - rows) top = n - rows;
  if (top < 0) top = 0;
  for (int i = 0; i < rows && top + i < n; i++) {
    int y = y0 + i * 10;
    bool s = (top + i == sel);
    if (s) { oled.fillRect(0, y - 1, 128, 10, C_ON); oled.setTextColor(C_OFF); }
    else oled.setTextColor(C_ON);
    String nm = names[top + i];
    String v = vals ? (*vals)[top + i] : String("");
    int maxn = 21 - (int)v.length() - (v.length() ? 1 : 0);
    if ((int)nm.length() > maxn) nm = nm.substring(0, maxn);
    oled.setCursor(3, y);
    oled.print(nm);
    if (v.length()) { oled.setCursor(125 - (int)v.length() * 6, y); oled.print(v); }
  }
  oled.setTextColor(C_ON);
  if (n > rows) {                                   // thanh cuon nho
    int h = imax(4, rows * 10 * rows / n);
    int y = y0 + (rows * 10 - h) * sel / imax(1, n - 1);
    oled.drawFastVLine(127, y, h, C_ON);
  }
}
