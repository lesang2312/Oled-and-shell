// ============================================================
//  Mang: WiFi (STA + AP du phong), NTP, thoi tiet, Web, Bluetooth
//  Web: http://buddy.local  hoac  http://<IP>  (chua co WiFi: noi mang "ESP32-Buddy", mat khau 12345678, http://192.168.4.1)
// ============================================================
#pragma once
#include "core.h"

WebServer server(80);
#if ENABLE_BT
BluetoothSerial SerialBT;
#endif
bool btUp = false;
uint32_t wfT = 0, wfRetry = 0;
bool webStarted = false, mdnsUp = false;
bool wifiRestartPending = false;
uint32_t wifiRestartAt = 0;

void scheduleWifiRestart(uint32_t delayMs = 500) {
  wifiRestartPending = true;
  wifiRestartAt = millis() + delayMs;
}

String wfIp() {
  if (wfState == WF_STA) return WiFi.localIP().toString();
  if (wfState == WF_AP) return WiFi.softAPIP().toString();
  return String("");
}

// ---------- NTP ----------
void onNtp(struct timeval *tv) { ntpFlag = true; }
void ntpSync() { configTime(0, 0, "pool.ntp.org", "time.google.com", "time.cloudflare.com"); }

// ---------- WiFi ----------
void startAP() {
  WiFi.mode(WIFI_AP);
  WiFi.softAP("ESP32-Buddy", "12345678");
  wfState = WF_AP;
}
void wifiStart() {
  if (!S.wifiOn) { wfState = WF_OFF; return; }
  if (wifiSsid.length()) {
    WiFi.mode(WIFI_STA);
    WiFi.begin(wifiSsid.c_str(), wifiPass.c_str());
    wfState = WF_CONNECTING;
    wfT = millis();
  } else startAP();
}
void wifiRestart() {
  wifiRestartPending = false;
  // Rebind web server sau khi doi AP/STA hoac bat/tat WiFi.
  if (webStarted) { server.stop(); webStarted = false; }
  if (mdnsUp) { MDNS.end(); mdnsUp = false; }
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  wfState = WF_OFF;
  delay(50);
  wifiStart();
}
void onWifiUp() {
  if (!mdnsUp) {
    if (MDNS.begin("buddy")) { MDNS.addService("http", "tcp", 80); mdnsUp = true; }
  }
  sntp_set_time_sync_notification_cb(onNtp);
  ntpSync();
  wxReq = true;
  showPopup("WiFi", "Da noi " + WiFi.localIP().toString());
}

// ---------- Thoi tiet (Open-Meteo, khong can API key) ----------
float jsonNum(const String &s, const char *key) {
  String k = String("\"") + key + "\"";
  int p = s.indexOf(k);
  if (p < 0) return NAN;
  p = s.indexOf(':', p + k.length());
  if (p < 0) return NAN;
  p++;
  while (p < (int)s.length() && (s[p] == ' ' || s[p] == '\t' || s[p] == '\r' || s[p] == '\n')) p++;
  if (p >= (int)s.length() || s.substring(p, p + 4) == "null") return NAN;
  return s.substring(p).toFloat();
}
bool fetchWeather() {
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(9000);
  String url = String("https://api.open-meteo.com/v1/forecast?latitude=") + String(geoLat, 4) + "&longitude=" + String(geoLon, 4) +
               "&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,weather_code,wind_speed_10m&timezone=auto";
  if (!http.begin(client, url)) return false;
  int code = http.GET();
  if (code != 200) { http.end(); return false; }
  String body = http.getString();
  http.end();
  int p = body.indexOf("\"current\"");
  if (p < 0) return false;
  String cur = body.substring(p);
  float t = jsonNum(cur, "temperature_2m");
  float h = jsonNum(cur, "relative_humidity_2m");
  float w = jsonNum(cur, "wind_speed_10m");
  float c = jsonNum(cur, "weather_code");
  float feels = jsonNum(cur, "apparent_temperature");
  float day = jsonNum(cur, "is_day");
  if (isnan(t) || isnan(c)) return false;
  wx.t = t;
  wx.feels = isnan(feels) ? t : feels;
  wx.hum = isnan(h) ? 0 : clampi((int)h, 0, 100);
  wx.wind = isnan(w) ? 0 : w;
  wx.code = (int)c;
  wx.isDay = isnan(day) ? true : day >= 0.5f;
  wx.at = millis();
  wx.ok = true;
  wxFailed = false;
  dirty = true;
  return true;
}
void weatherTask(void *) {
  for (;;) {
    if (wxReq) {
      wxReq = false;
      wxBusy = true;
      bool ok = fetchWeather();
      wxFailed = !ok;
      wxBusy = false;
      if (screen == SC_WEATHER) dirty = true;
    }
    vTaskDelay(pdMS_TO_TICKS(500));
  }
}

// ---------- Trang web ----------
const char PAGE[] PROGMEM = R"HTML(<!doctype html><html lang=vi><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>ESP32 Buddy</title>
<style>
body{font-family:system-ui,sans-serif;background:#1e1e2e;color:#cdd6f4;max-width:680px;margin:0 auto;padding:14px}
h1{color:#cba6f7;font-size:22px}h3{margin:20px 0 6px;color:#94e2d5}
textarea,input{width:100%;box-sizing:border-box;background:#313244;color:#cdd6f4;border:1px solid #585b70;border-radius:10px;padding:9px;font-size:15px}
button{background:#cba6f7;color:#1e1e2e;border:0;border-radius:18px;padding:8px 16px;margin:6px 6px 0 0;font-weight:700;cursor:pointer}
button.g{background:#45475a;color:#cdd6f4}
pre{background:#181825;border-radius:10px;padding:10px;white-space:pre-wrap;font-size:12px}
.f{display:flex;gap:8px;align-items:center;padding:6px 0;border-bottom:1px solid #313244}.f span{flex:1;word-break:break-all}
.f button{margin:0;padding:5px 12px}
.wxcard{background:linear-gradient(135deg,#313244,#45475a);border:1px solid #585b70;border-radius:16px;padding:14px;margin:8px 0}
.wxhead{display:flex;align-items:center;justify-content:space-between}.wxt{font-size:42px;font-weight:800;line-height:1;color:#f9e2af}.wxemoji{font-size:54px;line-height:1}.wxsub{font-size:12px;color:#a6adc8;margin-top:3px}
.wxstats{display:flex;justify-content:space-between;gap:8px;border-top:1px solid #585b70;padding-top:10px;margin-top:12px;font-size:12px;color:#bac2de}.wxloc{display:flex;gap:8px;margin-top:8px}.wxloc input{min-width:0;width:50%}
</style></head><body>
<h1>&#128223; ESP32 Buddy</h1><pre id=st>...</pre>
<h3>Thoi tiet</h3>
<div class=wxcard><div class=wxhead><div><div class=wxt id=wt>--°</div><div id=wc>Dang cho du lieu...</div><div class=wxsub id=wa>Cam nhan --°C</div></div><div class=wxemoji id=wi>⛅</div></div>
<div class=wxstats><span>💧 <b id=wh>--%</b></span><span>🌬 <b id=ww>-- km/h</b></span><span id=wu>Chua cap nhat</span></div></div>
<div class=wxsub>Vi tri du bao (toa do; mac dinh TP.HCM)</div><div class=wxloc><input id=lat type=number step=any placeholder="Vi do"><input id=lon type=number step=any placeholder="Kinh do"></div>
<button class=g onclick=geo()>Luu vi tri</button><button class=g onclick=refreshWxNow()>Cap nhat thoi tiet</button>
<h3>Ghi chu / popup</h3>
<textarea id=t rows=3 placeholder="Noi dung (tu dong bo dau)"></textarea>
<button onclick=note()>Ghi chu</button><button class=g onclick=msg()>Popup</button>
<h3>Gui file .txt</h3>
<input type=file id=f accept=".txt,.md,.log"><button onclick=up()>Tai len</button>
<h3>File tren thiet bi</h3><div id=fl></div><button class=g onclick=ls()>Lam moi</button>
<h3>Bao thuc / hen gio</h3>
<input id=al type=time style="width:auto"><button onclick=alarm()>Dat bao thuc</button><button class=g onclick=alOff()>Tat</button><br>
<input id=tm type=number min=1 placeholder="phut" style="width:110px"><button onclick=timer()>Dem nguoc</button>
<h3>WiFi</h3>
<input id=ss placeholder="Ten WiFi"><input id=pw type=password placeholder="Mat khau" style="margin-top:6px">
<button onclick=wifi()>Luu va ket noi</button>
<pre id=out></pre>
<script>
const $=i=>document.getElementById(i);
const S=s=>s.replace(/\r\n?/g,'\n').replace(/\t/g,' ').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D').replace(/[^\x20-\x7e\n]/g,'?');
async function cmd(c){const r=await fetch('/api/cmd',{method:'POST',body:c});const x=(await r.text()).trim();$('out').textContent=x;return x}
function note(){cmd('NOTE '+S($('t').value).replace(/\n/g,' '))}
function msg(){cmd('MSG '+S($('t').value).replace(/\n/g,' '))}
async function up(){const f=$('f').files[0];if(!f)return;
 const n=f.name.replace(/[^A-Za-z0-9._-]/g,'_');
 const r=await fetch('/api/put?n='+encodeURIComponent(n),{method:'POST',body:S(await f.text())});
 $('out').textContent=await r.text();ls()}
async function ls(){const j=await (await fetch('/api/files')).json();const d=$('fl');d.innerHTML='';
 j.forEach(x=>{const r=document.createElement('div');r.className='f';
  r.innerHTML='<span></span>';r.firstChild.textContent=x.n+'  ('+x.s+' B)';
  const b=(t,fn)=>{const e=document.createElement('button');e.textContent=t;e.onclick=fn;r.appendChild(e)};
  b('Doc',()=>cmd('OPEN '+x.n));b('Xem',()=>window.open('/f?n='+encodeURIComponent(x.n)));
  b('Xoa',async()=>{if(confirm('Xoa '+x.n+'?')){await cmd('DEL '+x.n);ls()}});d.appendChild(r)})}
function alarm(){if($('al').value)cmd('ALARM '+$('al').value+' on')}
function alOff(){cmd('ALARM off')}
function timer(){cmd('TIMER '+($('tm').value||10))}
function wifi(){cmd('WIFI '+$('ss').value+'\t'+$('pw').value)}
function geo(){const a=Number($('lat').value),b=Number($('lon').value);if(!Number.isFinite(a)||!Number.isFinite(b)||a < -90||a > 90||b < -180||b > 180){$('out').textContent='Toa do khong hop le';return}cmd('GEO '+a+' '+b).then(refreshWxNow)}
function wxIcon(c){if(c===0)return '☀️';if(c<=2)return '🌤️';if(c===3)return '☁️';if(c===45||c===48)return '🌫️';if(c>=95)return '⛈️';if((c>=71&&c<=77)||(c>=85&&c<=86))return '❄️';if((c>=51&&c<=67)||(c>=80&&c<=82))return '🌧️';return '☁️'}
function wxText(c){if(c===0)return 'Troi quang';if(c<=2)return 'It may';if(c===3)return 'Nhieu may';if(c===45||c===48)return 'Suong mu';if(c>=51&&c<=57)return 'Mua phun';if(c>=61&&c<=67)return 'Mua';if(c>=71&&c<=77)return 'Tuyet';if(c>=80&&c<=82)return 'Mua rao';if(c>=95)return 'Dong bao';return 'Thoi tiet'}
function refreshWxNow(){$('wu').textContent='Dang yeu cau cap nhat';cmd('WX').then(()=>{setTimeout(refreshWx,3000);setTimeout(refreshWx,8000);})}
function refreshWx(){try{return fetch('/api/weather').then(r=>r.json()).then(w=>{$('wt').textContent=w.ok?Math.round(w.t)+'°':'--°';$('wc').textContent=w.ok?wxText(w.code):(w.busy?'Dang cap nhat...':'Chua co du lieu');$('wi').textContent=wxIcon(w.code);$('wa').textContent=w.ok?'Cam nhan '+Math.round(w.feels)+'°C':'Can ket noi WiFi Internet';$('wh').textContent=w.ok?w.hum+'%':'--%';$('ww').textContent=w.ok?Math.round(w.wind)+' km/h':'-- km/h';$('wu').textContent=w.busy?'Dang cap nhat':(w.ok?'Cap nhat '+w.age+' phut truoc':(w.failed?'Tai that bai':'Cho du lieu'));if(!$('lat').value)$('lat').value=w.lat;if(!$('lon').value)$('lon').value=w.lon;});}catch(e){}}
async function st(){try{$('st').textContent=await (await fetch('/api/state')).text()}catch(e){}}
st();ls();refreshWx();setInterval(st,5000);setInterval(refreshWx,60000);
</script></body></html>)HTML";

void webSetup() {
  server.on("/", HTTP_GET, []() { server.send_P(200, "text/html; charset=utf-8", PAGE); });
  server.on("/api/cmd", HTTP_POST, []() {
    String line = server.arg("plain");
    StrOut o;
    processLine(line, o);
    server.send(200, "text/plain; charset=utf-8", o.s);
  });
  server.on("/api/state", HTTP_GET, []() {
    StrOut o;
    processLine("INFO", o);
    processLine("NET", o);
    server.send(200, "text/plain; charset=utf-8", o.s);
  });
  server.on("/api/weather", HTTP_GET, []() {
    String j = String("{\"ok\":") + (wx.ok ? "true" : "false") +
      ",\"t\":" + (wx.ok ? String(wx.t, 1) : String("null")) +
      ",\"feels\":" + (wx.ok ? String(wx.feels, 1) : String("null")) +
      ",\"hum\":" + String(wx.hum) + ",\"wind\":" + String(wx.wind, 1) +
      ",\"code\":" + String(wx.code) + ",\"day\":" + String(wx.isDay ? 1 : 0) +
      ",\"age\":" + String(wx.ok ? (millis() - wx.at) / 60000UL : 0) +
      ",\"busy\":" + (wxBusy ? "true" : "false") +
      ",\"failed\":" + (wxFailed ? "true" : "false") +
      ",\"lat\":" + String(geoLat, 5) + ",\"lon\":" + String(geoLon, 5) + "}";
    server.send(200, "application/json", j);
  });
  server.on("/api/files", HTTP_GET, []() {
    String j = "[";
    File root = LittleFS.open("/");
    File f = root.openNextFile();
    bool first = true;
    while (f) {
      if (!f.isDirectory()) {
        String n = f.name();
        if (n.startsWith("/")) n = n.substring(1);
        if (!first) j += ",";
        first = false;
        j += "{\"n\":\"" + n + "\",\"s\":" + String((unsigned long)f.size()) + "}";
      }
      f = root.openNextFile();
    }
    j += "]";
    server.send(200, "application/json", j);
  });
  server.on("/api/put", HTTP_POST, []() {
    String p = cleanPath(server.arg("n"));
    String body = server.arg("plain");
    if (!p.length()) { server.send(400, "text/plain", "ERR ten file"); return; }
    if (body.length() > 48000) { server.send(413, "text/plain", "ERR qua lon (toi da 48KB)"); return; }
    if ((size_t)(LittleFS.totalBytes() - LittleFS.usedBytes()) < body.length() + 4096) { server.send(507, "text/plain", "ERR day bo nho"); return; }
    File f = LittleFS.open(p, "w");
    if (!f) { server.send(500, "text/plain", "ERR mo file"); return; }
    size_t written = f.write((const uint8_t *)body.c_str(), body.length());
    f.close();
    if (written != body.length()) { LittleFS.remove(p); server.send(507, "text/plain", "ERR ghi file khong day du"); return; }
    if (p == "/notes.txt") loadNotes();
    if (p == "/todo.txt") loadTodos();
    if (screen == SC_RDLIST) refreshTxt();
    if (screen == SC_FILES) refreshFiles();
    showPopup("Da nhan file", p.substring(1));
    server.send(200, "text/plain", "OK PUT " + p + " " + String((unsigned long)written));
  });
  server.on("/f", HTTP_GET, []() {
    String p = cleanPath(server.arg("n"));
    if (!p.length() || !LittleFS.exists(p)) { server.send(404, "text/plain", "khong thay file"); return; }
    File f = LittleFS.open(p, "r");
    server.streamFile(f, "text/plain; charset=utf-8");
    f.close();
  });
  server.onNotFound([]() { server.send(404, "text/plain", "404"); });
}

// ---------- Bluetooth Serial ----------
void buddyBtStart() {
#if ENABLE_BT
  if (SerialBT.begin("ESP32-Buddy")) btUp = true;
#endif
}

// ---------- Vong lap mang ----------
void netLoop() {
  uint32_t now = millis();
  if (wfState == WF_CONNECTING) {
    if (WiFi.status() == WL_CONNECTED) { wfState = WF_STA; onWifiUp(); }
    else if (now - wfT > 20000) {
      WiFi.disconnect(true);
      startAP();
      showPopup("WiFi", "Khong noi duoc, mo AP ESP32-Buddy");
    }
  } else if (wfState == WF_STA && WiFi.status() != WL_CONNECTED && now - wfRetry > 10000) {
    wfRetry = now;
    WiFi.reconnect();
  }
  if (!webStarted && (wfState == WF_STA || wfState == WF_AP)) { server.begin(); webStarted = true; }
  if (wfState == WF_STA || wfState == WF_AP) server.handleClient();
  if (wifiRestartPending && (int32_t)(now - wifiRestartAt) >= 0) wifiRestart();
  if (ntpFlag) {
    ntpFlag = false;
    applyTime((uint32_t)time(nullptr), 3, true);
    dirty = true;
  }
  static uint32_t lastWx = 0;
  if (wfState == WF_STA && now - lastWx > 1800000UL) { lastWx = now; wxReq = true; }
}
