#!/bin/sh
# Cài study-shell đúng chỗ. Chạy trong thư mục đã giải nén:  sh install.sh
# Giữ nguyên dữ liệu của bạn khi cài đè: ảnh chụp (scr), ảnh kỷ niệm (memories), mục tiêu (goal.json).
set -e
here="$(cd "$(dirname "$0")" && pwd)"
dest="$HOME/.config/quickshell/study"
keep="scr memories goal.json todo.json pomodoro.json"

mkdir -p "$HOME/.config/quickshell" "$HOME/.config/hypr" \
         "$HOME/Pictures/Wallpapers" "$HOME/.cache/qs-study"

# Cất dữ liệu người dùng sang chỗ tạm
tmp="$(mktemp -d)"
for item in $keep; do
  if [ -e "$dest/$item" ]; then mv "$dest/$item" "$tmp/$item"; fi
done

rm -rf "$dest"
mkdir -p "$dest"
cp -r "$here/quickshell/study/." "$dest/"

# Trả dữ liệu về chỗ cũ
for item in $keep; do
  if [ -e "$tmp/$item" ]; then rm -rf "$dest/$item"; mv "$tmp/$item" "$dest/$item"; fi
done
mkdir -p "$dest/scr" "$dest/memories"
rm -rf "$tmp"

# Cấu hình Hyprland (sao lưu bản cũ)
if [ -f "$HOME/.config/hypr/hyprland.lua" ]; then
  cp "$HOME/.config/hypr/hyprland.lua" "$HOME/.config/hypr/hyprland.lua.bak"
fi
cp "$here/hypr/hyprland.lua" "$HOME/.config/hypr/hyprland.lua"

# Thông báo giờ do Quickshell (Dynamic Island) nhận. Chỉ một chương trình được giữ dịch vụ thông báo,
# nên phải tắt mako / dunst / swaync nếu đang chạy.
for d in mako dunst swaync; do pkill -x "$d" 2>/dev/null || true; done

# Kiểm tra đã đủ file và đúng bản
for f in shell.qml Bar.qml Launcher.qml PowerMenu.qml ConnectPanel.qml MemoryGallery.qml GoalWidget.qml \
         WallpaperPicker.qml Wallpaper.qml Pomodoro.qml TodoPanel.qml BuddyPanel.qml Island.qml netcheck.sh diag.sh sysmon.sh buddy.py; do
  [ -f "$dest/$f" ] || { echo "THIẾU $f trong $dest"; exit 1; }
done
grep -q "buddyOpen" "$dest/shell.qml" || { echo "shell.qml vẫn là bản cũ"; exit 1; }
if [ -e "$dest/study" ]; then echo "CẢNH BÁO: có thư mục lồng $dest/study, hãy xoá nó"; fi

# ESP32 Buddy: cần quyền mở cổng USB serial và python3
command -v python3 >/dev/null 2>&1 || echo "Thiếu python3 (cần cho bảng ESP32 Buddy)"
if ! id -nG | grep -qwE "uucp|dialout"; then
  echo "Muốn gửi sang ESP32: thêm user vào nhóm serial rồi đăng nhập lại (Arch: sudo usermod -aG uucp $USER | Debian: dialout)"
fi
python3 -c "import PIL" 2>/dev/null || command -v magick >/dev/null 2>&1 || command -v convert >/dev/null 2>&1 \
  || echo "Muốn gửi hình nền sang ESP32: cài python-pillow hoặc imagemagick"

if [ ! -d /usr/share/icons/Papirus-Dark ] && [ ! -d "$HOME/.local/share/icons/Papirus-Dark" ] \
   && [ ! -d "$HOME/.icons/Papirus-Dark" ]; then
  echo "CHƯA CÓ theme Papirus-Dark: hãy cài gói papirus-icon-theme (Arch: sudo pacman -S papirus-icon-theme)"
fi
if ! fc-list 2>/dev/null | grep -qi "Inter"; then
  echo "Chưa thấy font Inter (dùng cho widget mục tiêu): Arch: sudo pacman -S inter-font"
fi

echo "Xong. Chạy:  pkill qs; qs -c study"
echo "Kiểm tra cấu hình Hyprland: hyprctl configerrors"
