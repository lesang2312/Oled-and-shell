# Shell Quickshell "study" – nhẹ, đủ dùng

## Cài đặt
```sh
mkdir -p ~/.config/quickshell/study ~/Pictures/Wallpapers ~/.cache/qs-study
cp shell.qml Bar.qml Wallpaper.qml Pomodoro.qml ~/.config/quickshell/study/
# bỏ vài ảnh (png/jpg/webp) vào ~/Pictures/Wallpapers
qs -c study
```
Tự chạy khi vào Hyprland: thêm `exec-once = qs -c study` vào hyprland.conf.

## Tính năng
- Nền: lớp Background, quét `~/Pictures/Wallpapers`, nhớ ảnh đã chọn (`~/.cache/qs-study/wallpaper`).
  Bấm 🖼: trái = ảnh kế, phải = ảnh trước.
- Bar: workspace (Hyprland), đồng hồ, Pomodoro 25/5 (trái = chạy/dừng, phải = reset,
  có notify-send khi đổi pha), âm lượng (click = mute, cuộn = chỉnh), pin.
- Nhẹ: không dùng thư viện ngoài, ảnh nền giải mã đúng độ phân giải màn hình,
  đồng hồ cập nhật mỗi phút, timer chỉ chạy khi Pomodoro đang bật.

## Yêu cầu
Quickshell, PipeWire, UPower, `libnotify` (notify-send). Không dùng Hyprland thì
thay khối workspace trong Bar.qml bằng `Quickshell.I3` (Sway/i3) hoặc `Niri`.

## Chỉnh nhanh
- Thư mục nền / màu / thời gian Pomodoro: đầu `shell.qml`, `Bar.qml`, `Pomodoro.qml`.
- Đổi tên thư mục `study` thì chạy `qs -c <tên>` tương ứng.

## ESP32 Buddy (màn OLED qua USB hoặc WiFi)
- Mở bảng: **Win+E** hoặc nút 📟 trên thanh. Có 3 tab: **Gửi** (ghi chú / tin nhắn / hình nền), **File** (gửi file .txt, danh sách file trên ESP32, ▶ Đọc / ⬇ / ✕) và **Thiết bị** (kết nối Tự động/USB/WiFi, tự đồng bộ, hẹn giờ, báo thức, WiFi, vị trí thời tiết).
- Kết nối: ưu tiên cáp USB, không có thì dùng WiFi (`buddy.local` hoặc IP trong `~/.config/quickshell/study/buddy.host`).
- Tự đồng bộ (tab Thiết bị): mỗi 15 giây gửi giờ, CPU/RAM, Pomodoro và danh sách việc cần làm.
- Gửi nhanh: `qs -c study ipc call buddy note "chữ"` | `msg` | `wall` | `time` | `put /đường/dẫn.txt` | `open tên.txt` | `alarm 06:30` | `timer 25 học` | `sync` | `autosync true`.
- `buddy.py` chỉ cần python3 (ảnh cần python-pillow hoặc imagemagick); mã thoát 3 = không thấy thiết bị.

