#!/usr/bin/env bash
# =============================================================================
# setup.sh – cài toàn bộ study-shell (Hyprland + Quickshell) và project ESP32 OLED
# Chạy:  bash setup.sh            (KHÔNG dùng sudo; script tự gọi sudo khi cần)
# Tuỳ chọn:  --no-packages  bỏ qua cài gói      --no-system  bỏ qua dịch vụ/nhóm/udev
#            --no-projects  bỏ qua chép project PlatformIO
# Biến:      PIO_DIR=... đổi nơi đặt project (mặc định ~/Documents/PlatformIO/Projects)
# Chạy lại nhiều lần vẫn an toàn (không mất dữ liệu: ảnh kỷ niệm, todo, goal...).
# =============================================================================
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAY="$HERE/payload"
PIO_DIR="${PIO_DIR:-$HOME/Documents/PlatformIO/Projects}"
TS="$(date +%Y%m%d-%H%M%S)"
DO_PKG=1; DO_SYS=1; DO_PROJ=1
for a in "$@"; do
  case "$a" in
    --no-packages) DO_PKG=0 ;;
    --no-system)   DO_SYS=0 ;;
    --no-projects) DO_PROJ=0 ;;
    -h|--help) sed -n 2,10p "$0"; exit 0 ;;
    *) echo "Tuỳ chọn lạ: $a"; exit 2 ;;
  esac
done

c_ok=$'\033[32m'; c_w=$'\033[33m'; c_e=$'\033[31m'; c_b=$'\033[1m'; c_0=$'\033[0m'
step() { printf '\n%s==> %s%s\n' "$c_b" "$*" "$c_0"; }
ok()   { printf '%s  ✓%s %s\n' "$c_ok" "$c_0" "$*"; }
warn() { printf '%s  ! %s%s\n' "$c_w" "$*" "$c_0"; WARNS+=("$*"); }
die()  { printf '%s  ✗ %s%s\n' "$c_e" "$*" "$c_0"; exit 1; }
WARNS=()
trap 'printf "%s  ✗ Lỗi ở dòng %s: %s%s\n" "$c_e" "$LINENO" "$BASH_COMMAND" "$c_0"' ERR

[ "$(id -u)" -ne 0 ] || die "Đừng chạy bằng root/sudo, hãy chạy: bash setup.sh"
[ -d "$PAY/study-shell/quickshell/study" ] || die "Thiếu payload/study-shell. Hãy giải nén đầy đủ study-setup.zip"
HAS_PACMAN=0; command -v pacman >/dev/null 2>&1 && HAS_PACMAN=1
SUDO=""; if [ "$DO_PKG" = 1 ] || [ "$DO_SYS" = 1 ]; then command -v sudo >/dev/null 2>&1 && SUDO=sudo || die "Cần sudo"; fi

# -----------------------------------------------------------------------------
# 1. GÓI (Arch / Manjaro / CachyOS / EndeavourOS...)
# -----------------------------------------------------------------------------
# Quickshell + dịch vụ: Pipewire, Mpris, UPower, Notifications, Hyprland đều đã nằm trong gói quickshell
PKGS=(
  # lõi
  hyprland quickshell hyprlock xdg-desktop-portal-hyprland qt6-wayland qt6-declarative
  # âm thanh: pipewire + pactl/parec (libpulse) + MPRIS (playerctl) cho đảo nhạc & EQ OLED
  pipewire pipewire-pulse pipewire-alsa wireplumber libpulse playerctl alsa-utils
  # hệ thống
  upower networkmanager bluez bluez-utils brightnessctl libnotify polkit
  curl iproute2 util-linux xdg-utils wl-clipboard grim slurp
  # ứng dụng dùng trong hyprland.lua
  kitty btop firefox
  # giao diện: icon Papirus + font (Inter cho widget mục tiêu, emoji cho bar)
  papirus-icon-theme inter-font noto-fonts noto-fonts-emoji ttf-jetbrains-mono-nerd
  # gõ tiếng Việt
  fcitx5 fcitx5-unikey fcitx5-gtk fcitx5-qt fcitx5-configtool
  # python cho buddy.py / share.py / buddy_eq.py và gửi hình nền sang OLED
  python python-pillow imagemagick
  # đăng nhập (nút Đăng xuất dùng sddm)
  sddm
  # nạp ESP32
  platformio-core
)

install_packages() {
  [ "$HAS_PACMAN" = 1 ] || { warn "Không phải Arch (không có pacman): tự cài các gói tương đương: ${PKGS[*]}"; return 0; }
  step "Cài gói (pacman)"
  local repo=() aur=() p
  for p in "${PKGS[@]}"; do
    if pacman -Qq "$p" >/dev/null 2>&1; then continue
    elif pacman -Si "$p" >/dev/null 2>&1; then repo+=("$p")
    else aur+=("$p"); fi
  done
  if [ "${#repo[@]}" -gt 0 ]; then
    echo "  cài: ${repo[*]}"
    $SUDO pacman -S --needed --noconfirm "${repo[@]}" || warn "pacman báo lỗi (thử sudo pacman -Syu rồi chạy lại setup.sh)"
  else ok "Gói trong repo đã đủ"; fi
  if [ "${#aur[@]}" -gt 0 ]; then
    local helper=""; command -v paru >/dev/null 2>&1 && helper=paru; [ -z "$helper" ] && command -v yay >/dev/null 2>&1 && helper=yay
    if [ -n "$helper" ]; then
      echo "  AUR ($helper): ${aur[*]}"
      "$helper" -S --needed --noconfirm "${aur[@]}" || warn "AUR không cài được: ${aur[*]}"
    else
      warn "Không có trong repo chính, cần AUR helper (paru/yay): ${aur[*]}"
    fi
  fi
  # brltty giành cổng USB-serial của CH340/CP210x, làm nạp ESP32 thất bại
  if pacman -Qq brltty >/dev/null 2>&1; then
    $SUDO pacman -Rns --noconfirm brltty && ok "Đã gỡ brltty (hay chiếm cổng ESP32)"
  fi
  ok "Xong phần gói"
}
[ "$DO_PKG" = 1 ] && install_packages

# Hyprland cần 0.55+ vì hyprland.lua dùng cấu hình Lua
HYPR_OK=1
if command -v Hyprland >/dev/null 2>&1; then
  hv="$(Hyprland --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -1 || true)"
  if [ -n "$hv" ] && [ "$(printf '%s\n0.55\n' "$hv" | sort -V | head -1)" != "0.55" ]; then
    HYPR_OK=0; warn "Hyprland $hv < 0.55: sẽ KHÔNG ghi đè hyprland.lua (cập nhật Hyprland rồi chạy lại)"
  fi
fi

# -----------------------------------------------------------------------------
# 2. DỊCH VỤ, NHÓM, UDEV
# -----------------------------------------------------------------------------
setup_system() {
  step "Dịch vụ hệ thống"
  for s in NetworkManager bluetooth; do
    systemctl list-unit-files "$s.service" >/dev/null 2>&1 && $SUDO systemctl enable --now "$s.service" >/dev/null 2>&1 \
      && ok "$s bật" || warn "Không bật được $s"
  done
  # âm thanh chạy ở mức user
  systemctl --user enable --now pipewire.socket pipewire-pulse.socket wireplumber.service >/dev/null 2>&1 \
    && ok "pipewire / pipewire-pulse / wireplumber (user)" || warn "Không bật được pipewire user (vào phiên Hyprland rồi chạy: systemctl --user enable --now pipewire pipewire-pulse wireplumber)"
  # trình quản lý đăng nhập: chỉ bật sddm nếu chưa có cái nào
  if ! systemctl is-enabled display-manager.service >/dev/null 2>&1 && getent passwd sddm >/dev/null 2>&1; then
    $SUDO systemctl enable sddm.service >/dev/null 2>&1 && ok "sddm bật (hiện lúc khởi động)"
  fi

  step "Nhóm người dùng (cổng USB serial, độ sáng)"
  local g added=()
  for g in uucp dialout lock video input; do
    if getent group "$g" >/dev/null 2>&1 && [[ " $(id -nG "$USER") " != *" $g "* ]]; then
      $SUDO usermod -aG "$g" "$USER" && added+=("$g")
    fi
  done
  if [ "${#added[@]}" -gt 0 ]; then ok "Đã thêm vào nhóm: ${added[*]}  (cần đăng xuất/đăng nhập lại)"; NEED_RELOGIN=1
  else ok "Nhóm đã đủ"; fi

  step "Quy tắc udev cho ESP32 (CH340 / CP210x / FTDI / USB gốc Espressif)"
  $SUDO tee /etc/udev/rules.d/99-esp32-serial.rules >/dev/null <<'RULES'
# Cho phép đọc/ghi và cấm ModemManager/brltty chiếm cổng ESP32
SUBSYSTEM=="tty", ATTRS{idVendor}=="1a86", MODE="0666", ENV{ID_MM_DEVICE_IGNORE}="1", ENV{ID_MM_PORT_IGNORE}="1"
SUBSYSTEM=="tty", ATTRS{idVendor}=="10c4", MODE="0666", ENV{ID_MM_DEVICE_IGNORE}="1", ENV{ID_MM_PORT_IGNORE}="1"
SUBSYSTEM=="tty", ATTRS{idVendor}=="0403", MODE="0666", ENV{ID_MM_DEVICE_IGNORE}="1", ENV{ID_MM_PORT_IGNORE}="1"
SUBSYSTEM=="tty", ATTRS{idVendor}=="303a", MODE="0666", ENV{ID_MM_DEVICE_IGNORE}="1", ENV{ID_MM_PORT_IGNORE}="1"
RULES
  $SUDO udevadm control --reload-rules && $SUDO udevadm trigger && ok "udev đã nạp"
}
NEED_RELOGIN=0
[ "$DO_SYS" = 1 ] && setup_system

# -----------------------------------------------------------------------------
# 3. GIAO DIỆN: Papirus-Dark cho GTK + Quickshell
# -----------------------------------------------------------------------------
step "Icon theme Papirus-Dark"
set_ini_key() {  # file section key value
  python3 -I - "$@" <<'PY'
import sys, configparser, os
f, sec, k, v = sys.argv[1:5]
cp = configparser.RawConfigParser(); cp.optionxform = str
if os.path.exists(f): cp.read(f, encoding="utf-8")
if not cp.has_section(sec): cp.add_section(sec)
cp.set(sec, k, v)
os.makedirs(os.path.dirname(f), exist_ok=True)
with open(f, "w", encoding="utf-8") as fh: cp.write(fh, space_around_delimiters=False)
PY
}
for v in gtk-3.0 gtk-4.0; do
  set_ini_key "$HOME/.config/$v/settings.ini" Settings gtk-icon-theme-name Papirus-Dark
  set_ini_key "$HOME/.config/$v/settings.ini" Settings gtk-application-prefer-dark-theme 1
done
command -v gsettings >/dev/null 2>&1 && gsettings set org.gnome.desktop.interface icon-theme 'Papirus-Dark' >/dev/null 2>&1 || true
command -v gsettings >/dev/null 2>&1 && gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark' >/dev/null 2>&1 || true
mkdir -p "$HOME/.config/environment.d"
cat > "$HOME/.config/environment.d/10-study-shell.conf" <<'ENV'
QS_ICON_THEME=Papirus-Dark
ENV
ok "GTK3/GTK4/gsettings + QS_ICON_THEME = Papirus-Dark"
if [ ! -d /usr/share/icons/Papirus-Dark ] && [ ! -d "$HOME/.local/share/icons/Papirus-Dark" ]; then
  warn "Chưa thấy thư mục Papirus-Dark (gói papirus-icon-theme chưa cài?)"
fi

# -----------------------------------------------------------------------------
# 4. QUICKSHELL "study" + hyprland.lua
# -----------------------------------------------------------------------------
step "Quickshell study → ~/.config/quickshell/study"
mkdir -p "$HOME/.config/hypr"
if [ "$HYPR_OK" = 1 ] && [ -f "$HOME/.config/hypr/hyprland.lua" ]; then
  cp "$HOME/.config/hypr/hyprland.lua" "$HOME/.config/hypr/hyprland.lua.pre-study-$TS"
  ok "Sao lưu hyprland.lua → hyprland.lua.pre-study-$TS"
fi
# install.sh gốc: giữ dữ liệu (scr, memories, goal, todo, buddy.json...), chép đúng chỗ, tự kiểm tra
if [ "$HYPR_OK" = 1 ]; then
  sh "$PAY/study-shell/install.sh" >/dev/null
else
  tmp="$(mktemp -d)"; cp -r "$PAY/study-shell" "$tmp/"; rm -rf "$tmp/study-shell/hypr"; mkdir "$tmp/study-shell/hypr"
  cp "$PAY/study-shell/hypr/hyprland.lua" "$tmp/study-shell/hypr/hyprland.lua"
  # giữ nguyên hyprland.lua hiện tại nếu Hyprland quá cũ
  [ -f "$HOME/.config/hypr/hyprland.lua" ] && cp "$HOME/.config/hypr/hyprland.lua" "$tmp/keep.lua"
  sh "$tmp/study-shell/install.sh" >/dev/null
  [ -f "$tmp/keep.lua" ] && cp "$tmp/keep.lua" "$HOME/.config/hypr/hyprland.lua"
  rm -rf "$tmp"
fi
[ -f "$HOME/.config/quickshell/study/shell.qml" ] || die "Chép study thất bại"
[ ! -e "$HOME/.config/quickshell/study/study" ] || die "Có thư mục lồng study/study"
chmod +x "$HOME/.config/quickshell/study/"*.sh 2>/dev/null || true
ok "Đã chép shell, hyprland.lua, tạo ~/Pictures/Wallpapers và ~/.cache/qs-study"

# Hình nền mặc định nếu thư mục trống (shell cần ít nhất 1 ảnh)
if [ -z "$(find "$HOME/Pictures/Wallpapers" -maxdepth 1 -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.webp' \) 2>/dev/null | head -1)" ]; then
  python3 -I - "$HOME/Pictures/Wallpapers/default.png" <<'PY' && ok "Tạo hình nền mặc định (thay bằng ảnh của bạn tuỳ ý)" || warn "Chưa tạo được hình nền mặc định, hãy bỏ ảnh vào ~/Pictures/Wallpapers"
import sys
from PIL import Image
w, h = 1920, 1080
im = Image.new("RGB", (w, h))
px = im.load()
for y in range(h):
    for x in range(0, w):
        t = (x / w * 0.5 + y / h * 0.5)
        px[x, y] = (int(24 + 40 * t), int(24 + 30 * t), int(46 + 70 * t))
im.save(sys.argv[1])
PY
fi

# tắt trình thông báo khác (Quickshell/Dynamic Island giữ dịch vụ thông báo)
for d in mako dunst swaync; do
  pkill -x "$d" 2>/dev/null || true
  systemctl --user disable --now "$d.service" >/dev/null 2>&1 || true
done

# -----------------------------------------------------------------------------
# 5. PROJECT PLATFORMIO + LỆNH oled-flash
# -----------------------------------------------------------------------------
install_projects() {
  step "Project ESP32 → $PIO_DIR"
  mkdir -p "$PIO_DIR"
  local p
  for p in oled esp32-oled-buddy; do
    if [ -d "$PIO_DIR/$p" ]; then mv "$PIO_DIR/$p" "$PIO_DIR/$p.bak-$TS"; ok "Bản cũ → $p.bak-$TS"; fi
    cp -r "$PAY/projects/$p" "$PIO_DIR/$p"
    ok "$PIO_DIR/$p"
  done
}
[ "$DO_PROJ" = 1 ] && install_projects

mkdir -p "$HOME/.local/bin"
install -m 755 "$HERE/bin/oled-flash" "$HOME/.local/bin/oled-flash"
# pio + ~/.local/bin trong PATH (fish và bash/zsh)
mkdir -p "$HOME/.config/fish/conf.d"
cat > "$HOME/.config/fish/conf.d/study-shell.fish" <<'FISH'
fish_add_path -g $HOME/.local/bin
test -d $HOME/.platformio/penv/bin; and fish_add_path -g $HOME/.platformio/penv/bin
FISH
for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
  if [ -f "$rc" ] && ! grep -q "study-shell PATH" "$rc"; then
    printf '\n# study-shell PATH\nexport PATH="$HOME/.local/bin:$HOME/.platformio/penv/bin:$PATH"\n' >> "$rc"
  fi
done
ok "Lệnh oled-flash + PATH (fish/bash/zsh)"

# -----------------------------------------------------------------------------
# 6. KIỂM TRA CUỐI
# -----------------------------------------------------------------------------
step "Kiểm tra"
chk() { if command -v "$1" >/dev/null 2>&1; then ok "$1"; else warn "Thiếu lệnh: $1 ($2)"; fi; }
chk qs "quickshell"; chk Hyprland "hyprland"; chk pactl "libpulse"; chk parec "libpulse"
chk playerctl "playerctl"; chk wpctl "wireplumber"; chk brightnessctl "brightnessctl"
chk nmcli "networkmanager"; chk bluetoothctl "bluez-utils"; chk grim "grim"; chk slurp "slurp"
chk wl-copy "wl-clipboard"; chk notify-send "libnotify"; chk kitty "kitty"; chk fcitx5 "fcitx5"
python3 -c "import PIL" 2>/dev/null && ok "python-pillow" || warn "Thiếu python-pillow"
FL="$(fc-list 2>/dev/null || true)"
[[ "${FL,,}" == *inter* ]] && ok "font Inter" || warn "Thiếu font Inter"
[[ "${FL,,}" == *emoji* ]] && ok "font emoji" || warn "Thiếu font emoji"
if command -v hyprctl >/dev/null 2>&1 && hyprctl version >/dev/null 2>&1; then
  e="$(hyprctl configerrors 2>/dev/null || true)"
  [ -z "$e" ] && ok "hyprctl configerrors: sạch" || warn "Hyprland báo lỗi cấu hình: $e"
fi

printf '\n%s================ XONG ================%s\n' "$c_b" "$c_0"
[ "$NEED_RELOGIN" = 1 ] && echo " • ĐĂNG XUẤT rồi đăng nhập lại (hoặc reboot) để nhóm uucp/video có hiệu lực."
echo " • Vào Hyprland: tự chạy qs -c study. Đang ở trong Hyprland thì: pkill qs; qs -c study"
echo " • Nạp ESP32:  oled-flash        (tự tạm dừng đồng bộ buddy.py, nạp xong tự bật lại)"
echo "   Project:    $PIO_DIR/oled"
if [ "${#WARNS[@]}" -gt 0 ]; then
  printf '\n%sCần xem lại:%s\n' "$c_w" "$c_0"; for w in "${WARNS[@]}"; do echo "   - $w"; done
fi
