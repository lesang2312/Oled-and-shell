study-setup – cài study-shell (Quickshell) + âm thanh + Papirus-Dark + project ESP32 OLED

  unzip study-setup.zip && cd study-setup
  bash setup.sh            # không dùng sudo; fish cũng gọi được: bash setup.sh

Sau đó đăng xuất/đăng nhập lại (để nhóm uucp có hiệu lực) rồi vào Hyprland.
Nạp ESP32:  oled-flash     (tự tạm dừng buddy.py để không giành cổng USB)

Tuỳ chọn: --no-packages  --no-system  --no-projects     Biến: PIO_DIR=...
Chạy lại nhiều lần an toàn: dữ liệu (ảnh kỷ niệm, todo, goal) được giữ, file cũ được sao lưu *.bak-<giờ>.
