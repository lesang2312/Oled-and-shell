-- ~/.config/hypr/hyprland.lua  (Hyprland 0.55+)
-- Cấu hình nhẹ cho học tập / làm việc, đi kèm shell Quickshell "study"
-- Bar + hình nền do qs lo, không cần hyprpaper / waybar.

------------------------------------------------------------
-- BIẾN
------------------------------------------------------------
local mainMod  = "SUPER"          -- phím Win
local terminal = "kitty"
local launcher = "qs -c study ipc call launcher toggle"   -- bảng ứng dụng của shell
local browser  = "firefox"

------------------------------------------------------------
-- MÀN HÌNH & MÔI TRƯỜNG
------------------------------------------------------------
hl.monitor({ output = "", mode = "preferred", position = "auto", scale = 1 })

hl.env("XCURSOR_SIZE", "24")
hl.env("QT_QPA_PLATFORM", "wayland;xcb")
hl.env("QS_ICON_THEME", "Papirus-Dark")   -- icon cho Quickshell (cần gói papirus-icon-theme)
-- Gõ tiếng Việt với fcitx5 (xoá 3 dòng này nếu không dùng)
hl.env("GTK_IM_MODULE", "fcitx")
hl.env("QT_IM_MODULE", "fcitx")
hl.env("XMODIFIERS", "@im=fcitx")

------------------------------------------------------------
-- KHỞI ĐỘNG
------------------------------------------------------------
hl.on("hyprland.start", function()
  hl.exec_cmd("qs -c study")      -- shell: bar + nền + Pomodoro
  hl.exec_cmd("fcitx5 -d")        -- gõ tiếng Việt
  -- Thông báo do chính Quickshell (Dynamic Island) nhận, KHÔNG chạy mako/dunst nữa
end)

------------------------------------------------------------
-- GIAO DIỆN (tắt hiệu ứng nặng cho nhẹ máy)
------------------------------------------------------------
hl.config({
  general = {
    gaps_in = 3,
    gaps_out = 6,
    border_size = 2,
    col = {
      active_border = "rgb(89b4fa)",
      inactive_border = "rgb(313244)",
    },
    layout = "dwindle",
    resize_on_border = true,
  },
  decoration = {
    rounding = 8,
    blur = { enabled = false },
    shadow = { enabled = false },
  },
  animations = { enabled = false },
  dwindle = { preserve_split = true },
  input = {
    kb_layout = "us",
    follow_mouse = 1,
    sensitivity = 0,
    repeat_rate = 35,
    repeat_delay = 250,
    touchpad = { natural_scroll = true },
  },
  misc = {
    disable_hyprland_logo = true,
    disable_splash_rendering = true,
    force_default_wallpaper = 0,
  },
})

------------------------------------------------------------
-- PHÍM TẮT
------------------------------------------------------------
-- Ứng dụng
hl.bind(mainMod .. " + Return", hl.dsp.exec_cmd(terminal))      -- Win+Enter: kitty
hl.bind(mainMod .. " + Q",      hl.dsp.window.close())          -- Win+Q: đóng cửa sổ
hl.bind(mainMod .. " + D",      hl.dsp.exec_cmd(launcher))      -- Win+D: danh sách ứng dụng
hl.bind(mainMod .. " + space",  hl.dsp.exec_cmd(launcher))      -- Win+Space: cũng mở launcher
hl.bind(mainMod .. " + B",      hl.dsp.exec_cmd(browser))
hl.bind(mainMod .. " + W",      hl.dsp.exec_cmd("qs -c study ipc call wallpaper toggle"))  -- ô chọn hình nền
-- Quản lý ứng dụng đang chạy (btop trong kitty: xem/kill tiến trình)
hl.bind(mainMod .. " + SHIFT + Escape", hl.dsp.exec_cmd(terminal .. " -e btop"))

-- Cửa sổ
hl.bind(mainMod .. " + V",         hl.dsp.window.float({ action = "toggle" }))
hl.bind(mainMod .. " + F",         hl.dsp.window.fullscreen({ action = "toggle" }))

-- Di chuyển focus
hl.bind(mainMod .. " + left",  hl.dsp.focus({ direction = "left" }))
hl.bind(mainMod .. " + right", hl.dsp.focus({ direction = "right" }))
hl.bind(mainMod .. " + up",    hl.dsp.focus({ direction = "up" }))
hl.bind(mainMod .. " + down",  hl.dsp.focus({ direction = "down" }))

-- Dời cửa sổ
hl.bind(mainMod .. " + SHIFT + left",  hl.dsp.window.move({ direction = "left" }))
hl.bind(mainMod .. " + SHIFT + right", hl.dsp.window.move({ direction = "right" }))
hl.bind(mainMod .. " + SHIFT + up",    hl.dsp.window.move({ direction = "up" }))
hl.bind(mainMod .. " + SHIFT + down",  hl.dsp.window.move({ direction = "down" }))

-- Workspace 1-3: Win+số để chuyển, Win+Shift+số để chuyển cửa sổ sang
for i = 1, 3 do
  hl.bind(mainMod .. " + " .. i,            hl.dsp.focus({ workspace = i }))
  hl.bind(mainMod .. " + SHIFT + " .. i,    hl.dsp.window.move({ workspace = i }))
end

-- Win + lăn chuột: đổi qua lại giữa workspace 1-2-3 (xử lý trong shell)
hl.bind(mainMod .. " + mouse_down", hl.dsp.exec_cmd("qs -c study ipc call workspace next"))
hl.bind(mainMod .. " + mouse_up",   hl.dsp.exec_cmd("qs -c study ipc call workspace prev"))

-- Kéo / đổi kích thước cửa sổ bằng chuột (Win + giữ chuột trái / phải)
hl.bind(mainMod .. " + mouse:272", hl.dsp.window.drag(),   { drag = true })
hl.bind(mainMod .. " + mouse:273", hl.dsp.window.resize(), { drag = true })

-- Âm lượng, độ sáng (cần wpctl, brightnessctl)
hl.bind("XF86AudioRaiseVolume",
  hl.dsp.exec_cmd("qs -c study ipc call audio up"),
  { locked = true, repeating = true })
hl.bind("XF86AudioLowerVolume",
  hl.dsp.exec_cmd("qs -c study ipc call audio down"),
  { locked = true, repeating = true })
hl.bind("XF86AudioMute",
  hl.dsp.exec_cmd("qs -c study ipc call audio mute"),
  { locked = true })
hl.bind("XF86MonBrightnessUp",
  hl.dsp.exec_cmd("qs -c study ipc call brightness up"),
  { locked = true, repeating = true })
hl.bind("XF86MonBrightnessDown",
  hl.dsp.exec_cmd("qs -c study ipc call brightness down"),
  { locked = true, repeating = true })

-- Phím media: điều khiển trình phát nhạc đang chạy (YouTube, Spotify, mpv...)
hl.bind("XF86AudioPlay", hl.dsp.exec_cmd("qs -c study ipc call media toggle"), { locked = true })
hl.bind("XF86AudioPause", hl.dsp.exec_cmd("qs -c study ipc call media toggle"), { locked = true })
hl.bind("XF86AudioNext", hl.dsp.exec_cmd("qs -c study ipc call media next"), { locked = true })
hl.bind("XF86AudioPrev", hl.dsp.exec_cmd("qs -c study ipc call media prev"), { locked = true })

-- Chụp màn hình (do shell Quickshell xử lý bằng grim; ảnh lưu ở study/scr)
hl.bind("Print",           hl.dsp.exec_cmd("qs -c study ipc call screenshot full"))     -- toàn màn hình: lưu + copy
hl.bind("SHIFT + Print",   hl.dsp.exec_cmd("qs -c study ipc call screenshot region"))   -- chọn vùng: lưu + copy
hl.bind("CTRL + Print",    hl.dsp.exec_cmd("qs -c study ipc call screenshot copy"))     -- chọn vùng: chỉ copy nhanh
hl.bind(mainMod .. " + SHIFT + S", hl.dsp.exec_cmd("qs -c study ipc call screenshot region"))

-- Khởi động lại shell Quickshell nếu bị lỗi
hl.bind(mainMod .. " + SHIFT + R", hl.dsp.exec_cmd("pkill qs; qs -c study"))

-- Dynamic Island: mở/đóng thẻ nhanh (giờ, Pomodoro, CPU/RAM, mục tiêu)
hl.bind(mainMod .. " + I", hl.dsp.exec_cmd("qs -c study ipc call island peek"))

-- Việc cần làm / chế độ tập trung / khoá màn hình
hl.bind(mainMod .. " + T", hl.dsp.exec_cmd("qs -c study ipc call todo toggle"))
hl.bind(mainMod .. " + Z", hl.dsp.exec_cmd("qs -c study ipc call focus toggle"))       -- bật/tắt chế độ tập trung
hl.bind(mainMod .. " + P", hl.dsp.exec_cmd("qs -c study ipc call focus pomodoro"))     -- chạy/dừng Pomodoro
hl.bind(mainMod .. " + L", hl.dsp.exec_cmd("hyprlock"))                                -- khoá màn hình

-- ESP32 Buddy: gửi chữ / hình sang màn OLED qua cáp USB
hl.bind(mainMod .. " + E", hl.dsp.exec_cmd("qs -c study ipc call buddy toggle"))

-- Nhận file / ảnh từ điện thoại (thư viện share_png)
hl.bind(mainMod .. " + A", hl.dsp.exec_cmd("qs -c study ipc call share toggle"))

-- Ảnh kỷ niệm
hl.bind(mainMod .. " + M", hl.dsp.exec_cmd("qs -c study ipc call memory toggle"))

-- Wi-Fi và Bluetooth
hl.bind(mainMod .. " + N",         hl.dsp.exec_cmd("qs -c study ipc call connect wifi"))
hl.bind(mainMod .. " + SHIFT + N", hl.dsp.exec_cmd("qs -c study ipc call connect bluetooth"))

-- Menu nguồn: Ngủ / Đăng xuất / Khởi động lại / Tắt máy
hl.bind(mainMod .. " + X", hl.dsp.exec_cmd("qs -c study ipc call power toggle"))

-- Thoát Hyprland
hl.bind(mainMod .. " + SHIFT + E", hl.dsp.exec_cmd("hyprctl dispatch exit"))

------------------------------------------------------------
-- QUY TẮC CỬA SỔ
------------------------------------------------------------
hl.window_rule({ name = "float-pavucontrol", match = { class = "pavucontrol" }, float = true })
