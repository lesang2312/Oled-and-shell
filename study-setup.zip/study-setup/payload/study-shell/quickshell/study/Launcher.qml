import Quickshell
import Quickshell.Wayland
import Quickshell.Widgets
import QtQuick
import QtQuick.Layouts

// Bảng ứng dụng dạng lưới icon (Papirus-Dark)
// Gõ để tìm, phím mũi tên di chuyển, Enter mở, Esc hoặc click ra ngoài để đóng
PanelWindow {
    id: win
    property var shell

    readonly property color accent: "#89b4fa"

    visible: shell.launcherOpen
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-launcher"
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "#99000000"

    property string query: input.text.toLowerCase()

    ScriptModel {
        id: results
        values: DesktopEntries.applications.values
                .filter(a => !a.noDisplay && a.name.toLowerCase().includes(win.query))
                .sort((a, b) => a.name.localeCompare(b.name))
    }

    function close() { shell.launcherOpen = false }

    function launch() {
        const e = results.values[grid.currentIndex]
        if (e) {
            e.execute()
            close()
        }
    }

    onVisibleChanged: {
        if (visible) {
            input.text = ""
            grid.currentIndex = 0
            input.forceActiveFocus()
        }
    }

    // Click ra ngoài để đóng
    MouseArea {
        anchors.fill: parent
        onClicked: win.close()
    }

    Rectangle {
        id: panel
        width: 540
        height: 420
        anchors.centerIn: parent
        radius: 22
        color: "#f01e1e2e"
        border.color: "#585b70"
        border.width: 1

        MouseArea { anchors.fill: parent }   // chặn click xuyên xuống nền

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 12

            // Ô tìm kiếm
            Rectangle {
                Layout.fillWidth: true
                height: 44
                radius: 22
                color: "#313244"
                border.width: 1
                border.color: input.activeFocus ? win.accent : "transparent"

                Text {
                    anchors { left: parent.left; leftMargin: 16; verticalCenter: parent.verticalCenter }
                    text: "🔍"
                    font.pixelSize: 15
                }
                TextInput {
                    id: input
                    anchors { fill: parent; leftMargin: 46; rightMargin: 16 }
                    verticalAlignment: TextInput.AlignVCenter
                    color: "#cdd6f4"
                    font.pixelSize: 15
                    clip: true
                    focus: true

                    Text {
                        visible: input.text === ""
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Tìm ứng dụng…"
                        color: "#7f849c"
                        font.pixelSize: 15
                    }

                    onTextChanged: grid.currentIndex = 0
                    Keys.onPressed: e => {
                        if (e.key === Qt.Key_Escape) { win.close(); e.accepted = true }
                        else if (e.key === Qt.Key_Down) { grid.moveCurrentIndexDown(); e.accepted = true }
                        else if (e.key === Qt.Key_Up) { grid.moveCurrentIndexUp(); e.accepted = true }
                        else if (e.key === Qt.Key_Left) { grid.moveCurrentIndexLeft(); e.accepted = true }
                        else if (e.key === Qt.Key_Right) { grid.moveCurrentIndexRight(); e.accepted = true }
                        else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) { win.launch(); e.accepted = true }
                    }
                }
            }

            // Lưới ứng dụng: 5 cột
            GridView {
                id: grid
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: results
                cellWidth: Math.floor(width / 5)
                cellHeight: 96
                currentIndex: 0
                highlightMoveDuration: 0

                delegate: Item {
                    id: cell
                    required property var modelData
                    required property int index
                    readonly property bool current: GridView.isCurrentItem
                    width: grid.cellWidth
                    height: grid.cellHeight

                    Rectangle {
                        anchors.fill: parent
                        anchors.margins: 3
                        radius: 14
                        color: cell.current ? "#45475a" : "transparent"
                        border.width: 1
                        border.color: cell.current ? win.accent : "transparent"
                    }

                    Column {
                        anchors.centerIn: parent
                        spacing: 6

                        IconImage {
                            anchors.horizontalCenter: parent.horizontalCenter
                            implicitSize: 44
                            // check=true: không có icon thì để trống, không in cảnh báo
                            source: Quickshell.iconPath(cell.modelData.icon, true)
                                    || Quickshell.iconPath("application-x-executable", true)
                        }
                        Text {
                            width: cell.width - 12
                            horizontalAlignment: Text.AlignHCenter
                            elide: Text.ElideRight
                            text: cell.modelData.name
                            color: cell.current ? "#ffffff" : "#cdd6f4"
                            font.pixelSize: 11
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onEntered: grid.currentIndex = cell.index
                        onClicked: { grid.currentIndex = cell.index; win.launch() }
                    }
                }
            }
        }
    }
}
