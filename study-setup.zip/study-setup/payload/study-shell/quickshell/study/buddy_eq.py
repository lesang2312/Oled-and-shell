#!/usr/bin/env python3
"""Low-overhead PC audio spectrum sender for ESP32 OLED Buddy.

Captures the default desktop audio monitor (PipeWire/PulseAudio), computes 8
logarithmic bands with a small pure-Python FFT, and streams binary UDP packets
(`EQ1` + eight 0..15 levels) to ESP32 port 4211. It never opens the USB serial
port, so normal Buddy commands remain available while the EQ is running.
"""
import math
import os
import select
import shutil
import signal
import socket
import struct
import subprocess
import sys
import time

HOME = os.path.expanduser("~")
HOST_FILE = os.path.join(HOME, ".config/quickshell/study/buddy.host")
RATE = 16000
N = 512
PORT = 4211
SEND_EVERY = 2                 # 512 samples @ 16 kHz, send ~15.6 updates/s
BAND_EDGES = (60, 120, 240, 480, 960, 1920, 3840, 6000, 7800)


def target_host():
    host = os.environ.get("BUDDY_HOST", "").strip()
    if not host:
        try:
            with open(HOST_FILE, encoding="utf-8") as f:
                host = f.read().strip()
        except OSError:
            pass
    return host or "buddy.local"


def get_monitor_candidates():
    names = []
    pactl = shutil.which("pactl")
    if pactl:
        try:
            sink = subprocess.run([pactl, "get-default-sink"], capture_output=True,
                                  text=True, timeout=2, check=True).stdout.strip()
            if sink:
                names.append(sink + ".monitor")
        except (OSError, subprocess.SubprocessError):
            pass
    names.extend(["@DEFAULT_MONITOR@", "@DEFAULT_AUDIO_SINK@.monitor"])
    seen = set()
    return [x for x in names if not (x in seen or seen.add(x))]


def read_exact(proc, count, timeout):
    if proc.stdout is None:
        return None
    fd = proc.stdout.fileno()
    data = bytearray()
    deadline = time.monotonic() + timeout
    while len(data) < count:
        if proc.poll() is not None:
            return None
        left = deadline - time.monotonic()
        if left <= 0:
            return None
        try:
            ready, _, _ = select.select([fd], [], [], min(left, 0.25))
        except (OSError, ValueError):
            return None
        if not ready:
            continue
        try:
            chunk = os.read(fd, count - len(data))
        except BlockingIOError:
            continue
        except OSError:
            return None
        if not chunk:
            return None
        data.extend(chunk)
    return bytes(data)


def start_capture():
    """Return (process, description); try PulseAudio monitor then PipeWire."""
    errors = []
    parec = shutil.which("parec")
    if parec:
        for device in get_monitor_candidates():
            cmd = [parec, "--raw", "--format=s16le", "--rate=%d" % RATE,
                   "--channels=1", "--device=" + device]
            try:
                p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     bufsize=0, close_fds=True)
                first = read_exact(p, N * 2, 1.8)
                if first:
                    return p, "parec:" + device, first
                p.terminate()
                try:
                    p.wait(timeout=0.5)
                except subprocess.TimeoutExpired:
                    p.kill()
                errors.append("parec " + device + " không có PCM")
            except OSError as e:
                errors.append(str(e))

    pw_record = shutil.which("pw-record")
    if pw_record:
        # PipeWire target names commonly expose a monitor source for each sink.
        for device in get_monitor_candidates():
            cmd = [pw_record, "--target=" + device, "--rate=%d" % RATE,
                   "--channels=1", "--format=s16", "--raw", "-"]
            try:
                p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     bufsize=0, close_fds=True)
                first = read_exact(p, N * 2, 1.8)
                if first:
                    return p, "pw-record:" + device, first
                p.terminate()
                try:
                    p.wait(timeout=0.5)
                except subprocess.TimeoutExpired:
                    p.kill()
                errors.append("pw-record " + device + " không có PCM")
            except OSError as e:
                errors.append(str(e))
    hint = "Không lấy được âm thanh monitor. Cài pipewire-pulse (parec) hoặc PipeWire pw-record; " \
           "kiểm tra PC đang dùng PipeWire/PulseAudio."
    if errors:
        hint += " Chi tiết: " + "; ".join(errors[-3:])
    raise RuntimeError(hint)


def fft(values):
    """In-place radix-2 complex FFT, N=512; standard library only."""
    n = len(values)
    j = 0
    for i in range(1, n):
        bit = n >> 1
        while j & bit:
            j ^= bit
            bit >>= 1
        j ^= bit
        if i < j:
            values[i], values[j] = values[j], values[i]
    length = 2
    while length <= n:
        half = length >> 1
        angle = -2.0 * math.pi / length
        wlen = complex(math.cos(angle), math.sin(angle))
        for start in range(0, n, length):
            w = 1.0 + 0.0j
            for k in range(start, start + half):
                u = values[k]
                v = values[k + half] * w
                values[k] = u + v
                values[k + half] = u - v
                w *= wlen
        length <<= 1
    return values


WINDOW = [0.5 - 0.5 * math.cos(2 * math.pi * i / (N - 1)) for i in range(N)]
BAND_BINS = []
for low, high in zip(BAND_EDGES[:-1], BAND_EDGES[1:]):
    lo = max(1, int(low * N / RATE))
    hi = max(lo + 1, int(high * N / RATE))
    BAND_BINS.append((lo, min(N // 2, hi)))


def spectrum(frame, previous):
    samples = struct.unpack("<%dh" % N, frame)
    values = [complex((samples[i] / 32768.0) * WINDOW[i], 0.0) for i in range(N)]
    fft(values)
    levels = []
    for lo, hi in BAND_BINS:
        energy = 0.0
        count = max(1, hi - lo)
        for k in range(lo, hi):
            mag = (abs(values[k]) * 2.0 / N)
            energy += mag * mag
        rms = math.sqrt(energy / count)
        db = 20.0 * math.log10(max(rms, 1e-6))
        raw = max(0, min(15, int((db + 62.0) * (15.0 / 38.0) + 0.5)))
        # Faster attack, slower release keeps the bars alive without flicker.
        smooth = raw if raw >= previous[len(levels)] else int(previous[len(levels)] * 0.72 + raw * 0.28)
        levels.append(max(0, min(15, smooth)))
    return levels


def main():
    host = target_host()
    try:
        addr = socket.getaddrinfo(host, PORT, socket.AF_INET, socket.SOCK_DGRAM)[0][4]
    except OSError as e:
        print("ERROR: không phân giải được ESP32 '%s': %s" % (host, e), flush=True)
        return 3

    try:
        proc, capture_name, frame = start_capture()
    except RuntimeError as e:
        print("ERROR: " + str(e), flush=True)
        return 2

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    levels = [0] * 8
    running = True

    def stop(*_):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    print("EQ_READY %s -> %s:%d" % (capture_name, addr[0], PORT), flush=True)
    count = 0
    try:
        while running:
            if frame is None:
                frame = read_exact(proc, N * 2, 1.0)
                if frame is None:
                    if proc.poll() is not None:
                        break
                    continue
            levels = spectrum(frame, levels)
            count += 1
            if count % SEND_EVERY == 0:
                sock.sendto(b"EQ1" + bytes(levels), addr)
            frame = read_exact(proc, N * 2, 1.0)
            if frame is None and proc.poll() is not None:
                break
        try:
            sock.sendto(b"EQ0", addr)
        except OSError:
            pass
    except (BrokenPipeError, OSError) as e:
        print("ERROR: luồng EQ bị ngắt: " + str(e), flush=True)
        return 1
    finally:
        try:
            proc.terminate()
            proc.wait(timeout=0.5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        sock.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
