import Quickshell
import Quickshell.Wayland
import QtQuick

// Thẻ "nhận file từ điện thoại" kiểu Huawei Share: một vòng tròn nảy lên ở góc dưới phải cùng các vòng sóng lan ra,
// rồi bung thành thẻ có hình xem trước + nút Lưu / Bỏ qua. Không bấm gì thì thẻ tự thu lại (file vẫn chờ,
// nút nổi bên cạnh màn hình hiện số file đang chờ).
PanelWindow {
    id: win
    property var shell

    readonly property color accent: "#89b4fa"
    readonly property color fg: "#cdd6f4"
    readonly property color dim: "#9399b2"
    readonly property var pend: shell.sharePending
    readonly property int count: pend.length
    readonly property real cardW: 380
    readonly property real cardH: 346
    readonly property real pad: 40

    // 0 ẩn | 1 vòng tròn + sóng | 2 thẻ mở | 3 đang thu lại
    property int phase: 0
    property real remain: 1                         // phần còn lại của thanh đếm ngược
    readonly property bool wanted: shell.shareToastWanted && count > 0

    function totalSize() {
        let t = 0
        for (let i = 0; i < pend.length; i++) t += pend[i].size
        return t
    }
    function who() {
        if (count === 0) return ""
        const p = pend[0]
        return (p.dev !== "" ? p.dev + " · " : "") + p.from
    }

    onWantedChanged: {
        if (wanted) {
            closeTimer.stop()
            if (phase === 0 || phase === 3) { phase = 1; openTimer.restart() }
        } else if (phase === 1 || phase === 2) {
            openTimer.stop()
            countdown.stop()
            phase = 3
            closeTimer.restart()
        }
    }
    onCountChanged: if (phase === 2 && count > 0) { countdown.restart(); bump.restart() }

    Timer { id: openTimer; interval: 850; onTriggered: if (win.phase === 1) { win.phase = 2; countdown.restart() } }
    Timer { id: closeTimer; interval: 650; onTriggered: win.phase = 0 }

    NumberAnimation {
        id: countdown
        target: win
        property: "remain"
        from: 1
        to: 0
        duration: 25000
        onFinished: win.shell.shareToastWanted = false     // thu thẻ lại, file vẫn chờ
    }

    visible: phase > 0
    anchors { right: true; bottom: true }
    margins { right: 14; bottom: 14 }
    implicitWidth: cardW + pad * 2
    implicitHeight: cardH + pad * 2
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-share-toast"
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    color: "transparent"
    mask: Region { item: card }                  // chỗ trong suốt xung quanh không chặn chuột

    // ---- Các vòng sóng lan ra từ vòng tròn (giống hiệu ứng kết nối của Huawei) ----
    component Ring: Rectangle {
        id: ring
        property int delay: 0
        width: 64
        height: 64
        radius: 32
        x: win.width - win.pad - 64
        y: win.height - win.pad - 64
        color: "transparent"
        border.width: 2
        border.color: win.accent
        opacity: 0
        SequentialAnimation {
            running: win.phase === 1
            PauseAnimation { duration: ring.delay }
            ParallelAnimation {
                NumberAnimation { target: ring; property: "scale"; from: 1; to: 3.0; duration: 1000; easing.type: Easing.OutCubic }
                NumberAnimation { target: ring; property: "opacity"; from: 0.75; to: 0; duration: 1000; easing.type: Easing.OutQuad }
            }
            onRunningChanged: if (!running) { ring.opacity = 0; ring.scale = 1 }
        }
    }
    Ring { delay: 0 }
    Ring { delay: 230 }
    Ring { delay: 460 }

    // ---- Thẻ ----
    Rectangle {
        id: card
        anchors { right: parent.right; bottom: parent.bottom; rightMargin: win.pad; bottomMargin: win.pad }
        width: win.phase === 2 ? win.cardW : 64
        height: win.phase === 2 ? win.cardH : 64
        radius: win.phase === 2 ? 24 : 32
        color: win.phase === 2 ? "#1e1e2e" : win.accent
        border.width: 1
        border.color: win.phase === 2 ? "#45475a" : "transparent"
        clip: true
        scale: win.phase === 0 ? 0 : 1
        opacity: win.phase === 3 ? 0 : 1
        transformOrigin: Item.Center

        Behavior on width { NumberAnimation { duration: 480; easing.type: Easing.OutBack; easing.overshoot: 0.8 } }
        Behavior on height { NumberAnimation { duration: 480; easing.type: Easing.OutBack; easing.overshoot: 0.8 } }
        Behavior on radius { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
        Behavior on color { ColorAnimation { duration: 300 } }
        Behavior on scale { NumberAnimation { duration: 380; easing.type: Easing.OutBack; easing.overshoot: 1.6 } }
        Behavior on opacity { NumberAnimation { duration: 520 } }

        // Biểu tượng điện thoại trên vòng tròn (mờ đi khi thẻ mở)
        Text {
            anchors.centerIn: parent
            text: "📲"
            font.pixelSize: 28
            opacity: win.phase === 2 ? 0 : 1
            Behavior on opacity { NumberAnimation { duration: 180 } }
        }

        // Nội dung kích thước cố định, dính góc dưới phải, được "lộ ra" dần khi thẻ bung
        Item {
            id: content
            width: win.cardW
            height: win.cardH
            anchors { right: parent.right; bottom: parent.bottom }
            opacity: win.phase === 2 ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 320 } }

            // Tiêu đề
            Row {
                x: 18
                y: 16
                spacing: 10
                Rectangle {
                    width: 34
                    height: 34
                    radius: 17
                    color: "#313244"
                    Text { anchors.centerIn: parent; text: "📲"; font.pixelSize: 17 }
                }
                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 1
                    Text { text: "Nhận từ điện thoại"; color: win.fg; font.pixelSize: 14; font.bold: true }
                    Text {
                        text: win.who()
                        color: win.dim
                        font.pixelSize: 11
                        elide: Text.ElideRight
                        width: 250
                    }
                }
            }
            Rectangle {
                x: win.cardW - 46
                y: 16
                width: 30
                height: 30
                radius: 15
                color: closeArea.containsMouse ? "#45475a" : "transparent"
                Text { anchors.centerIn: parent; text: "✕"; color: win.dim; font.pixelSize: 13 }
                MouseArea {
                    id: closeArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: win.shell.shareToastWanted = false      // thu lại, file vẫn chờ
                }
            }

            // Xem trước: tối đa 3 file xếp chồng như chồng ảnh
            Item {
                id: fan
                x: 0
                y: 62
                width: win.cardW
                height: 176
                scale: win.phase === 2 ? 1 : 0.78
                Behavior on scale { NumberAnimation { duration: 560; easing.type: Easing.OutBack; easing.overshoot: 1.2 } }

                SequentialAnimation {
                    id: bump
                    NumberAnimation { target: fan; property: "scale"; to: 1.06; duration: 110; easing.type: Easing.OutQuad }
                    NumberAnimation { target: fan; property: "scale"; to: 1; duration: 260; easing.type: Easing.OutBack }
                }

                Repeater {
                    model: Math.min(3, win.count)
                    delegate: Rectangle {
                        id: frame
                        required property int index
                        readonly property var it: win.pend[index]
                        width: 262
                        height: 164
                        x: (fan.width - width) / 2 + index * 6
                        y: 4 + index * 4
                        z: 10 - index
                        rotation: [0, -6, 5][index]
                        radius: 12
                        color: "#181825"
                        border.width: 1
                        border.color: "#45475a"
                        clip: true

                        Image {
                            anchors { fill: parent; margins: 4 }
                            visible: !!(frame.it && frame.it.img)
                            source: (frame.it && frame.it.img) ? "file://" + frame.it.path : ""
                            fillMode: Image.PreserveAspectFit
                            asynchronous: true
                            cache: false
                            sourceSize.width: 520
                            sourceSize.height: 340
                        }
                        Column {
                            anchors.centerIn: parent
                            spacing: 6
                            visible: !!(frame.it && !frame.it.img)
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: frame.it ? win.shell.fileIcon(frame.it.name) : ""
                                font.pixelSize: 54
                            }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: frame.it ? frame.it.name : ""
                                color: win.fg
                                font.pixelSize: 12
                                width: 230
                                elide: Text.ElideMiddle
                                horizontalAlignment: Text.AlignHCenter
                            }
                        }
                    }
                }
            }

            // Số file, dung lượng
            Text {
                x: 18
                y: 244
                width: win.cardW - 36
                text: win.count + " file · " + win.shell.fmtBytes(win.totalSize())
                      + (win.count === 1 && win.pend[0] ? "  ·  " + win.pend[0].name : "")
                color: win.fg
                font.pixelSize: 12
                elide: Text.ElideMiddle
                horizontalAlignment: Text.AlignHCenter
            }

            // Nút
            Row {
                x: 18
                y: 272
                spacing: 10
                Rectangle {
                    width: 214
                    height: 44
                    radius: 22
                    color: saveArea.pressed ? Qt.darker(win.accent, 1.2) : (saveArea.containsMouse ? Qt.lighter(win.accent, 1.12) : win.accent)
                    Text { anchors.centerIn: parent; text: "Lưu vào share_png"; color: "#11111b"; font.pixelSize: 14; font.bold: true }
                    MouseArea {
                        id: saveArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: win.shell.shareFinish(true)
                    }
                }
                Rectangle {
                    width: 120
                    height: 44
                    radius: 22
                    color: skipArea.containsMouse ? "#45475a" : "#313244"
                    Text { anchors.centerIn: parent; text: "Bỏ qua"; color: win.fg; font.pixelSize: 14; font.bold: true }
                    MouseArea {
                        id: skipArea
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: win.shell.shareFinish(false)
                    }
                }
            }

            // Thanh đếm ngược
            Rectangle {
                x: 18
                y: win.cardH - 14
                width: win.cardW - 36
                height: 3
                radius: 2
                color: "#313244"
                Rectangle {
                    width: parent.width * win.remain
                    height: parent.height
                    radius: 2
                    color: win.accent
                }
            }
        }
    }
}
