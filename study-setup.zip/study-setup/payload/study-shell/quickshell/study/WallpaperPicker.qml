import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// Ô chọn hình nền: lưới ảnh xem trước, bấm để đặt. Esc hoặc click ra ngoài để đóng.
PanelWindow {
    id: win
    property var shell
    property var model          // FolderListModel chứa ảnh nền

    readonly property color accent: "#89b4fa"

    visible: shell.pickerOpen
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-wallpaper-picker"
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "#99000000"

    function close() { shell.pickerOpen = false }

    onVisibleChanged: if (visible) keys.forceActiveFocus()

    // Click ra ngoài để đóng
    MouseArea {
        anchors.fill: parent
        onClicked: win.close()
    }

    Item {
        id: keys
        focus: true
        Keys.onEscapePressed: win.close()
    }

    Rectangle {
        width: 560
        height: 400
        anchors.centerIn: parent
        radius: 22
        color: "#f01e1e2e"
        border.color: "#585b70"
        border.width: 1

        MouseArea { anchors.fill: parent }   // chặn click xuyên xuống nền

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                Text {
                    text: "🖼  Chọn hình nền"
                    color: "#cdd6f4"
                    font.pixelSize: 15
                    font.bold: true
                    Layout.fillWidth: true
                }
                Text {
                    text: (win.model ? win.model.count : 0) + " ảnh"
                    color: "#7f849c"
                    font.pixelSize: 12
                }
            }

            Text {
                visible: !win.model || win.model.count === 0
                Layout.fillWidth: true
                wrapMode: Text.WordWrap
                color: "#7f849c"
                font.pixelSize: 13
                text: "Chưa có ảnh nào. Hãy bỏ ảnh png/jpg/webp vào " + win.shell.wallDir
            }

            GridView {
                id: grid
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: win.model
                cellWidth: Math.floor(width / 3)
                cellHeight: 108

                delegate: Item {
                    id: cell
                    required property string filePath
                    required property int index
                    readonly property bool current: cell.filePath === win.shell.wallpaper
                    width: grid.cellWidth
                    height: grid.cellHeight

                    Rectangle {
                        anchors.fill: parent
                        anchors.margins: 4
                        radius: 12
                        color: "#313244"
                        border.width: cell.current || area.containsMouse ? 2 : 0
                        border.color: cell.current ? win.accent : "#cdd6f4"
                        clip: true

                        Image {
                            anchors.fill: parent
                            anchors.margins: 2
                            source: "file://" + cell.filePath
                            fillMode: Image.PreserveAspectCrop
                            asynchronous: true
                            // Giải mã nhỏ để nhẹ RAM
                            sourceSize: Qt.size(240, 150)
                        }

                        Text {
                            visible: cell.current
                            anchors { right: parent.right; top: parent.top; margins: 6 }
                            text: "✓"
                            color: win.accent
                            font.pixelSize: 16
                            font.bold: true
                        }

                        MouseArea {
                            id: area
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: win.shell.setWallpaper(cell.filePath, cell.index)
                        }
                    }
                }
            }
        }
    }
}
