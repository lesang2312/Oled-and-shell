import Quickshell
import Quickshell.Wayland
import QtQuick

// Hình nền với hiệu ứng chuyển trang trọng:
// ảnh cũ dịu xuống nhẹ, ảnh mới hiện lên chậm rãi với chuyển động rất nhẹ, không bật nảy.
PanelWindow {
    id: win
    required property var modelData
    property var shell

    // Chỉnh hiệu ứng ở đây. Đặt fadeMs = 0 để tắt.
    readonly property int fadeMs: 1900       // thời gian chuyển (ms)
    readonly property real dimTo: 0.45       // độ sáng ảnh cũ khi nhường chỗ (1 = không tối)
    readonly property real startScale: 1.025 // ảnh mới bắt đầu hơi phóng và thu về 1.0

    screen: modelData
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Background
    WlrLayershell.namespace: "qs-wallpaper"
    color: "#0b0b12"

    property string target: shell.wallpaper   // ảnh cần hiển thị
    property string shown: ""                 // ảnh đang ở lớp dưới
    property string frontPath: ""             // ảnh mới đang hiện dần ở lớp trên

    Component.onCompleted: shown = target

    onTargetChanged: {
        if (target === "" || target === shown) return
        if (shown === "" || fadeMs <= 0) { shown = target; return }   // lần đầu / tắt hiệu ứng
        frontPath = target
    }

    // Lớp dưới: ảnh hiện tại
    Image {
        id: back
        anchors.fill: parent
        source: win.shown !== "" ? "file://" + win.shown : ""
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        cache: false
        sourceSize: Qt.size(win.width, win.height)   // giải mã đúng cỡ màn hình, tiết kiệm RAM

        // Khi lớp dưới đã tải xong ảnh mới thì mới gỡ lớp trên (tránh nháy)
        onStatusChanged: {
            if (status === Image.Ready && win.frontPath !== "" && win.shown === win.frontPath) {
                front.opacity = 0
                front.scale = 1
                win.frontPath = ""
            }
        }
    }

    // Lớp trên: ảnh mới
    Image {
        id: front
        anchors.fill: parent
        opacity: 0
        source: win.frontPath !== "" ? "file://" + win.frontPath : ""
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
        cache: false
        sourceSize: Qt.size(win.width, win.height)

        onStatusChanged: if (status === Image.Ready && win.frontPath !== "") fade.restart()
    }

    ParallelAnimation {
        id: fade
        NumberAnimation {
            target: back; property: "opacity"
            to: win.dimTo
            duration: win.fadeMs; easing.type: Easing.InOutSine
        }
        NumberAnimation {
            target: front; property: "opacity"
            from: 0; to: 1
            duration: win.fadeMs; easing.type: Easing.InOutSine
        }
        NumberAnimation {
            target: front; property: "scale"
            from: win.startScale; to: 1.0
            duration: win.fadeMs; easing.type: Easing.OutSine
        }
        onFinished: {
            win.shown = win.frontPath
            back.opacity = 1          // ảnh mới đang phủ kín nên đổi lại độ sáng không bị lộ
        }
    }
}
