#!/bin/sh
# In ra "cpu%|ram%" (đo CPU trong 0,4 giây). Nhẹ, chỉ đọc /proc.
read -r _ u1 n1 s1 i1 w1 q1 sq1 _ < /proc/stat
sleep 0.4
read -r _ u2 n2 s2 i2 w2 q2 sq2 _ < /proc/stat
t1=$((u1 + n1 + s1 + i1 + w1 + q1 + sq1))
t2=$((u2 + n2 + s2 + i2 + w2 + q2 + sq2))
dt=$((t2 - t1))
di=$(((i2 + w2) - (i1 + w1)))
cpu=0
if [ "$dt" -gt 0 ]; then cpu=$(((100 * (dt - di)) / dt)); fi
mem=$(awk '/MemTotal/ {t=$2} /MemAvailable/ {a=$2} END {if (t > 0) printf "%d", (t - a) * 100 / t; else print 0}' /proc/meminfo)
echo "$cpu|$mem"
