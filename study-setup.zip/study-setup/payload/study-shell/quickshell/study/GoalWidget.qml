import Quickshell
import Quickshell.Wayland
import QtQuick

// Widget mục tiêu ở góc trên bên phải.
//  - Chuột phải: sửa mục tiêu (Enter lưu, Esc huỷ)
//  - Lần đặt đầu tiên không tính. Sau đó được sửa tối đa 10 lần, lần sửa thứ 10 xong là GHIM CỐ ĐỊNH.
// Dữ liệu lưu ở ~/.config/quickshell/study/goal.json
PanelWindow {
    id: win
    required property var modelData
    property var shell

    readonly property color gold: "#f9e2af"
    readonly property color pink: "#f5c2e7"
    readonly property color dim: "#7f849c"

    readonly property int editsLeft: shell.goalMaxEdits - shell.goalEdits
    readonly property bool pinned: shell.goalPinned
    property bool editing: false
    property string flash: ""

    screen: modelData
    visible: modelData === Quickshell.screens[0]      // chỉ hiện trên màn hình chính
    anchors { top: true; right: true }
    margins { top: 54; right: 14 }
    implicitWidth: 470
    implicitHeight: card.height
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Bottom               // nằm trên hình nền, dưới các cửa sổ
    WlrLayershell.namespace: "qs-goal"
    WlrLayershell.keyboardFocus: editing ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "transparent"

    function startEdit() {
        if (pinned) { showFlash("📌 Đã ghim cố định, không thể sửa nữa"); return }
        editor.text = shell.goalText
        editing = true
        editor.forceActiveFocus()
        editor.selectAll()
    }

    function commit() {
        shell.saveGoal(editor.text)
        editing = false
        if (shell.goalPinned) showFlash("📌 Đã ghim cố định")
    }

    function showFlash(t) { flash = t; flashTimer.restart() }
    Timer { id: flashTimer; interval: 2600; onTriggered: win.flash = "" }

    Rectangle {
        id: card
        width: parent.width
        height: col.implicitHeight + 40
        radius: 24
        color: "#d9181825"
        border.width: 1
        border.color: win.pinned ? win.gold : "#45475a"

        // Vạch màu bên trái
        Rectangle {
            anchors { left: parent.left; top: parent.top; bottom: parent.bottom; margins: 16; leftMargin: 14 }
            width: 5
            radius: 3
            gradient: Gradient {
                GradientStop { position: 0.0; color: win.pink }
                GradientStop { position: 1.0; color: win.gold }
            }
        }

        Column {
            id: col
            anchors { left: parent.left; leftMargin: 34; right: parent.right; rightMargin: 22; top: parent.top; topMargin: 20 }
            spacing: 8

            // Nhãn
            Row {
                spacing: 8
                Text {
                    text: "🎯  MỤC TIÊU"
                    color: win.pink
                    font.family: "Inter"
                    font.pixelSize: 12
                    font.weight: Font.ExtraBold
                    font.letterSpacing: 2.5
                }
                Text {
                    visible: win.pinned
                    text: "📌"
                    font.pixelSize: 12
                }
            }

            // Nội dung mục tiêu (xem)
            Text {
                visible: !win.editing
                width: col.width
                wrapMode: Text.Wrap
                text: win.shell.goalText !== "" ? win.shell.goalText : "Chuột phải để đặt mục tiêu"
                color: win.shell.goalText !== "" ? win.gold : win.dim
                font.family: "Inter"
                font.pixelSize: win.shell.goalText !== "" ? 32 : 22
                font.weight: Font.ExtraBold
                lineHeight: 1.1
            }

            // Ô sửa
            TextEdit {
                id: editor
                visible: win.editing
                width: col.width
                wrapMode: TextEdit.Wrap
                color: "#ffffff"
                selectionColor: win.pink
                selectedTextColor: "#1e1e2e"
                font.family: "Inter"
                font.pixelSize: 28
                font.weight: Font.ExtraBold
                selectByMouse: true
                Keys.onPressed: e => {
                    if (e.key === Qt.Key_Escape) {
                        win.editing = false
                        e.accepted = true
                    } else if ((e.key === Qt.Key_Return || e.key === Qt.Key_Enter) && !(e.modifiers & Qt.ShiftModifier)) {
                        win.commit()
                        e.accepted = true
                    }
                }
            }

            // Dòng gợi ý
            Text {
                width: col.width
                wrapMode: Text.Wrap
                font.family: "Inter"
                font.pixelSize: 11
                color: win.flash !== "" || (win.editing && win.editsLeft === 1 && win.shell.goalText !== "")
                       ? "#fab387" : win.dim
                text: {
                    if (win.flash !== "") return win.flash
                    if (win.editing) {
                        if (win.shell.goalText === "") return "Lần đặt đầu tiên không tính vào 10 lần sửa · Enter lưu · Esc huỷ"
                        if (win.editsLeft === 1) return "⚠ Đây là lần sửa CUỐI, lưu xong sẽ ghim cố định · Enter lưu · Esc huỷ"
                        return "Enter lưu · Esc huỷ · còn " + win.editsLeft + " lần sửa"
                    }
                    if (win.pinned) return "📌 Đã ghim cố định"
                    if (win.shell.goalText === "") return "Lần đặt đầu tiên không tính · sau đó được sửa " + win.shell.goalMaxEdits + " lần rồi ghim"
                    return "Chuột phải để sửa · còn " + win.editsLeft + "/" + win.shell.goalMaxEdits + " lần sửa"
                }
            }
        }

        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.RightButton
            enabled: !win.editing
            onClicked: win.startEdit()
        }
    }
}
