import QtQuick

// Đồng hồ Pomodoro trên bar. Trạng thái nằm trong shell.qml (một đồng hồ chung cho mọi màn hình).
// Chuột trái: chạy / dừng · Chuột phải: reset. Số "×N" là số phiên tập trung đã xong hôm nay.
Item {
    id: root
    property var shell

    implicitWidth: label.implicitWidth + 16
    implicitHeight: 24

    Text {
        id: label
        anchors.centerIn: parent
        color: shell.pomoBreak ? "#a6e3a1" : (shell.pomoRunning ? "#f38ba8" : "#cdd6f4")
        font.pixelSize: 13
        font.family: "monospace"
        text: (shell.pomoBreak ? "☕ " : "📖 ")
              + String(Math.floor(shell.pomoRemaining / 60)).padStart(2, "0") + ":"
              + String(shell.pomoRemaining % 60).padStart(2, "0")
              + (shell.pomoToday > 0 ? "  ×" + shell.pomoToday : "")
    }

    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onClicked: m => m.button === Qt.RightButton ? shell.pomoReset() : shell.pomoToggle()
    }
}
