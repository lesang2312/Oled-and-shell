#!/usr/bin/env python3
"""Máy chủ nhận file (ảnh, tài liệu, bất kỳ loại nào) từ điện thoại trong cùng mạng WiFi (chỉ dùng thư viện chuẩn của Python).

Shell (Quickshell) chạy file này nền. Điện thoại mở  http://<IP máy tính>:8765  rồi bấm "Gửi".
File được lưu TẠM vào thư mục inbox; shell hiện thẻ "Lưu / Bỏ qua", chỉ khi bấm Lưu mới chuyển vào share_png.

Giao tiếp với shell:
  stdout  mỗi dòng một JSON:  {"ev":"ready",...} | {"ev":"file",...} | {"ev":"error","msg":...}
  stdin   mỗi dòng một lệnh:  "saved <batch>" | "skipped <batch>"  (điện thoại sẽ thấy kết quả)
  stdin đóng (shell tắt) -> máy chủ tự thoát.

Dùng thử không cần shell:  python3 share.py --inbox /tmp/inbox
Mã PIN (tuỳ chọn): đặt trong file share.pin cạnh share.py hoặc biến SHARE_PIN; có PIN thì điện thoại phải nhập PIN.
"""
import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

MAX_BYTES = 500 * 1024 * 1024
OUT_LOCK = threading.Lock()
STATUS = {}                      # batch -> "pending" | "saved" | "skipped"
STATUS_LOCK = threading.Lock()
PIN = ""
INBOX = ""


def emit(obj):
    with OUT_LOCK:
        try:
            sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
            sys.stdout.flush()
        except (BrokenPipeError, ValueError):
            os._exit(0)


# ---------------------------------------------------------------- QR (phiên bản 1-6, mức sửa lỗi L)
_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]

# version: (số khối, số byte dữ liệu mỗi khối, số byte sửa lỗi mỗi khối)
_QR_VER = {1: (1, 19, 7), 2: (1, 34, 10), 3: (1, 55, 15), 4: (1, 80, 20), 5: (1, 108, 26), 6: (2, 68, 18)}
_QR_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34]}


def _gmul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


def _rs_remainder(data, n):
    g = [1]
    for i in range(n):
        ng = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            ng[j] ^= c
            ng[j + 1] ^= _gmul(c, _EXP[i])
        g = ng
    res = [0] * n
    for b in data:
        f = b ^ res[0]
        res = res[1:] + [0]
        for i in range(n):
            res[i] ^= _gmul(g[i + 1], f)
    return res


def qr_matrix(text):
    """Trả về danh sách các dòng '0'/'1' (1 = ô tối), hoặc [] nếu chữ quá dài."""
    data = text.encode("utf-8")
    ver = 0
    for v, (nb, dcw, _ec) in _QR_VER.items():
        if len(data) <= nb * dcw - 2:
            ver = v
            break
    if not ver:
        return []
    nblocks, dcw, ecw = _QR_VER[ver]
    cap = nblocks * dcw
    bits = "0100" + format(len(data), "08b") + "".join(format(b, "08b") for b in data)
    bits += "0" * min(4, cap * 8 - len(bits))
    bits += "0" * (-len(bits) % 8)
    cw = [int(bits[i:i + 8], 2) for i in range(0, len(bits), 8)]
    pad = [0xEC, 0x11]
    while len(cw) < cap:
        cw.append(pad[(len(cw) - len(bits) // 8) % 2])
    blocks = [cw[i * dcw:(i + 1) * dcw] for i in range(nblocks)]
    ecs = [_rs_remainder(b, ecw) for b in blocks]
    final = []
    for i in range(dcw):
        for b in blocks:
            final.append(b[i])
    for i in range(ecw):
        for e in ecs:
            final.append(e[i])
    size = 17 + 4 * ver
    mod = [[False] * size for _ in range(size)]
    fn = [[False] * size for _ in range(size)]

    def setf(x, y, v):
        mod[y][x] = v
        fn[y][x] = True

    for i in range(size):
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                xx, yy = cx + dx, cy + dy
                if 0 <= xx < size and 0 <= yy < size:
                    setf(xx, yy, max(abs(dx), abs(dy)) not in (2, 4))
    pos = _QR_ALIGN[ver]
    for i, py in enumerate(pos):
        for j, px in enumerate(pos):
            if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) or (i == len(pos) - 1 and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(px + dx, py + dy, max(abs(dx), abs(dy)) != 1)

    def put_format(mask):
        d = (1 << 3) | mask                      # mức L = 01
        rem = d
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        fb = ((d << 10) | rem) ^ 0x5412
        bit = lambda i: ((fb >> i) & 1) != 0
        for i in range(6):
            setf(8, i, bit(i))
        setf(8, 7, bit(6))
        setf(8, 8, bit(7))
        setf(7, 8, bit(8))
        for i in range(9, 15):
            setf(14 - i, 8, bit(i))
        for i in range(8):
            setf(size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            setf(8, size - 15 + i, bit(i))
        setf(8, size - 8, True)

    put_format(0)                                # đánh dấu vùng chức năng trước khi đặt dữ liệu
    i = 0
    right = size - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                upward = ((right + 1) & 2) == 0
                y = size - 1 - vert if upward else vert
                if not fn[y][x] and i < len(final) * 8:
                    mod[y][x] = ((final[i >> 3] >> (7 - (i & 7))) & 1) != 0
                    i += 1
        right -= 2

    masks = (lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
             lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
             lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
             lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0)

    def penalty(m):
        p = 0
        for grid in (m, [list(r) for r in zip(*m)]):
            for row in grid:
                run = 1
                for k in range(1, size):
                    if row[k] == row[k - 1]:
                        run += 1
                    else:
                        if run >= 5:
                            p += 3 + run - 5
                        run = 1
                if run >= 5:
                    p += 3 + run - 5
        for y in range(size - 1):
            for x in range(size - 1):
                if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    p += 3
        dark = sum(r.count(True) for r in m)
        p += (abs(dark * 20 - size * size * 10) // (size * size)) * 10
        return p

    best, best_m, best_p = 0, None, None
    for mk in range(8):
        m = [row[:] for row in mod]
        f = masks[mk]
        for y in range(size):
            for x in range(size):
                if not fn[y][x] and f(x, y):
                    m[y][x] = not m[y][x]
        pen = penalty(m)
        if best_p is None or pen < best_p:
            best, best_m, best_p = mk, m, pen
    mod = best_m
    put_format(best)
    return ["".join("1" if c else "0" for c in row) for row in mod]


# ---------------------------------------------------------------- mạng / tệp
def lan_ips():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))          # không gửi gói nào, chỉ để hệ điều hành chọn card mạng
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        out = subprocess.run(["ip", "-4", "-o", "addr", "show", "scope", "global"], capture_output=True,
                             text=True, timeout=3).stdout
        for m in re.finditer(r"inet (\d+\.\d+\.\d+\.\d+)/", out):
            if m.group(1) not in ips:
                ips.append(m.group(1))
    except (OSError, subprocess.SubprocessError):
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if not ip.startswith("127.") and ip not in ips:
                ips.append(ip)
    except OSError:
        pass
    return [i for i in ips if not i.startswith("127.")] or ["127.0.0.1"]


def sniff(head):
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    return ""


def safe_name(orig, kind, stamp):
    """Tên file an toàn: bỏ đường dẫn, ký tự lạ; ảnh thì ép đuôi đúng với nội dung thật."""
    name = os.path.basename(orig.replace("\\", "/"))
    stem, ext = os.path.splitext(name)
    stem = re.sub(r"[^\w\-. ()]", "_", stem, flags=re.UNICODE).strip(" ._")[:80]
    ext = re.sub(r"[^A-Za-z0-9]", "", ext)[:10].lower()
    if kind:
        ext = kind
    if not stem or stem.lower() in ("image", "photo", "blob", "img", "download", "unknown", "file"):
        stem = ("anh-" if kind else "file-") + stamp
    return stem + ("." + ext if ext else "")


def device_name(ua):
    m = re.search(r"Android[^;)]*;\s*([^;)]+?)(?:\sBuild|[;)])", ua)
    if m and m.group(1).strip() and m.group(1).strip() != "K":
        return m.group(1).strip()[:30]
    for key in ("iPhone", "iPad", "Android", "Windows", "Macintosh", "Linux"):
        if key in ua:
            return key
    return ""


def clean_old(inbox):
    now = time.time()
    try:
        for d in os.listdir(inbox):
            p = os.path.join(inbox, d)
            if os.path.isdir(p) and now - os.path.getmtime(p) > 12 * 3600:
                shutil.rmtree(p, ignore_errors=True)
    except OSError:
        pass


PAGE = r"""<!doctype html>
<html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#11111b"><title>Gửi file sang máy tính</title>
<style>
:root{--bg:#11111b;--card:#1e1e2e;--line:#313244;--fg:#cdd6f4;--dim:#9399b2;--ac:#89b4fa;--ok:#a6e3a1;--bad:#f38ba8}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:radial-gradient(120% 60% at 50% 0,#1b1d33 0,var(--bg) 60%) fixed;color:var(--fg);
 font:16px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;min-height:100vh;
 padding:max(18px,env(safe-area-inset-top)) 16px max(24px,env(safe-area-inset-bottom))}
main{max-width:520px;margin:0 auto}
h1{font-size:22px;margin:6px 0 2px}.sub{color:var(--dim);font-size:14px;margin:0 0 18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:22px;padding:16px;margin-bottom:14px}
.drop{border:2px dashed #45475a;border-radius:18px;padding:26px 12px;text-align:center;color:var(--dim)}
.drop.on{border-color:var(--ac);background:#89b4fa14}
.row{display:flex;gap:10px;margin-top:12px}
button,label.btn{flex:1;border:0;border-radius:16px;padding:15px 12px;font:600 16px system-ui;color:var(--fg);
 background:#313244;text-align:center;cursor:pointer;display:block}
button.pri{background:var(--ac);color:#11111b}button:disabled{opacity:.45}
input[type=file]{display:none}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:14px}
.th{position:relative;aspect-ratio:1;border-radius:14px;overflow:hidden;background:#181825}
.th img{width:100%;height:100%;object-fit:cover}
.th b{position:absolute;top:4px;right:4px;width:26px;height:26px;border-radius:50%;background:#000a;color:#fff;
 text-align:center;line-height:26px;font-size:15px}
.bar{height:8px;border-radius:4px;background:#313244;overflow:hidden;margin-top:14px;display:none}
.bar i{display:block;height:100%;width:0;background:var(--ac);transition:width .15s}
#msg{margin-top:12px;text-align:center;min-height:24px}.ok{color:var(--ok)}.bad{color:var(--bad)}
.pair{display:flex;align-items:center;gap:14px}.pair img{width:112px;height:112px;background:#fff;border-radius:12px;padding:5px;image-rendering:pixelated;flex:none}
.pair code{font:600 13px/1.5 ui-monospace,monospace;color:var(--ac);overflow-wrap:anywhere}
input[type=password],input[type=text]{width:100%;border:1px solid var(--line);background:#181825;color:var(--fg);
 border-radius:14px;padding:13px;font-size:17px;text-align:center;letter-spacing:4px}
@media(max-width:360px){.pair{gap:8px}.pair img{width:92px;height:92px}}
</style></head><body><main>
<h1>📲 Gửi file sang máy tính</h1>
<p class="sub" id="host">Cùng mạng WiFi với máy tính</p>
<div class="card"><div class="sub">Địa chỉ chia sẻ local · quét để mở trang này trên thiết bị khác</div>
 <div class="pair"><img src="/qr.svg" alt="QR chia sẻ local"><code id="localurl">Đang tải địa chỉ…</code></div>
</div>
<div class="card" id="pinbox" style="display:none"><div class="sub">Nhập mã PIN hiển thị trên máy tính</div>
<input id="pin" type="password" inputmode="numeric" autocomplete="off" placeholder="••••"></div>
<div class="card">
 <div class="drop" id="drop">Chọn file hoặc chụp ảnh mới<br><small>Ảnh, tài liệu, video… mọi loại file, tối đa 500 MB mỗi file</small></div>
 <div class="row">
  <label class="btn" for="f1">📁 Chọn file</label>
  <label class="btn" for="f2">📷 Chụp ảnh</label>
 </div>
 <input id="f1" type="file" multiple><input id="f2" type="file" accept="image/*" capture="environment">
 <div class="grid" id="grid"></div>
 <div class="bar" id="bar"><i id="fill"></i></div>
 <div class="row"><button class="pri" id="send" disabled>Gửi</button></div>
 <div id="msg"></div>
</div></main>
<script>
const $=id=>document.getElementById(id);
let files=[],pinNeeded=false;
const MAX=500*1024*1024;
try{$('pin').value=localStorage.getItem('sharepin')||''}catch(e){}
fetch('/info').then(r=>r.json()).then(j=>{pinNeeded=j.pin;$('pinbox').style.display=j.pin?'block':'none';
 if(j.name)$('host').textContent='Gửi tới máy tính "'+j.name+'" trong cùng WiFi';
 if(j.url)$('localurl').textContent=j.url}).catch(()=>{$('localurl').textContent=location.origin});
function say(t,c){$('msg').textContent=t;$('msg').className=c||''}
function render(){
 const g=$('grid');g.innerHTML='';
 files.forEach((f,i)=>{const d=document.createElement('div');d.className='th';
  if(/^image\//.test(f.type)){const im=document.createElement('img');im.src=URL.createObjectURL(f);d.appendChild(im)}
  else{const t=document.createElement('div');t.style.cssText='height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:12px;color:#9399b2;padding:6px;text-align:center;word-break:break-all';
   t.innerHTML='<div style="font-size:28px">📄</div>';t.appendChild(document.createTextNode(f.name.slice(-18)));d.appendChild(t)}
  const x=document.createElement('b');x.textContent='×';x.onclick=()=>{files.splice(i,1);render()};d.appendChild(x);g.appendChild(d)});
 $('send').disabled=!files.length;$('send').textContent=files.length?'Gửi '+files.length+' file':'Gửi';
}
function add(list){
 for(const f of list){
  if(f.size>MAX){say(f.name+' lớn hơn 500 MB','bad');continue}
  files.push(f)}
 render()}
$('f1').onchange=e=>{add(e.target.files);e.target.value=''};
$('f2').onchange=e=>{add(e.target.files);e.target.value=''};
const dr=$('drop');
['dragover','dragenter'].forEach(n=>dr.addEventListener(n,e=>{e.preventDefault();dr.classList.add('on')}));
['dragleave','drop'].forEach(n=>dr.addEventListener(n,e=>{e.preventDefault();dr.classList.remove('on')}));
dr.addEventListener('drop',e=>add(e.dataTransfer.files));
function one(f,batch,pr){return new Promise((ok,no)=>{
 const x=new XMLHttpRequest();x.open('POST','/up');
 x.setRequestHeader('X-Name',encodeURIComponent(f.name||'image'));x.setRequestHeader('X-Batch',batch);
 if(pinNeeded)x.setRequestHeader('X-Pin',$('pin').value);
 x.upload.onprogress=e=>{if(e.lengthComputable)pr(e.loaded/e.total)};
 x.onload=()=>{if(x.status==200)ok();else{let m='Lỗi '+x.status;try{m=JSON.parse(x.responseText).error||m}catch(e){}no(new Error(m))}};
 x.onerror=()=>no(new Error('Mất kết nối tới máy tính'));x.send(f)})}
$('send').onclick=async()=>{
 if(!files.length)return;
 try{if(pinNeeded)localStorage.setItem('sharepin',$('pin').value)}catch(e){}
 const batch=Date.now().toString(36)+Math.random().toString(36).slice(2,8);
 $('send').disabled=true;$('bar').style.display='block';say('Đang gửi…');
 const n=files.length;
 try{
  for(let i=0;i<n;i++){await one(files[i],batch,p=>{$('fill').style.width=((i+p)/n*100)+'%'});say('Đã gửi '+(i+1)+'/'+n)}
  $('fill').style.width='100%';files=[];render();say('Đã gửi ✓ — chờ máy tính nhận…','ok');poll(batch,0)
 }catch(e){say(e.message,'bad');$('send').disabled=!files.length}
 setTimeout(()=>{$('bar').style.display='none';$('fill').style.width='0'},1200)};
function poll(b,k){
 fetch('/s/'+b).then(r=>r.json()).then(j=>{
  if(j.state=='saved')say('Máy tính đã lưu ✓','ok');
  else if(j.state=='skipped')say('Máy tính đã bỏ qua','bad');
  else if(k<90)setTimeout(()=>poll(b,k+1),1000);
  else say('Đã gửi ✓','ok')}).catch(()=>{})}
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    timeout = 60
    server_version = "qs-share"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _err(self, code, msg):
        self._send(code, json.dumps({"ok": False, "error": msg}, ensure_ascii=False))

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            self._send(200, PAGE, "text/html; charset=utf-8")
        elif path == "/info":
            self._send(200, json.dumps({"pin": bool(PIN), "name": socket.gethostname(),
                                        "url": getattr(self.server, "share_url", "")}))
        elif path == "/qr.svg":
            matrix = getattr(self.server, "share_qr", [])
            if not matrix:
                self._err(503, "Chua tao ma QR")
                return
            n = len(matrix)
            quiet = 4
            size = n + quiet * 2
            paths = []
            for y, row in enumerate(matrix):
                for x, bit in enumerate(row):
                    if bit == "1":
                        paths.append("M%d %dh1v1h-1z" % (x + quiet, y + quiet))
            svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" shape-rendering="crispEdges">'
                   '<rect width="100%%" height="100%%" fill="#fff"/><path d="%s" fill="#000"/></svg>') % (size, size, "".join(paths))
            self._send(200, svg, "image/svg+xml; charset=utf-8")
        elif path.startswith("/s/"):
            b = re.sub(r"[^A-Za-z0-9]", "", path[3:])[:24]
            with STATUS_LOCK:
                st = STATUS.get(b, "none")
            self._send(200, json.dumps({"state": st}))
        elif path == "/favicon.ico":
            self._send(204, b"", "image/x-icon")
        else:
            self._err(404, "Không có trang này")

    def do_POST(self):
        if urlparse(self.path).path != "/up":
            self._err(404, "Không có trang này")
            return
        if PIN and self.headers.get("X-Pin", "") != PIN:
            self.close_connection = True
            self._err(403, "Sai mã PIN")
            return
        try:
            length = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            length = -1
        if length <= 0:
            self.close_connection = True
            self._err(411, "Thiếu dữ liệu file")
            return
        if length > MAX_BYTES:
            self.close_connection = True
            self._err(413, "File lớn hơn 500 MB")
            return
        batch = re.sub(r"[^A-Za-z0-9]", "", self.headers.get("X-Batch", ""))[:24] or uuid.uuid4().hex[:10]
        orig = unquote(self.headers.get("X-Name", "image"))[:200]
        item_dir = os.path.join(INBOX, uuid.uuid4().hex[:10])
        os.makedirs(item_dir, exist_ok=True)
        part = os.path.join(item_dir, ".part")
        kind, left, size, first = "", length, 0, True
        try:
            with open(part, "wb") as fh:
                while left > 0:
                    chunk = self.rfile.read(min(left, 1 << 20))
                    if not chunk:
                        raise ConnectionError("đứt kết nối")
                    if first:
                        kind = sniff(chunk[:16])
                        first = False
                    fh.write(chunk)
                    left -= len(chunk)
                    size += len(chunk)
        except (OSError, ConnectionError):
            shutil.rmtree(item_dir, ignore_errors=True)
            self.close_connection = True
            return
        stamp = time.strftime("%Y%m%d-%H%M%S")
        name = safe_name(orig, kind, stamp)
        final = os.path.join(item_dir, name)
        os.replace(part, final)
        with STATUS_LOCK:
            STATUS[batch] = "pending"
            while len(STATUS) > 200:
                STATUS.pop(next(iter(STATUS)))
        emit({"ev": "file", "batch": batch, "path": final, "dir": item_dir, "name": name, "size": size, "img": bool(kind),
              "from": self.client_address[0], "dev": device_name(self.headers.get("User-Agent", ""))})
        self._send(200, json.dumps({"ok": True}))


def stdin_loop():
    try:
        for line in sys.stdin:
            parts = line.strip().split()
            if len(parts) == 2 and parts[0] in ("saved", "skipped"):
                with STATUS_LOCK:
                    STATUS[parts[1]] = parts[0]
    except (OSError, ValueError):
        pass
    os._exit(0)                                  # shell đã tắt -> thoát theo


def main():
    global PIN, INBOX
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=int(os.environ.get("SHARE_PORT", "8765")))
    ap.add_argument("--inbox", default=os.path.expanduser("~/.cache/qs-study/share-inbox"))
    ap.add_argument("--no-stdin", action="store_true", help="không đọc stdin (chạy tay)")
    a = ap.parse_args()
    INBOX = os.path.abspath(a.inbox)
    os.makedirs(INBOX, exist_ok=True)
    clean_old(INBOX)
    PIN = os.environ.get("SHARE_PIN", "")
    if not PIN:
        try:
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "share.pin"), encoding="utf-8") as fh:
                PIN = fh.read().strip()[:16]
        except OSError:
            pass
    srv = None
    for port in range(a.port, a.port + 10):
        try:
            ThreadingHTTPServer.daemon_threads = True
            ThreadingHTTPServer.allow_reuse_address = True
            srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
            break
        except OSError:
            continue
    if srv is None:
        emit({"ev": "error", "msg": "Không mở được cổng %d-%d (đang bị chiếm?)" % (a.port, a.port + 9)})
        sys.exit(2)
    ips = lan_ips()
    url = "http://%s:%d" % (ips[0], srv.server_address[1])
    srv.share_url = url
    srv.share_qr = qr_matrix(url)
    emit({"ev": "ready", "port": srv.server_address[1], "ips": ips, "url": url, "qr": srv.share_qr,
          "pin": bool(PIN)})
    if not a.no_stdin and not sys.stdin.isatty():
        threading.Thread(target=stdin_loop, daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
