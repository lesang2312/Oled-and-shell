#!/bin/sh
# In ra một dòng "trạng_thái|tên_mạng"
#   online  = có Internet      portal = mạng cần đăng nhập (Wi-Fi công cộng)
#   nonet   = đã nối mạng nhưng không ra được Internet
#   offline = chưa nối mạng nào    unknown = không kiểm tra được (thiếu curl)
w=$(nmcli -t -f TYPE,STATE,CONNECTION device 2>/dev/null | grep -E "^(wifi|ethernet):connected:" | head -n 1)
if [ -z "$w" ]; then echo "offline|"; exit 0; fi
name="${w#*:connected:}"
if ! command -v curl >/dev/null 2>&1; then echo "unknown|$name"; exit 0; fi

code=$(curl -s -m 4 -o /dev/null -w "%{http_code}" http://connectivitycheck.gstatic.com/generate_204 2>/dev/null)
# Dự phòng khi trang của Google bị chặn
if [ -z "$code" ] || [ "$code" = "000" ]; then
  code2=$(curl -s -m 4 -o /dev/null -w "%{http_code}" http://detectportal.firefox.com/success.txt 2>/dev/null)
  if [ "$code2" = "200" ]; then code=204; fi
fi

case "$code" in
  204)    echo "online|$name" ;;
  000|"") echo "nonet|$name" ;;
  *)      echo "portal|$name" ;;
esac
