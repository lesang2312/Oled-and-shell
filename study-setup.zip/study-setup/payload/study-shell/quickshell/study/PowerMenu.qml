import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// Menu nguồn: Ngủ / Đăng xuất / Khởi động lại / Tắt máy
// Ngủ chạy ngay. Ba nút còn lại bấm lần 1 để chọn, bấm lần 2 (hoặc Enter) để xác nhận.
// Đăng xuất (restart sddm) cần quyền root: hiện ô nhập mật khẩu.
// Phím nhanh: S, L, R, P. Esc hoặc click ra ngoài để đóng.
PanelWindow {
    id: win
    property var shell

    visible: shell.powerOpen
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-power"
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "#b3000000"

    property string armed: ""        // nút đang chờ xác nhận
    property bool askPass: false     // đang hiện ô nhập mật khẩu root
    property var passAction: null    // hành động cần root
    property string errorText: ""
    property bool busy: false

    // "Nhớ": lần đầu nhập đúng mật khẩu, tạo quy tắc sudoers chỉ cho phép đúng lệnh
    // `systemctl restart sddm` không cần mật khẩu (file /etc/sudoers.d/qs-study-sddm).
    // Mật khẩu KHÔNG được lưu ở đâu cả. Xoá quy tắc: sudo rm /etc/sudoers.d/qs-study-sddm
    property bool remember: true
    property string pendingPass: ""     // mật khẩu đang gửi cho sudo (xoá ngay sau khi gửi)

    readonly property string rememberScript:
        'u="${SUDO_USER:-$1}"; sc=$(command -v systemctl); f=/etc/sudoers.d/qs-study-sddm\n' +
        'printf \'%s ALL=(root) NOPASSWD: %s restart sddm\\n\' "$u" "$sc" > "$f.tmp" ' +
        '&& chmod 440 "$f.tmp" && visudo -cf "$f.tmp" >/dev/null && mv "$f.tmp" "$f" || rm -f "$f.tmp"\n' +
        'exec "$sc" restart sddm'

    readonly property var actions: [
        { id: "lock",     icon: "🔒", label: "Khoá màn hình", color: "#a6e3a1", confirm: false, key: Qt.Key_K,
          cmd: ["sh", "-c", "command -v hyprlock >/dev/null 2>&1 && exec hyprlock || exec loginctl lock-session"] },
        { id: "sleep",    icon: "🌙", label: "Ngủ",           color: "#89b4fa", confirm: false, key: Qt.Key_S,
          cmd: ["systemctl", "suspend"] },
        // root: true -> cần mật khẩu root (chạy qua sudo -S)
        { id: "logout",   icon: "🚪", label: "Đăng xuất",     color: "#f9e2af", confirm: true,  key: Qt.Key_L, root: true,
          cmd: ["systemctl", "restart", "sddm"] },
        { id: "reboot",   icon: "🔄", label: "Khởi động lại", color: "#fab387", confirm: true,  key: Qt.Key_R,
          cmd: ["systemctl", "reboot"] },
        { id: "poweroff", icon: "⏻",  label: "Tắt máy",       color: "#f38ba8", confirm: true,  key: Qt.Key_P,
          cmd: ["systemctl", "poweroff"] }
    ]

    function reset() {
        if (busy) return            // đang gửi mật khẩu thì không reset giữa chừng
        armed = ""
        askPass = false
        passAction = null
        errorText = ""
        passField.text = ""
    }

    function close() { reset(); shell.powerOpen = false }

    function run(a) {
        if (a.confirm && armed !== a.id) { armed = a.id; return }   // lần 1: chỉ đánh dấu
        if (a.root) {                                               // cần root
            passAction = a
            errorText = ""
            // Thử chạy không cần mật khẩu (có quy tắc sudoers từ lần trước thì chạy luôn)
            trySudo.command = ["sudo", "-n"].concat(a.cmd)
            trySudo.running = true
            return
        }
        const cmd = a.cmd
        close()
        Quickshell.execDetached(cmd)
    }

    // Gửi mật khẩu qua stdin của sudo -S (không đưa vào dòng lệnh, không ghi ra file)
    function submitPassword() {
        if (busy || passField.text === "" || !passAction) return
        const p = passField.text
        passField.text = ""
        send(p)
    }

    function send(p) {
        if (busy || !passAction) return
        busy = true
        errorText = ""
        pendingPass = p
        const base = ["sudo", "-S", "-k", "-p", ""]
        sudo.command = remember
            ? base.concat(["sh", "-c", rememberScript, "sh", Quickshell.env("USER")])
            : base.concat(passAction.cmd)
        sudo.running = true
    }

    // Thử `sudo -n`: thành công thì xong, thất bại thì hiện ô nhập mật khẩu
    Process {
        id: trySudo
        onExited: (code, status) => {
            if (code === 0) {
                win.close()
            } else {
                win.askPass = true
                passField.text = ""
                passField.forceActiveFocus()
            }
        }
    }

    Process {
        id: sudo
        stdinEnabled: true
        stderr: StdioCollector { id: sudoErr }
        onStarted: {
            write(win.pendingPass + "\n")
            win.pendingPass = ""
        }
        onExited: (code, status) => {
            win.busy = false
            win.pendingPass = ""
            if (code === 0) {
                win.close()
            } else {
                win.askPass = true
                win.errorText = "Sai mật khẩu hoặc lệnh bị từ chối"
                passField.text = ""
                passField.forceActiveFocus()
            }
        }
    }

    onVisibleChanged: {
        reset()
        if (visible) keys.forceActiveFocus()
    }

    // Click ra ngoài để đóng
    MouseArea {
        anchors.fill: parent
        onClicked: win.close()
    }

    Item {
        id: keys
        focus: true
        Keys.onPressed: e => {
            if (win.askPass) return
            if (e.key === Qt.Key_Escape) { win.close(); e.accepted = true; return }
            if ((e.key === Qt.Key_Return || e.key === Qt.Key_Enter) && win.armed !== "") {
                for (const a of win.actions) if (a.id === win.armed) win.run(a)
                e.accepted = true
                return
            }
            for (const a of win.actions) {
                if (e.key === a.key) { win.run(a); e.accepted = true; return }
            }
        }
    }

    Rectangle {
        anchors.centerIn: parent
        width: Math.max(row.implicitWidth + 40, 420)
        height: win.askPass ? 240 : 190
        radius: 24
        color: "#f01e1e2e"
        border.color: "#585b70"
        border.width: 1

        MouseArea { anchors.fill: parent }   // chặn click xuyên xuống nền

        // ---------- Chọn hành động ----------
        Column {
            visible: !win.askPass
            anchors.centerIn: parent
            spacing: 14

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: win.armed === "" ? "Nguồn" : "Bấm lần nữa để xác nhận"
                color: win.armed === "" ? "#cdd6f4" : "#f38ba8"
                font.pixelSize: 14
                font.bold: true
            }

            Row {
                id: row
                spacing: 12

                Repeater {
                    model: win.actions
                    delegate: Rectangle {
                        id: btn
                        required property var modelData
                        readonly property bool isArmed: win.armed === modelData.id
                        width: 96
                        height: 100
                        radius: 16
                        color: isArmed ? Qt.rgba(modelData.color.r, modelData.color.g, modelData.color.b, 0.35)
                               : (area.containsMouse ? "#45475a" : "#313244")
                        border.width: isArmed || area.containsMouse ? 2 : 0
                        border.color: modelData.color
                        Behavior on color { ColorAnimation { duration: 100 } }

                        Column {
                            anchors.centerIn: parent
                            spacing: 8
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: btn.modelData.icon
                                font.pixelSize: 30
                                color: btn.modelData.color
                            }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: btn.modelData.label
                                color: "#cdd6f4"
                                font.pixelSize: 12
                            }
                        }

                        MouseArea {
                            id: area
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: win.run(btn.modelData)
                        }
                    }
                }
            }
        }

        // ---------- Ô nhập mật khẩu root ----------
        Column {
            visible: win.askPass
            anchors.centerIn: parent
            width: parent.width - 48
            spacing: 12

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: "🔑  Nhập mật khẩu root"
                color: "#cdd6f4"
                font.pixelSize: 15
                font.bold: true
            }

            Rectangle {
                width: parent.width
                height: 44
                radius: 22
                color: "#313244"
                border.width: 1
                border.color: win.errorText !== "" ? "#f38ba8" : (passField.activeFocus ? "#89b4fa" : "transparent")

                TextInput {
                    id: passField
                    anchors { fill: parent; leftMargin: 18; rightMargin: 18 }
                    verticalAlignment: TextInput.AlignVCenter
                    echoMode: TextInput.Password
                    passwordCharacter: "•"
                    color: "#cdd6f4"
                    font.pixelSize: 15
                    clip: true
                    enabled: !win.busy

                    Text {
                        visible: passField.text === ""
                        anchors.verticalCenter: parent.verticalCenter
                        text: win.busy ? "Đang xác thực…" : "Mật khẩu…"
                        color: "#7f849c"
                        font.pixelSize: 15
                    }

                    onTextChanged: win.errorText = ""
                    Keys.onPressed: e => {
                        if (e.key === Qt.Key_Escape) {
                            win.askPass = false          // quay lại chọn hành động
                            win.passAction = null
                            passField.text = ""
                            keys.forceActiveFocus()
                            e.accepted = true
                        } else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) {
                            win.submitPassword()
                            e.accepted = true
                        }
                    }
                }
            }

            // Ô tích "nhớ cho lần sau"
            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 8
                Rectangle {
                    width: 18; height: 18; radius: 5
                    color: win.remember ? "#89b4fa" : "transparent"
                    border.width: 1; border.color: "#89b4fa"
                    Text { anchors.centerIn: parent; visible: win.remember; text: "✓"; color: "#1e1e2e"; font.pixelSize: 13; font.bold: true }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: win.remember = !win.remember }
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Nhớ cho lần sau (không cần nhập lại)"
                    color: "#cdd6f4"; font.pixelSize: 12
                    MouseArea { anchors.fill: parent; onClicked: win.remember = !win.remember }
                }
            }

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: win.errorText !== "" ? win.errorText
                      : "Enter để xác nhận · Esc để quay lại"
                color: win.errorText !== "" ? "#f38ba8" : "#7f849c"
                font.pixelSize: 12
            }
        }
    }
}
