import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Widgets
import QtQuick

// Dynamic Island: viên thuốc ở giữa trên cùng, co giãn kiểu lò xo (có nảy).
//  - Nghỉ:       giờ + ngày (thêm ảnh bìa + sóng nhạc khi đang phát, đồng hồ Pomodoro khi đang chạy)
//  - Thông báo:  mọi thông báo hệ thống (notify-send, Discord, trình duyệt...) hiện ở đây. Bấm = mở, chuột phải = bỏ
//  - Nhạc:       đổi bài / bắt đầu phát thì bung ra ảnh bìa + tên bài + nghệ sĩ
//  - Sự kiện:    chỉnh âm lượng / độ sáng, đổi nền, Pomodoro, mạng, chế độ tập trung
//  - Thẻ nhanh:  bấm vào island hoặc Win+I. Có điều khiển nhạc, thanh trượt âm lượng + độ sáng, Pomodoro, mục tiêu
PanelWindow {
    id: win
    required property var modelData
    property var shell

    readonly property color fg: "#cdd6f4"
    readonly property color dim: "#8a8fa8"
    readonly property color line: "#1f1f2b"

    screen: modelData
    visible: modelData === Quickshell.screens[0]       // chỉ hiện trên màn hình chính
    anchors { top: true }
    margins { top: 6 }
    implicitWidth: 500
    implicitHeight: 460                                 // dư chỗ cho thẻ nhanh + độ nảy
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Top
    WlrLayershell.namespace: "qs-island"
    color: "transparent"
    mask: Region { item: pill }                         // chỉ phần island nhận chuột, còn lại click xuyên qua

    // ---------------- Trạng thái ----------------
    readonly property var pl: shell.player
    readonly property bool hasMusic: pl !== null && pl !== undefined
    readonly property bool playing: hasMusic && pl.isPlaying
    readonly property var sink: shell.sink

    property string flash: ""                           // "", "event", "notif", "music"
    readonly property string mode: shell.islandPeek ? "peek" : (flash !== "" ? flash : "idle")

    function mmss(s) {
        s = Math.max(0, Math.floor(s))
        return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0")
    }
    function clock_(s) {                                // 3:07 (cho thanh tiến trình nhạc)
        s = Math.max(0, Math.floor(s))
        return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0")
    }

    function startFlash(kind, ms) {
        flash = kind
        flashTimer.interval = ms
        flashTimer.restart()
        pop.restart()
    }
    function endFlash() {
        if (flash === "notif") shell.releaseNotif()
        flash = ""
    }

    function showEvent() {
        if (shell.islandPeek || flash === "notif") return          // thẻ nhanh đã có thanh trượt; thông báo được ưu tiên
        startFlash("event", shell.islandValue >= 0 ? 1600 : 2800)
    }
    function showNotif() {
        shell.islandPeek = false                                   // thông báo luôn được thấy
        startFlash("notif", shell.nCritical ? 9000 : 5500)
    }
    function showMusic() {
        if (shell.islandPeek || flash === "notif" || flash === "event") return
        startFlash("music", 3800)
    }

    Timer { id: flashTimer; onTriggered: win.endFlash() }

    Connections {
        target: win.shell
        function onIslandSeqChanged() { win.showEvent() }
        function onNotifSeqChanged() { win.showNotif() }
    }

    // Đổi bài / bấm phát -> bung ra tên bài
    Connections {
        target: win.pl
        ignoreUnknownSignals: true
        function onTrackTitleChanged() { musicDebounce.restart() }
        function onIsPlayingChanged() { if (win.pl && win.pl.isPlaying) musicDebounce.restart() }
    }
    Timer {
        id: musicDebounce
        interval: 600
        onTriggered: if (win.shell.islandReady && win.playing && win.pl.trackTitle !== "") win.showMusic()
    }

    // Thẻ nhanh tự thu lại sau 12 giây nếu không rê chuột vào
    Timer {
        interval: 12000
        running: win.shell.islandPeek && !hover.hovered
        onTriggered: win.shell.islandPeek = false
    }

    // Cập nhật vị trí bài hát mỗi giây khi thẻ nhanh đang mở
    Timer {
        interval: 1000
        repeat: true
        triggeredOnStart: true
        running: win.mode === "peek" && win.playing
        onTriggered: win.pl.positionChanged()
    }

    onModeChanged: if (mode === "peek") peekPop.restart()

    SystemClock { id: clock; precision: SystemClock.Minutes }

    // ---------------- Vị trí chuột toàn màn hình (cho đôi mắt) ----------------
    // Wayland không cho ứng dụng biết chuột ở đâu ngoài cửa sổ của nó, nên hỏi Hyprland (hyprctl cursorpos).
    // Chỉ chạy khi island đang nghỉ, ~14 lần/giây.
    property real curX: 0
    property real curY: 0
    property bool curMoving: false           // chuột vừa di chuyển trong 6 giây qua -> mắt nhìn theo

    function onCursor(line) {
        const p = line.split(",")
        if (p.length < 2) return
        const x = parseFloat(p[0]), y = parseFloat(p[1])
        if (isNaN(x) || isNaN(y)) return
        if (Math.abs(x - curX) > 2 || Math.abs(y - curY) > 2) {
            curX = x
            curY = y
            curMoving = true
            curIdle.restart()
        }
    }
    Timer { id: curIdle; interval: 6000; onTriggered: win.curMoving = false }

    Process {
        running: win.mode === "idle" && win.visible
        command: ["sh", "-c", "while :; do hyprctl cursorpos 2>/dev/null; sleep 0.07; done"]
        stdout: SplitParser { onRead: line => win.onCursor(line) }
    }

    // ---------------- Thành phần dùng chung ----------------
    component Pill: Rectangle {
        id: pl_
        property string label: ""
        property color tint: "#23232f"
        property color textColor: "#cdd6f4"
        signal clicked()
        implicitWidth: plText.implicitWidth + 22
        implicitHeight: 28
        radius: 14
        color: plArea.containsMouse ? Qt.lighter(tint, 1.3) : tint
        Behavior on color { ColorAnimation { duration: 100 } }
        Text { id: plText; anchors.centerIn: parent; text: pl_.label; color: pl_.textColor
               font.pixelSize: 12; font.bold: true }
        MouseArea { id: plArea; anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor; onClicked: pl_.clicked() }
    }

    // Nút tròn (điều khiển nhạc)
    component RoundBtn: Rectangle {
        id: rb
        property string glyph: ""
        property int size: 30
        property bool solid: false
        property bool active: true
        signal clicked()
        width: size; height: size; radius: size / 2
        opacity: active ? 1 : 0.35
        color: solid ? (rbArea.containsMouse ? "#ffffff" : "#e6e9f5")
                     : (rbArea.containsMouse ? "#2a2a3a" : "transparent")
        Behavior on color { ColorAnimation { duration: 100 } }
        Text {
            anchors.centerIn: parent
            text: rb.glyph
            color: rb.solid ? "#11111b" : win.fg
            font.pixelSize: rb.size * 0.46
        }
        MouseArea { id: rbArea; anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor; onClicked: if (rb.active) rb.clicked() }
    }

    // Thanh trượt kéo được. value: 0..1. moved = đang kéo, commit = thả chuột
    component Slide: Item {
        id: sl
        property real value: 0
        property color tone: "#89b4fa"
        property real mark: -1
        property int thick: 6
        property bool enabled_: true
        readonly property bool dragging: area.pressed
        readonly property real shown: area.pressed ? dragVal : value
        property real dragVal: 0
        signal moved(real v)
        signal commit(real v)
        height: 22
        opacity: enabled_ ? 1 : 0.35

        Rectangle {
            id: track
            width: parent.width; height: sl.thick; radius: height / 2
            anchors.verticalCenter: parent.verticalCenter
            color: "#2a2a3a"
            Rectangle {
                width: 7 + (parent.width - 14) * Math.max(0, Math.min(1, sl.shown))
                height: parent.height; radius: parent.radius
                color: sl.tone
            }
            Rectangle {
                visible: sl.mark >= 0
                x: 7 + (parent.width - 14) * sl.mark - 1
                width: 2; height: parent.height + 4; y: -2
                color: "#6c7086"
            }
        }
        Rectangle {
            width: 14; height: 14; radius: 7
            anchors.verticalCenter: parent.verticalCenter
            x: (sl.width - width) * Math.max(0, Math.min(1, sl.shown))
            color: "#e6e9f5"
            scale: area.pressed ? 1.25 : (area.containsMouse ? 1.1 : 1)
            Behavior on scale { NumberAnimation { duration: 90 } }
        }
        MouseArea {
            id: area
            anchors.fill: parent
            enabled: sl.enabled_
            hoverEnabled: true
            preventStealing: true
            cursorShape: Qt.PointingHandCursor
            function val(mx) { return Math.max(0, Math.min(1, (mx - 7) / Math.max(1, width - 14))) }
            onPressed: m => { sl.dragVal = val(m.x); sl.moved(sl.dragVal) }
            onPositionChanged: m => { if (pressed) { sl.dragVal = val(m.x); sl.moved(sl.dragVal) } }
            onReleased: sl.commit(sl.dragVal)
        }
    }

    // Sóng nhạc nhỏ (chỉ chạy khi hiện, để nhẹ máy)
    component Eq: Row {
        id: eq
        property bool running: false
        property color tone: "#a6e3a1"
        spacing: 2
        height: 14
        Repeater {
            model: 4
            Item {
                id: col
                required property int index
                width: 3; height: eq.height
                Rectangle {
                    anchors.bottom: parent.bottom
                    width: 3; radius: 1.5; color: eq.tone
                    height: 4
                    SequentialAnimation on height {
                        running: eq.running && eq.visible
                        loops: Animation.Infinite
                        NumberAnimation { to: 14; duration: 260 + col.index * 80; easing.type: Easing.InOutQuad }
                        NumberAnimation { to: 4;  duration: 300 + col.index * 60; easing.type: Easing.InOutQuad }
                    }
                }
            }
        }
    }

    // Đôi mắt robot sống động: thở, chớp mắt (đôi khi chớp 2 lần / nháy một mắt), đảo mắt, nhìn lên,
    // lắc lư, và NHÌN THEO CON TRỎ CHUỘT khi rê vào island. Chỉ chạy khi đang hiện (nhẹ máy).
    //  mood: "normal" | "happy" (đang nghe nhạc, nhún nhảy) | "focus" (nheo, cau mày) | "sleepy" (ngái ngủ, lim dim)
    component Eyes: Item {
        id: ey
        property bool active: true
        property string mood: "normal"
        property color tone: "#89dceb"
        property bool follow: false           // đang rê chuột -> nhìn theo
        property real followX: 0              // -1..1
        property real followY: 0
        property real gx: 0                   // hướng nhìn ngẫu nhiên
        property real gy: 0
        property bool blinkL: false
        property bool blinkR: false
        readonly property real gxEff: follow ? followX : gx
        readonly property real gyEff: follow ? followY : gy
        readonly property real baseH: mood === "focus" ? 8 : (mood === "sleepy" ? 5 : (mood === "happy" ? 11 : 13))
        readonly property real tilt: mood === "focus" ? 14 : (mood === "sleepy" ? -12 : (mood === "happy" ? -6 : 0))
        width: 40; height: 22

        Item {
            id: pair
            width: 28; height: 16
            x: (ey.width - width) / 2 + ey.gxEff * 4
            y: (ey.height - height) / 2 + ey.gyEff * 3
            transformOrigin: Item.Center
            Behavior on x { NumberAnimation { duration: 170; easing.type: Easing.OutCubic } }
            Behavior on y { NumberAnimation { duration: 170; easing.type: Easing.OutCubic } }

            // thở nhẹ
            SequentialAnimation on scale {
                running: ey.active
                loops: Animation.Infinite
                NumberAnimation { to: 1.07; duration: 1700; easing.type: Easing.InOutSine }
                NumberAnimation { to: 1.0;  duration: 1700; easing.type: Easing.InOutSine }
            }
            // nhún nhảy theo nhạc
            property real bob: 0
            SequentialAnimation on bob {
                running: ey.active && ey.mood === "happy"
                loops: Animation.Infinite
                NumberAnimation { to: -2.5; duration: 240; easing.type: Easing.OutQuad }
                NumberAnimation { to: 1;    duration: 240; easing.type: Easing.InQuad }
            }
            // lắc lư
            SequentialAnimation {
                id: wiggle
                NumberAnimation { target: pair; property: "rotation"; to: -10; duration: 110 }
                NumberAnimation { target: pair; property: "rotation"; to: 10;  duration: 160 }
                NumberAnimation { target: pair; property: "rotation"; to: -7;  duration: 140 }
                NumberAnimation { target: pair; property: "rotation"; to: 0;   duration: 120 }
            }

            Repeater {
                model: 2
                Rectangle {
                    id: eye
                    required property int index
                    readonly property bool closed: index === 0 ? ey.blinkL : ey.blinkR
                    width: 11
                    height: closed ? 2 : ey.baseH
                    radius: Math.min(5.5, height / 2)
                    x: index * 17
                    y: (pair.height - height) / 2 + pair.bob
                    color: ey.tone
                    rotation: (index === 0 ? 1 : -1) * ey.tilt
                    Behavior on height { NumberAnimation { duration: 90 } }
                    Behavior on rotation { NumberAnimation { duration: 220 } }
                    Behavior on color { ColorAnimation { duration: 300 } }
                    Rectangle {                       // chấm sáng trong mắt cho có hồn
                        visible: eye.height > 6
                        x: 2; y: 2; width: 3.5; height: 3.5; radius: 2
                        color: "white"; opacity: 0.85
                    }
                }
            }
        }

        // chớp mắt
        Timer {
            running: ey.active
            repeat: true
            interval: 2200 + Math.random() * 3200
            onTriggered: {
                ey.blinkL = true; ey.blinkR = true
                unblink.restart()
                if (Math.random() < 0.25) again.restart()          // thỉnh thoảng chớp 2 lần
                interval = 2200 + Math.random() * 3200
            }
        }
        Timer { id: unblink; interval: 130; onTriggered: { ey.blinkL = false; ey.blinkR = false } }
        Timer { id: again; interval: 260; onTriggered: { ey.blinkL = true; ey.blinkR = true; unblink.restart() } }

        // đảo mắt
        Timer {
            running: ey.active && !ey.follow
            repeat: true
            interval: 1500
            onTriggered: {
                const r = Math.random()
                ey.gx = r < 0.3 ? 0 : (r < 0.65 ? -1 : 1)
                ey.gy = Math.random() < 0.2 ? -1 : 0
                interval = 1100 + Math.random() * 2800
            }
        }

        // trò nghịch ngẫu nhiên: nháy mắt, nhìn lên, lắc lư, liếc hai bên
        Timer {
            running: ey.active && !ey.follow
            repeat: true
            interval: 6000
            onTriggered: {
                const r = Math.floor(Math.random() * 4)
                if (r === 0) { ey.blinkR = true; wink.restart() }
                else if (r === 1) { ey.gy = -1; ey.gx = 0 }
                else if (r === 2) wiggle.restart()
                else { ey.gx = -1; sweep.restart() }
                interval = 5000 + Math.random() * 7000
            }
        }
        Timer { id: wink; interval: 320; onTriggered: ey.blinkR = false }
        Timer { id: sweep; interval: 450; onTriggered: ey.gx = 1 }
    }

    // Ảnh bìa bo góc, chưa có ảnh thì hiện ♪
    component Art: ClippingRectangle {
        id: art
        property string src: ""
        radius: width * 0.22
        color: "#1b1b26"
        Image {
            anchors.fill: parent
            source: art.src
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            visible: status === Image.Ready
        }
        Text {
            anchors.centerIn: parent
            visible: art.src === ""
            text: "♪"
            color: "#6c7086"
            font.pixelSize: art.width * 0.5
        }
    }

    // ---------------- Viên island ----------------
    Rectangle {
        id: pill
        anchors.horizontalCenter: parent.horizontalCenter
        y: 0

        readonly property real targetW: {
            switch (win.mode) {
            case "peek":  return 420
            case "notif": return 380
            case "music": return 330
            case "event": return Math.max(eventRow.implicitWidth + 48, 150)
            default:      return idleRow.implicitWidth + 36
            }
        }
        readonly property real targetH: {
            switch (win.mode) {
            case "peek":  return peekCol.implicitHeight + 36
            case "notif": return 72
            case "music": return 62
            case "event": return 52
            default:      return 32
            }
        }

        width: targetW
        height: targetH
        radius: Math.min(height / 2, 30)
        color: "#050508"
        clip: true
        border.width: 1
        border.color: win.mode === "event" ? win.shell.islandTone
                      : (win.mode === "notif" && win.shell.nCritical ? "#f38ba8" : "#2a2a3a")
        Behavior on border.color { ColorAnimation { duration: 200 } }

        // Lò xo: co giãn có nảy
        Behavior on width  { SpringAnimation { spring: 3.4; damping: 0.26; epsilon: 0.4 } }
        Behavior on height { SpringAnimation { spring: 3.4; damping: 0.26; epsilon: 0.4 } }

        HoverHandler {
            id: hover
            cursorShape: Qt.PointingHandCursor
            onHoveredChanged: {
                // Rê chuột vào thông báo thì giữ lại, rời ra thì đếm lại
                if (win.flash === "notif" && !win.shell.islandPeek) {
                    if (hovered) flashTimer.stop(); else flashTimer.restart()
                }
            }
        }

        // Bấm vào nền island (các nút con nằm trên nên không bị ảnh hưởng)
        MouseArea {
            anchors.fill: parent
            acceptedButtons: Qt.LeftButton | Qt.RightButton
            onClicked: m => {
                if (win.mode === "notif") {
                    flashTimer.stop()
                    if (m.button === Qt.RightButton) win.shell.dismissNotif()
                    else win.shell.invokeNotif()
                    win.flash = ""
                } else if (win.mode === "peek") {
                    if (m.button === Qt.RightButton) win.shell.islandPeek = false
                } else {
                    flashTimer.stop()
                    win.flash = ""
                    win.shell.islandPeek = true
                }
            }
        }

        // ===== Nghỉ =====
        Row {
            id: idleRow
            anchors.centerIn: parent
            spacing: 8
            opacity: win.mode === "idle" ? 1 : 0
            visible: opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 140 } }

            Eyes {
                id: eyes
                active: win.mode === "idle"
                mood: win.playing ? "happy"
                      : (win.shell.dnd ? "focus" : (win.shell.manualDnd ? "sleepy" : "normal"))
                tone: win.shell.pomoRunning && !win.shell.pomoBreak ? "#f38ba8"
                      : (win.playing ? "#a6e3a1" : "#89dceb")
                follow: win.curMoving && win.mode === "idle"
                // Hướng từ mắt tới con trỏ (tọa độ toàn màn hình = vị trí màn hình + vị trí trong cửa sổ)
                readonly property point ctr: eyes.mapToItem(null, eyes.width / 2, eyes.height / 2)
                followX: Math.max(-1, Math.min(1, (win.curX - (win.screen.x + (win.screen.width - win.width) / 2 + ctr.x)) / 220))
                followY: Math.max(-1, Math.min(1, (win.curY - (win.screen.y + 6 + ctr.y)) / 160))
                anchors.verticalCenter: parent.verticalCenter
            }
            Art {
                visible: win.playing
                width: 20; height: 20
                src: win.hasMusic ? win.pl.trackArtUrl : ""
                anchors.verticalCenter: parent.verticalCenter
            }
            Text {
                visible: win.shell.pomoRunning
                text: (win.shell.pomoBreak ? "☕ " : "📖 ") + win.mmss(win.shell.pomoRemaining)
                color: win.shell.pomoBreak ? "#a6e3a1" : "#f38ba8"
                font.pixelSize: 12
                font.family: "monospace"
                anchors.verticalCenter: parent.verticalCenter
            }
            Text {
                text: Qt.formatDateTime(clock.date, "HH:mm")
                color: win.fg
                font.pixelSize: 14
                font.bold: true
                anchors.verticalCenter: parent.verticalCenter
            }
            Text {
                text: Qt.formatDateTime(clock.date, "ddd dd/MM")
                color: win.dim
                font.pixelSize: 12
                anchors.verticalCenter: parent.verticalCenter
            }
            Text {
                visible: win.shell.dnd
                text: "🔕"
                font.pixelSize: 12
                anchors.verticalCenter: parent.verticalCenter
            }
            Eq {
                visible: win.playing
                running: win.mode === "idle" && win.playing
                anchors.verticalCenter: parent.verticalCenter
            }
        }

        // ===== Các trạng thái tạm (sự kiện / thông báo / nhạc) =====
        Item {
            id: flashLayer
            anchors.fill: parent

            // --- Sự kiện ---
            Row {
                id: eventRow
                anchors.centerIn: parent
                spacing: 12
                opacity: win.mode === "event" ? 1 : 0
                visible: opacity > 0.01
                Behavior on opacity { NumberAnimation { duration: 140 } }

                Text {
                    text: win.shell.islandIcon
                    font.pixelSize: 22
                    anchors.verticalCenter: parent.verticalCenter
                }
                Rectangle {
                    visible: win.shell.islandValue >= 0
                    width: 150; height: 8; radius: 4
                    color: "#2a2a3a"
                    anchors.verticalCenter: parent.verticalCenter
                    Rectangle {
                        width: parent.width * Math.max(0, Math.min(1, win.shell.islandValue))
                        height: parent.height
                        radius: 4
                        color: win.shell.islandTone
                        Behavior on width { SpringAnimation { spring: 5; damping: 0.4; epsilon: 0.5 } }
                    }
                }
                Text {
                    text: win.shell.islandText
                    color: win.fg
                    font.pixelSize: 14
                    font.bold: true
                    anchors.verticalCenter: parent.verticalCenter
                }
            }

            // --- Thông báo ---
            Item {
                id: notifBox
                anchors.fill: parent
                opacity: win.mode === "notif" ? 1 : 0
                visible: opacity > 0.01
                Behavior on opacity { NumberAnimation { duration: 140 } }

                Rectangle {
                    id: nIconBox
                    x: 16; width: 40; height: 40; radius: 12
                    anchors.verticalCenter: parent.verticalCenter
                    color: "#1b1b26"
                    Image {
                        anchors.fill: parent
                        anchors.margins: 6
                        source: win.shell.nIcon
                        sourceSize: Qt.size(64, 64)
                        fillMode: Image.PreserveAspectFit
                        asynchronous: true
                        visible: status === Image.Ready
                    }
                    Text {
                        anchors.centerIn: parent
                        visible: win.shell.nIcon === ""
                        text: "🔔"
                        font.pixelSize: 20
                    }
                }
                Column {
                    x: 68
                    width: parent.width - 68 - 40
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 1
                    Text {
                        width: parent.width
                        text: win.shell.nApp
                        visible: text !== ""
                        elide: Text.ElideRight
                        color: win.dim
                        font.pixelSize: 10
                        font.capitalization: Font.AllUppercase
                        font.letterSpacing: 0.6
                    }
                    Text {
                        width: parent.width
                        text: win.shell.nSummary
                        elide: Text.ElideRight
                        maximumLineCount: 1
                        color: win.shell.nCritical ? "#f38ba8" : win.fg
                        font.pixelSize: 13
                        font.bold: true
                    }
                    Text {
                        width: parent.width
                        text: win.shell.nBody
                        visible: text !== ""
                        elide: Text.ElideRight
                        maximumLineCount: 1
                        color: win.dim
                        font.pixelSize: 12
                    }
                }
                RoundBtn {
                    glyph: "✕"
                    size: 24
                    anchors.right: parent.right
                    anchors.rightMargin: 12
                    anchors.verticalCenter: parent.verticalCenter
                    onClicked: { flashTimer.stop(); win.shell.dismissNotif(); win.flash = "" }
                }
            }

            // --- Đang phát nhạc ---
            Item {
                id: musicBox
                anchors.fill: parent
                opacity: win.mode === "music" ? 1 : 0
                visible: opacity > 0.01
                Behavior on opacity { NumberAnimation { duration: 140 } }

                Art {
                    id: musicArt
                    x: 14; width: 40; height: 40
                    anchors.verticalCenter: parent.verticalCenter
                    src: win.hasMusic ? win.pl.trackArtUrl : ""
                }
                Column {
                    x: 66
                    width: parent.width - 66 - 54
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 2
                    Text {
                        width: parent.width
                        text: win.hasMusic ? win.pl.trackTitle : ""
                        elide: Text.ElideRight
                        maximumLineCount: 1
                        color: win.fg
                        font.pixelSize: 13
                        font.bold: true
                    }
                    Text {
                        width: parent.width
                        text: win.hasMusic ? (win.pl.trackArtist !== "" ? win.pl.trackArtist : win.pl.identity) : ""
                        elide: Text.ElideRight
                        maximumLineCount: 1
                        color: win.dim
                        font.pixelSize: 12
                    }
                }
                Eq {
                    anchors.right: parent.right
                    anchors.rightMargin: 20
                    anchors.verticalCenter: parent.verticalCenter
                    running: win.mode === "music"
                }
            }
        }

        // ===== Thẻ nhanh =====
        Item {
            id: peek
            width: 420
            height: peekCol.implicitHeight + 36
            anchors.horizontalCenter: parent.horizontalCenter
            opacity: win.mode === "peek" ? 1 : 0
            visible: opacity > 0.01
            Behavior on opacity { NumberAnimation { duration: 180 } }

            Column {
                id: peekCol
                x: 22; y: 18
                width: 376
                spacing: 12

                // --- Giờ + ngày + CPU/RAM ---
                Item {
                    width: parent.width
                    height: 46
                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Qt.formatDateTime(clock.date, "HH:mm")
                        color: win.fg
                        font.pixelSize: 36
                        font.bold: true
                    }
                    Column {
                        anchors.right: parent.right
                        anchors.verticalCenter: parent.verticalCenter
                        width: 190
                        spacing: 3
                        Text {
                            width: parent.width
                            horizontalAlignment: Text.AlignRight
                            text: Qt.formatDateTime(clock.date, "dddd, dd/MM/yyyy")
                            color: win.fg
                            font.pixelSize: 12
                        }
                        Text {
                            width: parent.width
                            horizontalAlignment: Text.AlignRight
                            text: "CPU " + win.shell.sysCpu + "%   ·   RAM " + win.shell.sysMem + "%"
                            color: (win.shell.sysCpu > 85 || win.shell.sysMem > 90) ? "#f38ba8" : win.dim
                            font.pixelSize: 11
                        }
                    }
                    MouseArea {                      // bấm vào đồng hồ để thu lại
                        anchors.fill: parent
                        onClicked: win.shell.islandPeek = false
                    }
                }

                Rectangle { width: parent.width; height: 1; color: win.line }

                // --- Nhạc ---
                Item {
                    width: parent.width
                    height: win.hasMusic ? 96 : 20

                    Text {
                        visible: !win.hasMusic
                        anchors.verticalCenter: parent.verticalCenter
                        text: "♪   Chưa có nhạc đang phát"
                        color: win.dim
                        font.pixelSize: 12
                    }

                    Item {
                        visible: win.hasMusic
                        anchors.fill: parent

                        Art {
                            id: bigArt
                            width: 64; height: 64
                            src: win.hasMusic ? win.pl.trackArtUrl : ""
                        }
                        Column {
                            x: 78
                            width: parent.width - 78
                            spacing: 2
                            Text {
                                width: parent.width
                                text: win.hasMusic ? (win.pl.trackTitle !== "" ? win.pl.trackTitle : "Không rõ tên bài") : ""
                                elide: Text.ElideRight
                                maximumLineCount: 1
                                color: win.fg
                                font.pixelSize: 14
                                font.bold: true
                            }
                            Text {
                                width: parent.width
                                text: win.hasMusic ? (win.pl.trackArtist !== "" ? win.pl.trackArtist : win.pl.identity) : ""
                                elide: Text.ElideRight
                                maximumLineCount: 1
                                color: win.dim
                                font.pixelSize: 12
                            }
                        }
                        Row {
                            x: 74
                            y: 38
                            spacing: 6
                            RoundBtn {
                                glyph: "⏮"
                                active: win.hasMusic && win.pl.canGoPrevious
                                onClicked: win.pl.previous()
                            }
                            RoundBtn {
                                glyph: win.playing ? "⏸" : "▶"
                                solid: true
                                active: win.hasMusic && win.pl.canTogglePlaying
                                onClicked: win.pl.togglePlaying()
                            }
                            RoundBtn {
                                glyph: "⏭"
                                active: win.hasMusic && win.pl.canGoNext
                                onClicked: win.pl.next()
                            }
                        }
                        Text {                       // tên trình phát (Cốc Cốc, Spotify...)
                            anchors.right: parent.right
                            y: 46
                            text: win.hasMusic ? win.pl.identity : ""
                            color: "#585b70"
                            font.pixelSize: 10
                        }

                        // Thanh tiến trình (kéo để tua)
                        Item {
                            y: 74
                            width: parent.width
                            height: 18
                            visible: win.hasMusic && win.pl.lengthSupported && win.pl.length > 0
                            Text {
                                id: posText
                                anchors.verticalCenter: parent.verticalCenter
                                width: 34
                                text: win.hasMusic ? win.clock_(prog.dragging ? prog.dragVal * win.pl.length : win.pl.position) : ""
                                color: win.dim
                                font.pixelSize: 10
                            }
                            Slide {
                                id: prog
                                x: 38
                                width: parent.width - 38 - 38
                                anchors.verticalCenter: parent.verticalCenter
                                thick: 4
                                tone: "#cdd6f4"
                                enabled_: win.hasMusic && win.pl.canSeek
                                value: win.hasMusic && win.pl.length > 0 ? Math.min(1, win.pl.position / win.pl.length) : 0
                                onCommit: v => {
                                    if (win.hasMusic && win.pl.canSeek) {
                                        win.pl.position = v * win.pl.length
                                        win.pl.positionChanged()
                                    }
                                }
                            }
                            Text {
                                anchors.right: parent.right
                                anchors.verticalCenter: parent.verticalCenter
                                width: 34
                                horizontalAlignment: Text.AlignRight
                                text: win.hasMusic ? win.clock_(win.pl.length) : ""
                                color: win.dim
                                font.pixelSize: 10
                            }
                        }
                    }
                }

                Rectangle { width: parent.width; height: 1; color: win.line }

                // --- Âm lượng + độ sáng ---
                Column {
                    width: parent.width
                    spacing: 6

                    Row {
                        width: parent.width
                        height: 24
                        spacing: 10
                        Item {
                            width: 24; height: 24
                            Text {
                                anchors.centerIn: parent
                                text: !win.sink ? "🔈" : (win.sink.audio.muted ? "🔇" : (win.sink.audio.volume === 0 ? "🔈" : "🔊"))
                                font.pixelSize: 16
                            }
                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: if (win.sink) win.sink.audio.muted = !win.sink.audio.muted
                            }
                        }
                        Slide {
                            width: parent.width - 24 - 48 - 20
                            anchors.verticalCenter: parent.verticalCenter
                            enabled_: win.sink !== null && win.sink !== undefined
                            value: win.sink ? win.sink.audio.volume / win.shell.maxVolume : 0
                            mark: 1.0 / win.shell.maxVolume                       // vạch 100%
                            tone: win.sink && win.sink.audio.volume > 1.0 ? "#f38ba8"
                                  : (win.sink && win.sink.audio.muted ? "#585b70" : "#89b4fa")
                            onMoved: v => {
                                let x = v * win.shell.maxVolume
                                if (Math.abs(x - 1.0) < 0.04) x = 1.0              // hút vào đúng 100%
                                win.shell.setVolume(x)
                            }
                        }
                        Text {
                            width: 48
                            anchors.verticalCenter: parent.verticalCenter
                            horizontalAlignment: Text.AlignRight
                            text: !win.sink ? "--" : (win.sink.audio.muted ? "Tắt" : Math.round(win.sink.audio.volume * 100) + "%")
                            color: win.sink && win.sink.audio.volume > 1.0 ? "#f38ba8" : win.fg
                            font.pixelSize: 12
                            font.bold: true
                        }
                    }

                    Row {
                        width: parent.width
                        height: 24
                        spacing: 10
                        Item {
                            width: 24; height: 24
                            Text { anchors.centerIn: parent; text: "🔆"; font.pixelSize: 16 }
                        }
                        Slide {
                            width: parent.width - 24 - 48 - 20
                            anchors.verticalCenter: parent.verticalCenter
                            enabled_: win.shell.brightness >= 0
                            value: Math.max(0, win.shell.brightness) / 100
                            tone: "#f9e2af"
                            onMoved: v => win.shell.setBrightness(v * 100)
                        }
                        Text {
                            width: 48
                            anchors.verticalCenter: parent.verticalCenter
                            horizontalAlignment: Text.AlignRight
                            text: win.shell.brightness >= 0 ? win.shell.brightness + "%" : "--"
                            color: win.fg
                            font.pixelSize: 12
                            font.bold: true
                        }
                    }
                    Text {
                        visible: win.shell.brightness < 0
                        width: parent.width
                        text: "Không tìm thấy đèn nền màn hình (cần brightnessctl + quyền nhóm video)"
                        color: "#585b70"
                        font.pixelSize: 10
                        wrapMode: Text.WordWrap
                    }
                }

                Rectangle { width: parent.width; height: 1; color: win.line }

                // --- Pomodoro ---
                Row {
                    spacing: 10
                    height: 30
                    Text {
                        text: (win.shell.pomoBreak ? "☕ " : "📖 ") + win.mmss(win.shell.pomoRemaining)
                        color: win.shell.pomoBreak ? "#a6e3a1" : (win.shell.pomoRunning ? "#f38ba8" : win.fg)
                        font.pixelSize: 18
                        font.family: "monospace"
                        font.bold: true
                        anchors.verticalCenter: parent.verticalCenter
                    }
                    Pill {
                        label: win.shell.pomoRunning ? "⏸ Dừng" : "▶ Bắt đầu"
                        tint: "#f38ba8"; textColor: "#1e1e2e"
                        anchors.verticalCenter: parent.verticalCenter
                        onClicked: win.shell.pomoToggle()
                    }
                    Pill {
                        label: "⟲"
                        anchors.verticalCenter: parent.verticalCenter
                        onClicked: win.shell.pomoReset()
                    }
                    Text {
                        visible: win.shell.pomoToday > 0
                        text: "🍅 ×" + win.shell.pomoToday
                        color: win.dim
                        font.pixelSize: 12
                        anchors.verticalCenter: parent.verticalCenter
                    }
                }

                // --- Mục tiêu (gộp nhiều dòng thành một để không bị tràn) ---
                Text {
                    width: parent.width
                    maximumLineCount: 1
                    elide: Text.ElideRight
                    text: win.shell.goalText !== ""
                          ? "🎯  " + win.shell.goalText.replace(/\s*\n\s*/g, "  ·  ")
                          : "🎯  Chưa đặt mục tiêu"
                    color: win.shell.goalText !== "" ? "#f9e2af" : win.dim
                    font.pixelSize: 12
                    font.bold: true
                }
            }
        }
    }

    // ---------------- Hiệu ứng nảy ----------------
    ParallelAnimation {
        id: pop
        NumberAnimation {
            target: flashLayer; property: "scale"
            from: 0.8; to: 1.0
            duration: 420; easing.type: Easing.OutBack; easing.overshoot: 2.4
        }
        NumberAnimation {
            target: pill; property: "scale"
            from: 1.06; to: 1.0
            duration: 480; easing.type: Easing.OutBack; easing.overshoot: 3.0
        }
    }

    ParallelAnimation {
        id: peekPop
        NumberAnimation {
            target: peek; property: "scale"
            from: 0.92; to: 1.0
            duration: 460; easing.type: Easing.OutBack; easing.overshoot: 1.8
        }
    }
}
