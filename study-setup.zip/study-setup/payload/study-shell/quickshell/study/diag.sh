#!/bin/sh
# Chẩn đoán Wi-Fi: in ra các dòng "khoá|giá_trị" để shell đọc và hiển thị.

echo "nm|$(systemctl is-active NetworkManager 2>/dev/null)"

r=$(rfkill list wifi 2>/dev/null)
case "$r" in
  *"Hard blocked: yes"*) echo "rfkill|hard" ;;
  *"Soft blocked: yes"*) echo "rfkill|soft" ;;
  *) echo "rfkill|ok" ;;
esac

echo "radio|$(nmcli radio wifi 2>/dev/null)"
echo "dev|$(nmcli -t -f TYPE,STATE device 2>/dev/null | grep '^wifi:' | head -n 1 | cut -d: -f2)"

gw=$(ip route show default 2>/dev/null | awk '{print $3; exit}')
echo "gw|$gw"
if [ -n "$gw" ] && ping -c 1 -W 2 "$gw" >/dev/null 2>&1; then echo "gwping|ok"; else echo "gwping|fail"; fi

if ping -c 1 -W 3 1.1.1.1 >/dev/null 2>&1; then echo "inet|ok"; else echo "inet|fail"; fi
if getent hosts archlinux.org >/dev/null 2>&1; then echo "dns|ok"; else echo "dns|fail"; fi

if command -v curl >/dev/null 2>&1; then
  echo "http|$(curl -s -m 4 -o /dev/null -w '%{http_code}' http://connectivitycheck.gstatic.com/generate_204 2>/dev/null)"
else
  echo "http|skip"
fi
