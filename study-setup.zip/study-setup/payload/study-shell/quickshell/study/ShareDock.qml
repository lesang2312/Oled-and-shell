import Quickshell
import Quickshell.Wayland
import QtQuick

// Nút nổi ở mép phải màn hình: bấm để mở thư viện file nhận từ điện thoại (share_png).
// Trái = mở thư viện, phải = bật/tắt nhận file. Có số file đang chờ quyết định, nằm ẩn một nửa vào mép khi không dùng.
PanelWindow {
    id: dock
    property var shell

    readonly property color accent: "#89b4fa"
    readonly property int pending: shell.sharePending.length
    readonly property bool peek: area.containsMouse || pending > 0 || shell.shareOpen

    anchors { right: true; top: true }
    margins { top: Math.round((dock.screen ? dock.screen.height : 900) * 0.42) }
    implicitWidth: 76
    implicitHeight: 64
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Top
    WlrLayershell.namespace: "qs-share-dock"
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    color: "transparent"
    mask: Region { item: pill }

    Rectangle {
        id: pill
        y: 6
        x: dock.peek ? 14 : 44                  // không dùng thì chỉ lộ một phần ở mép
        width: 64
        height: 52
        radius: 26
        color: dock.shell.shareOn ? (dock.pending > 0 ? dock.accent : "#313244") : "#262637"
        border.width: 1
        border.color: dock.pending > 0 ? "#b4befe" : "#45475a"
        opacity: dock.shell.shareOn ? (dock.peek ? 1 : 0.7) : 0.5
        Behavior on x { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        Behavior on opacity { NumberAnimation { duration: 200 } }
        Behavior on color { ColorAnimation { duration: 200 } }

        // Vòng nhịp khi có file đang chờ
        Rectangle {
            anchors.centerIn: parent
            width: parent.height
            height: parent.height
            radius: height / 2
            color: "transparent"
            border.width: 2
            border.color: dock.accent
            visible: dock.pending > 0
            SequentialAnimation on scale {
                running: dock.pending > 0
                loops: Animation.Infinite
                NumberAnimation { from: 1; to: 1.5; duration: 900; easing.type: Easing.OutCubic }
            }
            SequentialAnimation on opacity {
                running: dock.pending > 0
                loops: Animation.Infinite
                NumberAnimation { from: 0.7; to: 0; duration: 900 }
            }
        }

        Text {
            x: 12
            anchors.verticalCenter: parent.verticalCenter
            text: "📲"
            font.pixelSize: 22
        }

        // Số file đang chờ
        Rectangle {
            visible: dock.pending > 0
            x: 2
            y: -2
            width: 20
            height: 20
            radius: 10
            color: "#f38ba8"
            Text {
                anchors.centerIn: parent
                text: dock.pending > 9 ? "9+" : dock.pending
                color: "#11111b"
                font.pixelSize: 11
                font.bold: true
            }
        }

        MouseArea {
            id: area
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            acceptedButtons: Qt.LeftButton | Qt.RightButton
            onClicked: m => {
                if (m.button === Qt.RightButton) dock.shell.shareSetOn(!dock.shell.shareOn)
                else dock.shell.shareOpen = !dock.shell.shareOpen
            }
        }
    }
}
