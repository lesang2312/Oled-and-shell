import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// Việc cần làm + thống kê Pomodoro hôm nay.
// Dữ liệu lưu ở ~/.config/quickshell/study/todo.json. Enter để thêm, Esc để đóng.
PanelWindow {
    id: win
    property var shell

    readonly property color accent: "#94e2d5"
    readonly property color fg: "#cdd6f4"
    readonly property color dim: "#7f849c"
    property int undone: 0

    visible: shell.todoOpen
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-todo"
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "#99000000"

    ListModel { id: todos }

    FileView {
        id: store
        path: win.shell.home + "/.config/quickshell/study/todo.json"
        printErrors: false
        onLoaded: {
            try {
                const a = JSON.parse(text())
                todos.clear()
                a.forEach(x => todos.append({ title: String(x.title), done: !!x.done }))
                win.recount()
            } catch (e) {}
        }
    }

    function recount() {
        let n = 0
        for (let i = 0; i < todos.count; i++) if (!todos.get(i).done) n++
        undone = n
    }

    function save() {
        const a = []
        for (let i = 0; i < todos.count; i++) {
            const t = todos.get(i)
            a.push({ title: t.title, done: t.done })
        }
        store.setText(JSON.stringify(a))
        recount()
    }

    function add(t) {
        t = t.trim()
        if (t === "") return
        todos.insert(0, { title: t, done: false })
        save()
    }
    function toggle(i) { todos.setProperty(i, "done", !todos.get(i).done); save() }
    function remove(i) { todos.remove(i); save() }
    function clearDone() {
        for (let i = todos.count - 1; i >= 0; i--) if (todos.get(i).done) todos.remove(i)
        save()
    }

    function close() { shell.todoOpen = false }
    onVisibleChanged: if (visible) input.forceActiveFocus()

    function mmss(s) {
        return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0")
    }

    component Pill: Rectangle {
        id: pill
        property string label: ""
        property color tint: "#313244"
        property color textColor: "#cdd6f4"
        property int h: 30
        signal clicked()
        implicitWidth: pillText.implicitWidth + 24
        implicitHeight: h
        radius: h / 2
        color: pillArea.containsMouse ? Qt.lighter(tint, 1.25) : tint
        Text { id: pillText; anchors.centerIn: parent; text: pill.label; color: pill.textColor
               font.pixelSize: 12; font.bold: true }
        MouseArea { id: pillArea; anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor; onClicked: pill.clicked() }
    }

    // Click ra ngoài để đóng
    MouseArea { anchors.fill: parent; onClicked: win.close() }

    Rectangle {
        anchors.centerIn: parent
        width: 440
        height: 560
        radius: 24
        color: "#f01e1e2e"
        border.color: "#585b70"
        border.width: 1

        MouseArea { anchors.fill: parent }   // chặn click xuyên xuống nền

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 18
            spacing: 12

            RowLayout {
                Layout.fillWidth: true
                Column {
                    Layout.fillWidth: true
                    spacing: 2
                    Text { text: "📝  Việc cần làm"; color: win.accent; font.pixelSize: 20; font.bold: true }
                    Text { text: win.undone + " việc chưa xong"; color: win.dim; font.pixelSize: 11 }
                }
                Pill { label: "✕"; onClicked: win.close() }
            }

            // ---- Thẻ Pomodoro ----
            Rectangle {
                Layout.fillWidth: true
                implicitHeight: 66
                radius: 14
                color: "#313244"

                RowLayout {
                    anchors { fill: parent; leftMargin: 14; rightMargin: 12 }
                    spacing: 10
                    Column {
                        Layout.fillWidth: true
                        spacing: 3
                        Text { text: "🍅  Hôm nay"; color: win.fg; font.pixelSize: 13; font.bold: true }
                        Text {
                            text: win.shell.pomoToday + " phiên · " + win.shell.pomoMinutes + " phút tập trung"
                            color: win.dim
                            font.pixelSize: 11
                        }
                    }
                    Text {
                        text: (win.shell.pomoBreak ? "☕ " : "📖 ") + win.mmss(win.shell.pomoRemaining)
                        color: win.shell.pomoBreak ? "#a6e3a1" : (win.shell.pomoRunning ? "#f38ba8" : win.fg)
                        font.pixelSize: 18
                        font.family: "monospace"
                        font.bold: true
                    }
                    Pill {
                        label: win.shell.pomoRunning ? "⏸" : "▶"
                        tint: win.accent
                        textColor: "#1e1e2e"
                        onClicked: win.shell.pomoToggle()
                    }
                }
            }

            // ---- Ô thêm việc ----
            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 42
                radius: 21
                color: "#313244"
                border.width: 1
                border.color: input.activeFocus ? win.accent : "transparent"

                TextInput {
                    id: input
                    anchors { fill: parent; leftMargin: 18; rightMargin: 18 }
                    verticalAlignment: TextInput.AlignVCenter
                    color: win.fg
                    font.pixelSize: 14
                    clip: true
                    Text {
                        visible: input.text === ""
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Thêm việc mới rồi nhấn Enter…"
                        color: win.dim
                        font.pixelSize: 14
                    }
                    Keys.onPressed: e => {
                        if (e.key === Qt.Key_Escape) { win.close(); e.accepted = true }
                        else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) {
                            win.add(input.text); input.text = ""; e.accepted = true
                        }
                    }
                }
            }

            // ---- Danh sách ----
            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                Text {
                    anchors.centerIn: parent
                    visible: todos.count === 0
                    horizontalAlignment: Text.AlignHCenter
                    color: win.dim
                    font.pixelSize: 13
                    lineHeight: 1.3
                    text: "Chưa có việc nào\nGõ vào ô phía trên để thêm"
                }

                ListView {
                    anchors.fill: parent
                    clip: true
                    spacing: 4
                    model: todos
                    delegate: Rectangle {
                        id: row
                        required property string title
                        required property bool done
                        required property int index
                        width: ListView.view.width
                        height: 42
                        radius: 10
                        color: rowHover.hovered ? "#313244" : "transparent"
                        HoverHandler { id: rowHover }

                        // Bấm vào dòng để đánh dấu xong / chưa xong
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: win.toggle(row.index)
                        }

                        Rectangle {
                            id: box
                            anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                            width: 22; height: 22; radius: 11
                            color: row.done ? win.accent : "transparent"
                            border.width: 2
                            border.color: row.done ? win.accent : win.dim
                            Text { anchors.centerIn: parent; visible: row.done; text: "✓"
                                   color: "#1e1e2e"; font.pixelSize: 13; font.bold: true }
                        }
                        Text {
                            anchors { left: box.right; leftMargin: 12; right: del.left; rightMargin: 8; verticalCenter: parent.verticalCenter }
                            text: row.title
                            elide: Text.ElideRight
                            color: row.done ? win.dim : win.fg
                            font.pixelSize: 14
                            font.strikeout: row.done
                        }
                        Rectangle {
                            id: del
                            visible: rowHover.hovered
                            anchors { right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                            width: 26; height: 26; radius: 13
                            color: delArea.containsMouse ? "#f38ba8" : "#45475a"
                            Text { anchors.centerIn: parent; text: "✕"; font.pixelSize: 12
                                   color: delArea.containsMouse ? "#1e1e2e" : win.fg }
                            MouseArea { id: delArea; anchors.fill: parent; hoverEnabled: true
                                        cursorShape: Qt.PointingHandCursor; onClicked: win.remove(row.index) }
                        }
                    }
                }
            }

            RowLayout {
                Layout.fillWidth: true
                Text {
                    Layout.fillWidth: true
                    text: "Bấm việc để đánh dấu xong · rê chuột để xoá"
                    color: win.dim
                    font.pixelSize: 11
                }
                Pill { label: "Xoá việc đã xong"; onClicked: win.clearDone() }
            }
        }
    }
}
