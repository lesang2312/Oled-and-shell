import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts

// Bảng kết nối không dây: Wi-Fi (nmcli) và Bluetooth (bluetoothctl)
// Wi-Fi có: báo lý do lỗi, quên mạng / nhập lại mật khẩu, mạng ẩn, cổng đăng nhập, chẩn đoán.
// Cần: networkmanager, bluez, bluez-utils. Esc hoặc click ra ngoài để đóng.
PanelWindow {
    id: win
    property var shell

    readonly property color accent: "#89b4fa"
    readonly property color fg: "#cdd6f4"
    readonly property color dim: "#7f849c"
    readonly property color red: "#f38ba8"
    readonly property color green: "#a6e3a1"
    readonly property color orange: "#fab387"

    readonly property bool isWifi: shell.connectTab === 0
    readonly property string scriptDir: shell.home + "/.config/quickshell/study"

    visible: shell.connectOpen
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-connect"
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "#99000000"

    // ---------------- Trạng thái ----------------
    property string msg: ""
    property string askSsid: ""          // mạng Wi-Fi đang hỏi mật khẩu
    property bool hiddenOpen: false      // form nối mạng ẩn
    property bool diagOpen: false
    property bool diagBusy: false
    property string diagSummary: ""
    property string failSsid: ""         // mạng vừa kết nối thất bại
    property string failReason: ""
    property bool failPw: false
    property bool wifiOn: true
    property var knownNets: ({})
    property bool btOn: false
    property bool scanning: false
    property var btPaired: ({})
    property var btConn: ({})

    ListModel { id: wifiModel }
    ListModel { id: btModel }
    ListModel { id: diagModel }

    function resetUi() {
        askSsid = ""
        hiddenOpen = false
        diagOpen = false
        failReason = ""
        msg = ""
    }

    function close() { resetUi(); shell.connectOpen = false }

    onVisibleChanged: {
        if (!visible) return
        resetUi()
        keys.forceActiveFocus()
        refresh()
        shell.refreshNet()
        if (!isWifi) startScan()
    }

    Connections {
        target: win.shell
        function onConnectTabChanged() {
            win.resetUi()
            win.refresh()
            if (!win.isWifi) win.startScan()
        }
    }

    function refresh() {
        if (isWifi) {
            wifiRadio.running = true
            knownProc.running = true
            wifiList.running = true
        } else {
            btShow.running = true
            btConnP.running = true
        }
    }

    // ---------------- Nút bấm dùng chung ----------------
    component Pill: Rectangle {
        id: pill
        property string label: ""
        property color tint: "#313244"
        property color textColor: "#cdd6f4"
        property int h: 34
        property int fs: 13
        signal clicked()
        implicitWidth: pillText.implicitWidth + 24
        implicitHeight: h
        radius: h / 2
        color: pillArea.containsMouse ? Qt.lighter(tint, 1.25) : tint
        Behavior on color { ColorAnimation { duration: 100 } }
        Text {
            id: pillText
            anchors.centerIn: parent
            text: pill.label
            color: pill.textColor
            font.pixelSize: pill.fs
            font.bold: true
        }
        MouseArea {
            id: pillArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }

    // ---------------- Chạy lệnh hành động (không cần đọc lỗi) ----------------
    Process {
        id: runner
        property string stdinData: ""
        onStarted: if (stdinData !== "") { write(stdinData); stdinData = "" }
        onExited: (code, status) => {
            win.msg = code === 0 ? "Xong" : "Không thành công"
            win.shell.refreshNet()
            win.refresh()
        }
    }

    function run(cmd, stdin, label) {
        runner.stdinEnabled = (stdin || "") !== ""
        runner.stdinData = stdin || ""
        runner.command = cmd
        msg = label || ""
        runner.running = true
    }

    // ================= Wi-Fi =================
    Process {
        id: wifiRadio
        command: ["nmcli", "radio", "wifi"]
        stdout: StdioCollector { onStreamFinished: win.wifiOn = text.trim() === "enabled" }
    }

    Process {
        id: knownProc
        command: ["nmcli", "-t", "-f", "NAME", "connection", "show"]
        stdout: StdioCollector {
            onStreamFinished: {
                const k = {}
                text.split("\n").forEach(l => { if (l) k[l] = true })
                win.knownNets = k
            }
        }
    }

    Process {
        id: wifiList
        command: ["nmcli", "-t", "-f", "IN-USE,SIGNAL,SECURITY,SSID", "dev", "wifi", "list", "--rescan", "auto"]
        stdout: StdioCollector { onStreamFinished: win.parseWifi(text) }
    }

    function parseWifi(text) {
        const rows = []
        const seen = {}
        for (const line of text.split("\n")) {
            if (!line) continue
            const p = line.replace(/\\:/g, "\u0001").split(":")
            if (p.length < 4) continue
            const ssid = p.slice(3).join(":").replace(/\u0001/g, ":")
            if (ssid === "" || seen[ssid]) continue
            seen[ssid] = true
            rows.push({ ssid: ssid, signal: parseInt(p[1]) || 0,
                        secure: p[2] !== "" && p[2] !== "--", active: p[0] === "*" })
        }
        rows.sort((a, b) => (b.active - a.active) || (b.signal - a.signal))
        wifiModel.clear()
        rows.forEach(r => wifiModel.append(r))
    }

    // ---- Kết nối có đọc lỗi để báo lý do ----
    Process {
        id: wifiRunner
        property string stdinData: ""
        property string ssid: ""
        property int exitCode: -1
        property bool exited: false
        property bool errDone: false
        property string errText: ""
        stderr: StdioCollector {
            onStreamFinished: { wifiRunner.errText = text; wifiRunner.errDone = true; wifiRunner.check() }
        }
        onStarted: if (stdinData !== "") { write(stdinData); stdinData = "" }
        onExited: (code, status) => { exitCode = code; exited = true; check() }
        function check() { if (exited && errDone) win.wifiDone(ssid, exitCode, errText) }
    }

    function startWifi(cmd, stdin, ssid) {
        if (wifiRunner.running) return
        failReason = ""
        wifiRunner.exited = false
        wifiRunner.errDone = false
        wifiRunner.errText = ""
        wifiRunner.ssid = ssid
        wifiRunner.stdinEnabled = (stdin || "") !== ""
        wifiRunner.stdinData = stdin || ""
        wifiRunner.command = cmd
        msg = "Đang kết nối " + ssid + "…"
        wifiRunner.running = true
    }

    function explainNm(err) {
        const e = err.toLowerCase()
        if (e.includes("secrets were required") || e.includes("password") || e.includes("802-1x") || e.includes("handshake"))
            return { t: "Sai mật khẩu, hoặc chưa nhập mật khẩu.", pw: true }
        if (e.includes("no network with ssid"))
            return { t: "Không thấy mạng này: có thể xa quá, đang ẩn hoặc router vừa tắt.", pw: false }
        if (e.includes("timeout"))
            return { t: "Hết thời gian chờ: sóng yếu hoặc router không phản hồi. Thử lại gần router hơn.", pw: false }
        if (e.includes("wi-fi is disabled") || e.includes("rfkill") || e.includes("radio"))
            return { t: "Wi-Fi đang bị tắt hoặc bị khoá. Bấm Chẩn đoán để mở khoá.", pw: false }
        if (e.includes("no suitable device") || e.includes("no wi-fi device"))
            return { t: "Không tìm thấy card Wi-Fi (có thể thiếu driver hoặc firmware).", pw: false }
        if (e.includes("ip configuration") || e.includes("dhcp"))
            return { t: "Bắt được sóng nhưng không nhận được địa chỉ IP (lỗi DHCP từ router).", pw: false }
        return { t: err.trim() !== "" ? err.trim().replace(/^Error:\s*/, "") : "Không kết nối được (không rõ lý do).", pw: false }
    }

    function wifiDone(ssid, code, err) {
        if (code === 0) {
            failReason = ""
            msg = "Đã kết nối " + ssid + " ✓"
        } else {
            const r = explainNm(err)
            failSsid = ssid
            failReason = r.t
            failPw = r.pw
            msg = ""
        }
        shell.refreshNet()
        refresh()
    }

    function wifiClick(r) {
        if (r.active) {
            run(["nmcli", "connection", "down", "id", r.ssid], "", "Đang ngắt…")
        } else if (r.secure && !knownNets[r.ssid]) {
            askSsid = r.ssid
            passField.text = ""
            passField.forceActiveFocus()
        } else {
            startWifi(["nmcli", "-w", "25", "dev", "wifi", "connect", r.ssid], "", r.ssid)
        }
    }

    function submitWifi() {
        if (passField.text === "" || askSsid === "") return
        const s = askSsid, p = passField.text
        askSsid = ""
        passField.text = ""
        // Mật khẩu gửi qua stdin (--ask), không nằm trong dòng lệnh
        startWifi(["nmcli", "--ask", "-w", "25", "dev", "wifi", "connect", s], p + "\n", s)
    }

    function submitHidden() {
        const s = hidSsid.text.trim()
        if (s === "") return
        const p = hidPass.text
        hidPass.text = ""
        hiddenOpen = false
        keys.forceActiveFocus()
        startWifi(["nmcli", "--ask", "-w", "25", "dev", "wifi", "connect", s, "hidden", "yes"], p + "\n", s)
    }

    // ---- Quên mạng (xoá hồ sơ cũ, hay dùng khi đổi mật khẩu router) ----
    Process {
        id: forgetP
        property bool thenAsk: false
        property string ssid: ""
        onExited: (code, status) => {
            win.failReason = ""
            if (thenAsk) {
                win.askSsid = ssid
                passField.text = ""
                passField.forceActiveFocus()
            } else {
                win.msg = code === 0 ? "Đã quên mạng " + ssid : "Không có hồ sơ mạng " + ssid
            }
            win.refresh()
        }
    }

    function forget(ssid, thenAsk) {
        forgetP.thenAsk = thenAsk
        forgetP.ssid = ssid
        forgetP.command = ["nmcli", "connection", "delete", "id", ssid]
        forgetP.running = true
    }

    // ================= Chẩn đoán =================
    Process {
        id: diagP
        command: ["sh", win.scriptDir + "/diag.sh"]
        stdout: StdioCollector { onStreamFinished: { win.diagBusy = false; win.buildDiag(text) } }
    }

    function runDiag() {
        diagOpen = true
        diagBusy = true
        diagSummary = ""
        diagModel.clear()
        diagP.running = true
    }

    function buildDiag(text) {
        const d = {}
        for (const line of text.split("\n")) {
            const i = line.indexOf("|")
            if (i > 0) d[line.slice(0, i)] = line.slice(i + 1).trim()
        }
        const items = []
        const add = (ok, label, detail, fixLabel, fixKind, fixCmd, fixArg) =>
            items.push({ ok: ok, label: label, detail: detail, fixLabel: fixLabel || "",
                         fixKind: fixKind || "", fixCmd: fixCmd || "", fixArg: fixArg || "" })

        const nmOk = d.nm === "active"
        add(nmOk, "Dịch vụ NetworkManager", nmOk ? "Đang chạy" : "Không chạy, không thể quản lý mạng",
            nmOk ? "" : "Sao chép lệnh", nmOk ? "" : "copy", "sudo systemctl enable --now NetworkManager")

        const rkOk = d.rfkill === "ok"
        add(rkOk, "Công tắc Wi-Fi (rfkill)",
            rkOk ? "Không bị khoá"
                 : (d.rfkill === "hard" ? "Bị khoá bằng phím/công tắc phần cứng (thử phím máy bay hoặc Fn)"
                                        : "Đang bị khoá mềm"),
            d.rfkill === "soft" ? "Mở khoá" : "", d.rfkill === "soft" ? "run" : "", "rfkill unblock wifi")

        const devOk = d.dev !== "" && d.dev !== "unmanaged" && d.dev !== "unavailable"
        let devDetail = "Có card Wi-Fi (" + d.dev + ")"
        if (d.dev === "") devDetail = "Không thấy card Wi-Fi: có thể thiếu driver hoặc firmware"
        else if (d.dev === "unmanaged") devDetail = "NetworkManager không quản lý card này"
        else if (d.dev === "unavailable") devDetail = "Card chưa sẵn sàng (thường do Wi-Fi bị tắt hoặc khoá)"
        add(devOk, "Card Wi-Fi", devDetail,
            d.dev === "" ? "Sao chép lệnh kiểm tra" : "", d.dev === "" ? "copy" : "",
            "dmesg | grep -iE 'firmware|wlan|iwlwifi|rtw|brcm|ath'")

        const radioOk = d.radio === "enabled"
        add(radioOk, "Wi-Fi đã bật", radioOk ? "Đang bật" : "Đang tắt",
            radioOk ? "" : "Bật Wi-Fi", radioOk ? "" : "run", "nmcli radio wifi on")

        const connected = d.dev === "connected"
        add(connected, "Đã kết nối mạng",
            connected ? "Đang nối " + shell.netName : "Chưa nối mạng nào, hãy chọn mạng trong danh sách")

        if (connected) {
            const gwOk = d.gw !== "" && d.gwping === "ok"
            add(gwOk, "Router (gateway)",
                d.gw === "" ? "Không có đường ra, chưa nhận được IP từ router"
                            : (gwOk ? "Router " + d.gw + " phản hồi" : "Router " + d.gw + " không phản hồi (sóng yếu hoặc router lỗi)"),
                gwOk ? "" : "Làm mới Wi-Fi", gwOk ? "" : "run", "nmcli radio wifi off; sleep 1; nmcli radio wifi on")

            const inetOk = d.inet === "ok"
            add(inetOk, "Ra Internet", inetOk ? "Ping 1.1.1.1 được" : "Không ra được Internet")

            const dnsOk = d.dns === "ok"
            add(dnsOk, "DNS (phân giải tên miền)", dnsOk ? "Hoạt động" : "Lỗi DNS",
                dnsOk ? "" : "Dùng DNS 1.1.1.1", dnsOk ? "" : "run",
                'nmcli connection modify "$1" ipv4.dns "1.1.1.1 8.8.8.8" ipv4.ignore-auto-dns yes && nmcli connection up "$1"',
                shell.netName)

            const code = d.http || ""
            const httpOk = code === "204" || (inetOk && (code === "000" || code === "" || code === "skip"))
            add(httpOk, "Cổng đăng nhập Wi-Fi",
                code === "204" ? "Không bị chặn" : (httpOk ? "Bỏ qua (không kiểm tra được)" : "Mạng yêu cầu đăng nhập (Wi-Fi công cộng)"),
                httpOk ? "" : "Mở trang đăng nhập", httpOk ? "" : "run", "xdg-open http://neverssl.com")
        }

        diagModel.clear()
        items.forEach(it => diagModel.append(it))
        const bad = items.filter(it => !it.ok)
        diagSummary = bad.length === 0 ? "Mọi thứ đều ổn ✓" : "Vấn đề: " + bad[0].label + ", " + bad[0].detail
    }

    Process {
        id: fixer
        property string okMsg: ""
        onExited: (code, status) => {
            win.msg = code === 0 ? okMsg : "Lệnh không thành công"
            diagTimer.restart()
        }
    }
    Timer {
        id: diagTimer
        interval: 1500
        onTriggered: { if (win.diagOpen) win.runDiag(); win.shell.refreshNet(); win.refresh() }
    }

    function runFix(kind, cmd, arg) {
        if (kind === "copy") {
            fixer.okMsg = "Đã sao chép, dán vào terminal để chạy"
            fixer.command = ["sh", "-c", 'printf %s "$1" | wl-copy', "sh", cmd]
        } else {
            fixer.okMsg = "Đã chạy"
            fixer.command = ["sh", "-c", cmd, "sh", arg]
        }
        fixer.running = true
    }

    // ================= Bluetooth =================
    function macMap(text) {
        const m = {}
        for (const line of text.split("\n")) {
            const x = /^Device\s+([0-9A-Fa-f:]{17})\s+(.*)$/.exec(line.trim())
            if (x) m[x[1]] = x[2]
        }
        return m
    }

    Process {
        id: btShow
        command: ["bluetoothctl", "show"]
        stdout: StdioCollector { onStreamFinished: win.btOn = /Powered:\s*yes/.test(text) }
    }
    Process {
        id: btConnP
        command: ["bluetoothctl", "devices", "Connected"]
        stdout: StdioCollector { onStreamFinished: { win.btConn = win.macMap(text); btPairedP.running = true } }
    }
    Process {
        id: btPairedP
        command: ["bluetoothctl", "devices", "Paired"]
        stdout: StdioCollector { onStreamFinished: { win.btPaired = win.macMap(text); btAllP.running = true } }
    }
    Process {
        id: btAllP
        command: ["bluetoothctl", "devices"]
        stdout: StdioCollector { onStreamFinished: win.parseBt(text) }
    }
    Process {
        id: btScan
        command: ["bluetoothctl", "--timeout", "6", "scan", "on"]
        onExited: { win.scanning = false; win.refresh() }
    }

    function startScan() {
        if (!btOn || scanning) return
        scanning = true
        btScan.running = true
    }

    function parseBt(text) {
        const all = macMap(text)
        const rows = []
        for (const mac in all) {
            const name = all[mac]
            if (name.replace(/-/g, ":") === mac) continue        // bỏ thiết bị chưa có tên
            rows.push({ mac: mac, name: name, connected: !!btConn[mac], paired: !!btPaired[mac] })
        }
        rows.sort((a, b) => (b.connected - a.connected) || (b.paired - a.paired) || a.name.localeCompare(b.name))
        btModel.clear()
        rows.forEach(r => btModel.append(r))
    }

    function btClick(r) {
        if (r.connected)
            run(["bluetoothctl", "disconnect", r.mac], "", "Đang ngắt…")
        else if (r.paired)
            run(["bluetoothctl", "connect", r.mac], "", "Đang kết nối…")
        else
            run(["sh", "-c", "bluetoothctl pair \"$1\" && bluetoothctl trust \"$1\" && bluetoothctl connect \"$1\"", "sh", r.mac],
                "", "Đang ghép đôi… (thiết bị cần ở chế độ ghép đôi)")
    }

    function toggleRadio() {
        if (isWifi) run(["nmcli", "radio", "wifi", wifiOn ? "off" : "on"], "", "")
        else run(["sh", "-c", btOn ? "bluetoothctl power off"
                                   : "rfkill unblock bluetooth 2>/dev/null; bluetoothctl power on"], "", "")
    }

    // ---------------- Giao diện ----------------
    MouseArea { anchors.fill: parent; onClicked: win.close() }

    Item {
        id: keys
        focus: true
        Keys.onPressed: e => {
            if (e.key === Qt.Key_Escape) {
                if (win.diagOpen) win.diagOpen = false
                else win.close()
                e.accepted = true
            }
        }
    }

    Rectangle {
        id: panel
        anchors.centerIn: parent
        width: 470
        height: 540
        radius: 22
        color: "#f01e1e2e"
        border.color: "#585b70"
        border.width: 1

        MouseArea { anchors.fill: parent }   // chặn click xuyên xuống nền

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 16
            spacing: 10

            // ---- Thanh tab + công tắc ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 8

                Repeater {
                    model: ["📶  Wi-Fi", "🔵  Bluetooth"]
                    delegate: Rectangle {
                        id: tabBtn
                        required property string modelData
                        required property int index
                        readonly property bool on: win.shell.connectTab === index
                        Layout.preferredHeight: 34
                        Layout.preferredWidth: tabText.implicitWidth + 28
                        radius: 17
                        color: on ? win.accent : "#313244"
                        Text {
                            id: tabText
                            anchors.centerIn: parent
                            text: tabBtn.modelData
                            color: tabBtn.on ? "#1e1e2e" : win.fg
                            font.pixelSize: 13
                            font.bold: tabBtn.on
                        }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: win.shell.connectTab = tabBtn.index
                        }
                    }
                }

                Item { Layout.fillWidth: true }

                // Làm mới / quét
                Rectangle {
                    Layout.preferredWidth: 34; Layout.preferredHeight: 34
                    radius: 17; color: "#313244"
                    Text { anchors.centerIn: parent; text: win.scanning ? "…" : "⟳"; color: win.fg; font.pixelSize: 17 }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: { win.refresh(); win.shell.refreshNet(); if (!win.isWifi) win.startScan() }
                    }
                }

                // Công tắc bật/tắt
                Rectangle {
                    readonly property bool on: win.isWifi ? win.wifiOn : win.btOn
                    Layout.preferredWidth: 46; Layout.preferredHeight: 26
                    radius: 13
                    color: on ? win.accent : "#45475a"
                    Rectangle {
                        width: 20; height: 20; radius: 10; y: 3
                        x: parent.on ? parent.width - width - 3 : 3
                        color: "#ffffff"
                        Behavior on x { NumberAnimation { duration: 120 } }
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: win.toggleRadio()
                    }
                }
            }

            // ---- Dòng trạng thái Internet (chỉ Wi-Fi) ----
            Rectangle {
                visible: win.isWifi && win.wifiOn
                Layout.fillWidth: true
                implicitHeight: 38
                radius: 12
                color: "#313244"

                readonly property string st: win.shell.netState
                readonly property color tone: st === "online" ? win.green
                                              : (st === "offline" ? win.red
                                              : (st === "unknown" ? win.dim : win.orange))

                RowLayout {
                    anchors { fill: parent; leftMargin: 12; rightMargin: 8 }
                    spacing: 8
                    Text { text: "●"; color: parent.parent.tone; font.pixelSize: 12 }
                    Text {
                        Layout.fillWidth: true
                        elide: Text.ElideRight
                        color: win.fg
                        font.pixelSize: 12
                        text: {
                            const s = win.shell.netState, n = win.shell.netName
                            if (s === "online") return n + " · có Internet"
                            if (s === "portal") return n + " · cần đăng nhập Wi-Fi"
                            if (s === "nonet") return n + " · KHÔNG ra được Internet"
                            if (s === "offline") return "Chưa kết nối mạng nào"
                            return "Đang kiểm tra…"
                        }
                    }
                    Pill {
                        visible: win.shell.netState === "portal"
                        h: 26; fs: 11
                        label: "🌐 Đăng nhập"
                        tint: win.orange; textColor: "#1e1e2e"
                        onClicked: win.runFix("run", "xdg-open http://neverssl.com", "")
                    }
                    Pill {
                        h: 26; fs: 11
                        label: "🩺 Chẩn đoán"
                        onClicked: win.runDiag()
                    }
                }
            }

            // ---- Thẻ báo lỗi kết nối ----
            Rectangle {
                visible: win.isWifi && win.failReason !== ""
                Layout.fillWidth: true
                implicitHeight: failCol.implicitHeight + 20
                radius: 12
                color: "#2a1d24"
                border.width: 1
                border.color: win.red

                Column {
                    id: failCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12 }
                    spacing: 6
                    Text {
                        text: "❌  Không kết nối được " + win.failSsid
                        color: win.red
                        font.pixelSize: 13
                        font.bold: true
                    }
                    Text {
                        width: parent.width
                        wrapMode: Text.Wrap
                        text: win.failReason
                        color: win.fg
                        font.pixelSize: 12
                    }
                    Row {
                        spacing: 8
                        Pill {
                            visible: win.failPw
                            h: 28; fs: 12
                            label: "🔑 Nhập lại mật khẩu"
                            tint: win.accent; textColor: "#1e1e2e"
                            onClicked: win.forget(win.failSsid, true)
                        }
                        Pill { h: 28; fs: 12; label: "Quên mạng"; onClicked: win.forget(win.failSsid, false) }
                        Pill { h: 28; fs: 12; label: "🩺 Chẩn đoán"; onClicked: win.runDiag() }
                        Pill { h: 28; fs: 12; label: "✕"; onClicked: win.failReason = "" }
                    }
                }
            }

            // ---- Danh sách ----
            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                Text {
                    anchors.centerIn: parent
                    visible: win.isWifi ? (!win.wifiOn || wifiModel.count === 0) : (!win.btOn || btModel.count === 0)
                    horizontalAlignment: Text.AlignHCenter
                    color: win.dim
                    font.pixelSize: 13
                    lineHeight: 1.3
                    text: win.isWifi
                          ? (win.wifiOn ? "Không thấy mạng nào…\nBấm ⟳ để quét lại, hoặc 🩺 Chẩn đoán" : "Wi-Fi đang tắt")
                          : (win.btOn ? (win.scanning ? "Đang quét thiết bị…" : "Chưa thấy thiết bị nào\nBấm ⟳ để quét lại")
                                      : "Bluetooth đang tắt")
                }

                // Wi-Fi
                ListView {
                    anchors.fill: parent
                    visible: win.isWifi
                    clip: true
                    spacing: 2
                    model: wifiModel
                    delegate: Rectangle {
                        id: wRow
                        required property string ssid
                        required property int signal
                        required property bool secure
                        required property bool active
                        readonly property bool known: !!win.knownNets[ssid]
                        width: ListView.view.width
                        height: 40
                        radius: 10
                        color: rowHover.hovered ? "#45475a" : (active ? "#313244" : "transparent")

                        HoverHandler { id: rowHover }

                        // Vùng bấm để kết nối (khai báo trước để nút "Quên" nằm trên)
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: win.wifiClick({ ssid: wRow.ssid, secure: wRow.secure, active: wRow.active })
                        }

                        Row {
                            anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                            spacing: 10
                            Text {
                                text: signal > 75 ? "▂▄▆█" : (signal > 50 ? "▂▄▆" : (signal > 25 ? "▂▄" : "▂"))
                                color: wRow.active ? win.green : win.fg
                                font.pixelSize: 12
                                anchors.verticalCenter: parent.verticalCenter
                            }
                            Text {
                                text: wRow.ssid
                                color: wRow.active ? win.green : win.fg
                                font.pixelSize: 13
                                font.bold: wRow.active
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }

                        Row {
                            anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                            spacing: 8

                            // Nút "Quên" mạng đã lưu (hiện khi rê chuột)
                            Rectangle {
                                visible: wRow.known && rowHover.hovered
                                width: forgetText.implicitWidth + 16
                                height: 24
                                radius: 12
                                color: forgetArea.containsMouse ? win.red : "#585b70"
                                anchors.verticalCenter: parent.verticalCenter
                                Text {
                                    id: forgetText
                                    anchors.centerIn: parent
                                    text: "Quên"
                                    color: forgetArea.containsMouse ? "#1e1e2e" : win.fg
                                    font.pixelSize: 11
                                    font.bold: true
                                }
                                MouseArea {
                                    id: forgetArea
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    cursorShape: Qt.PointingHandCursor
                                    onClicked: win.forget(wRow.ssid, false)
                                }
                            }
                            Text { visible: wRow.secure; text: "🔒"; font.pixelSize: 12; anchors.verticalCenter: parent.verticalCenter }
                            Text { visible: wRow.active; text: "✓"; color: win.green; font.pixelSize: 15; font.bold: true
                                   anchors.verticalCenter: parent.verticalCenter }
                        }
                    }
                }

                // Bluetooth
                ListView {
                    anchors.fill: parent
                    visible: !win.isWifi
                    clip: true
                    spacing: 2
                    model: btModel
                    delegate: Rectangle {
                        id: bRow
                        required property string mac
                        required property string name
                        required property bool connected
                        required property bool paired
                        width: ListView.view.width
                        height: 40
                        radius: 10
                        color: bArea.containsMouse ? "#45475a" : (connected ? "#313244" : "transparent")

                        Text {
                            anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                            text: bRow.name
                            color: bRow.connected ? win.green : win.fg
                            font.pixelSize: 13
                            font.bold: bRow.connected
                        }
                        Text {
                            anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                            text: bRow.connected ? "Đã kết nối ✓" : (bRow.paired ? "Đã ghép đôi" : "Mới")
                            color: bRow.connected ? win.green : win.dim
                            font.pixelSize: 11
                        }
                        MouseArea {
                            id: bArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: win.btClick({ mac: bRow.mac, connected: bRow.connected, paired: bRow.paired })
                        }
                    }
                }
            }

            // ---- Ô nhập mật khẩu Wi-Fi ----
            Rectangle {
                visible: win.askSsid !== ""
                Layout.fillWidth: true
                Layout.preferredHeight: 44
                radius: 22
                color: "#313244"
                border.width: 1
                border.color: passField.activeFocus ? win.accent : "transparent"

                TextInput {
                    id: passField
                    anchors { fill: parent; leftMargin: 18; rightMargin: 18 }
                    verticalAlignment: TextInput.AlignVCenter
                    echoMode: TextInput.Password
                    passwordCharacter: "•"
                    color: win.fg
                    font.pixelSize: 14
                    clip: true

                    Text {
                        visible: passField.text === ""
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Mật khẩu cho " + win.askSsid + "…"
                        color: win.dim
                        font.pixelSize: 14
                    }
                    Keys.onPressed: e => {
                        if (e.key === Qt.Key_Escape) {
                            win.askSsid = ""
                            passField.text = ""
                            keys.forceActiveFocus()
                            e.accepted = true
                        } else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) {
                            win.submitWifi()
                            e.accepted = true
                        }
                    }
                }
            }

            // ---- Form nối mạng ẩn ----
            Rectangle {
                visible: win.hiddenOpen
                Layout.fillWidth: true
                implicitHeight: 100
                radius: 14
                color: "#313244"

                Column {
                    anchors { fill: parent; margins: 10 }
                    spacing: 8

                    Rectangle {
                        width: parent.width; height: 34; radius: 17; color: "#1e1e2e"
                        border.width: 1; border.color: hidSsid.activeFocus ? win.accent : "transparent"
                        TextInput {
                            id: hidSsid
                            anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                            verticalAlignment: TextInput.AlignVCenter
                            color: win.fg; font.pixelSize: 13; clip: true
                            Text { visible: hidSsid.text === ""; anchors.verticalCenter: parent.verticalCenter
                                   text: "Tên mạng ẩn (SSID)…"; color: win.dim; font.pixelSize: 13 }
                            Keys.onPressed: e => {
                                if (e.key === Qt.Key_Escape) { win.hiddenOpen = false; keys.forceActiveFocus(); e.accepted = true }
                                else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) { hidPass.forceActiveFocus(); e.accepted = true }
                            }
                        }
                    }
                    Rectangle {
                        width: parent.width; height: 34; radius: 17; color: "#1e1e2e"
                        border.width: 1; border.color: hidPass.activeFocus ? win.accent : "transparent"
                        TextInput {
                            id: hidPass
                            anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                            verticalAlignment: TextInput.AlignVCenter
                            echoMode: TextInput.Password
                            passwordCharacter: "•"
                            color: win.fg; font.pixelSize: 13; clip: true
                            Text { visible: hidPass.text === ""; anchors.verticalCenter: parent.verticalCenter
                                   text: "Mật khẩu (để trống nếu mạng mở) · Enter để nối"; color: win.dim; font.pixelSize: 13 }
                            Keys.onPressed: e => {
                                if (e.key === Qt.Key_Escape) { win.hiddenOpen = false; keys.forceActiveFocus(); e.accepted = true }
                                else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) { win.submitHidden(); e.accepted = true }
                            }
                        }
                    }
                }
            }

            // ---- Thông báo + nút mạng ẩn ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 8
                Text {
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                    text: win.msg !== "" ? win.msg
                          : (win.isWifi ? "Bấm mạng để kết nối / ngắt · rê chuột để thấy nút Quên" : "Bấm thiết bị để kết nối / ngắt")
                    color: win.msg === "Không thành công" ? win.red : win.dim
                    font.pixelSize: 12
                }
                Pill {
                    visible: win.isWifi
                    h: 28; fs: 12
                    label: "＋ Mạng ẩn"
                    onClicked: {
                        win.hiddenOpen = !win.hiddenOpen
                        if (win.hiddenOpen) hidSsid.forceActiveFocus()
                    }
                }
            }
        }

        // ================= Lớp chẩn đoán =================
        Rectangle {
            visible: win.diagOpen
            anchors.fill: parent
            radius: 22
            color: "#fa1e1e2e"
            z: 5

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 16
                spacing: 10

                RowLayout {
                    Layout.fillWidth: true
                    Pill { label: "←"; onClicked: win.diagOpen = false }
                    Text {
                        Layout.fillWidth: true
                        text: "🩺  Chẩn đoán Wi-Fi"
                        color: win.fg
                        font.pixelSize: 16
                        font.bold: true
                    }
                    Pill { label: "Kiểm tra lại"; onClicked: win.runDiag() }
                }

                Text {
                    Layout.fillWidth: true
                    wrapMode: Text.Wrap
                    text: win.diagBusy ? "Đang kiểm tra… (mất vài giây)" : win.diagSummary
                    color: win.diagBusy ? win.dim : (win.diagSummary.startsWith("Mọi") ? win.green : win.orange)
                    font.pixelSize: 13
                    font.bold: true
                }

                ListView {
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    spacing: 6
                    model: diagModel
                    delegate: Rectangle {
                        id: dRow
                        required property bool ok
                        required property string label
                        required property string detail
                        required property string fixLabel
                        required property string fixKind
                        required property string fixCmd
                        required property string fixArg
                        width: ListView.view.width
                        implicitHeight: dCol.implicitHeight + 16
                        height: implicitHeight
                        radius: 10
                        color: "#313244"

                        Text {
                            id: dIcon
                            anchors { left: parent.left; leftMargin: 12; top: parent.top; topMargin: 9 }
                            text: dRow.ok ? "✓" : "✗"
                            color: dRow.ok ? win.green : win.red
                            font.pixelSize: 16
                            font.bold: true
                        }
                        Column {
                            id: dCol
                            anchors { left: dIcon.right; leftMargin: 10; right: dFix.left; rightMargin: 8; top: parent.top; topMargin: 8 }
                            spacing: 2
                            Text { text: dRow.label; color: win.fg; font.pixelSize: 13; font.bold: true }
                            Text { width: parent.width; wrapMode: Text.Wrap; text: dRow.detail
                                   color: dRow.ok ? win.dim : win.orange; font.pixelSize: 11 }
                        }
                        Pill {
                            id: dFix
                            visible: dRow.fixLabel !== ""
                            anchors { right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                            h: 28; fs: 11
                            label: dRow.fixLabel
                            tint: win.accent; textColor: "#1e1e2e"
                            onClicked: win.runFix(dRow.fixKind, dRow.fixCmd, dRow.fixArg)
                        }
                    }
                }

                Text {
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                    text: win.msg
                    color: win.dim
                    font.pixelSize: 12
                }
            }
        }
    }
}
