import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import Qt.labs.folderlistmodel

// Thư viện file nhận từ điện thoại (thư mục share_png): xem ảnh, mở file, xoá, mã QR / địa chỉ để điện thoại truy cập.
// Mở bằng nút nổi ở mép phải màn hình, Win+A hoặc: qs -c study ipc call share toggle.  Esc để đóng.
PanelWindow {
    id: win
    property var shell

    readonly property color accent: "#89b4fa"
    readonly property color fg: "#cdd6f4"
    readonly property color dim: "#9399b2"
    property int viewIdx: -1                      // -1: đang xem lưới, >= 0: đang xem ảnh lớn
    property bool confirmDel: false

    visible: shell.shareOpen
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-share"
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "#99000000"

    function close() { viewIdx = -1; confirmDel = false; shell.shareOpen = false }
    onVisibleChanged: if (visible) { viewIdx = -1; confirmDel = false; keys.forceActiveFocus() }

    function isImg(name) { return /\.(png|jpe?g|webp|gif|bmp)$/i.test(name || "") }
    function pathAt(i) { return (i >= 0 && i < files.count) ? files.get(i, "filePath") : "" }
    function nameAt(i) { return (i >= 0 && i < files.count) ? files.get(i, "fileName") : "" }
    function openFile(p) { openProc.command = ["xdg-open", p]; openProc.running = true }
    function openDir() { openProc.command = ["xdg-open", shell.shareDir]; openProc.running = true }
    function delFile(p) {
        if (p === "" || p.indexOf(shell.shareDir + "/") !== 0) return
        rmProc.command = ["rm", "-f", p]
        rmProc.running = true
    }
    function copyImg(p) {
        copyProc.command = ["sh", "-c", 'case "$1" in *.png) m=image/png;; *.webp) m=image/webp;; *.gif) m=image/gif;; *.bmp) m=image/bmp;; *) m=image/jpeg;; esac; wl-copy -t "$m" < "$1"', "sh", p]
        copyProc.running = true
        shell.notifyIsland("📋", "Đã sao chép ảnh", -1, "#a6e3a1")
    }
    function copyText(t) {
        copyProc.command = ["wl-copy", t]
        copyProc.running = true
        shell.notifyIsland("📋", "Đã sao chép địa chỉ", -1, "#a6e3a1")
    }
    // Chuyển sang ảnh kế tiếp / trước đó (bỏ qua file không phải ảnh)
    function step(dir) {
        confirmDel = false
        let i = viewIdx
        for (let k = 0; k < files.count; k++) {
            i += dir
            if (i < 0) i = files.count - 1
            if (i >= files.count) i = 0
            if (isImg(nameAt(i))) { viewIdx = i; return }
        }
    }
    function deleteCurrent() {
        if (!confirmDel) { confirmDel = true; confirmTimer.restart(); return }
        const p = pathAt(viewIdx)
        confirmDel = false
        viewIdx = -1                              // xoá xong quay về lưới (danh sách tự cập nhật)
        delFile(p)
    }

    Timer { id: confirmTimer; interval: 2500; onTriggered: win.confirmDel = false }
    Process { id: openProc }
    Process { id: rmProc }
    Process { id: copyProc }

    FolderListModel {
        id: files
        folder: win.shell.shareDirReady ? "file://" + win.shell.shareDir : ""
        showDirs: false
        sortField: FolderListModel.Time
        sortReversed: true                        // mới nhất ở trước
    }

    component Pill: Rectangle {
        id: pill
        property string label: ""
        property color tint: "#313244"
        property color textColor: "#cdd6f4"
        property int h: 34
        signal clicked()
        implicitWidth: pillText.implicitWidth + 28
        implicitHeight: h
        radius: h / 2
        color: pillArea.pressed ? Qt.darker(tint, 1.2) : (pillArea.containsMouse ? Qt.lighter(tint, 1.25) : tint)
        Text { id: pillText; anchors.centerIn: parent; text: pill.label; color: pill.textColor; font.pixelSize: 13; font.bold: true }
        MouseArea { id: pillArea; anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor; onClicked: pill.clicked() }
    }

    // Bấm ra ngoài thẻ để đóng
    MouseArea { anchors.fill: parent; onClicked: win.close() }

    Item {
        id: keys
        anchors.fill: parent
        focus: true
        Keys.onPressed: e => {
            if (e.key === Qt.Key_Escape) {
                if (win.viewIdx >= 0) { win.viewIdx = -1; win.confirmDel = false } else win.close()
                e.accepted = true
            } else if (win.viewIdx >= 0 && e.key === Qt.Key_Left) { win.step(-1); e.accepted = true }
            else if (win.viewIdx >= 0 && e.key === Qt.Key_Right) { win.step(1); e.accepted = true }
            else if (win.viewIdx >= 0 && e.key === Qt.Key_Delete) { win.deleteCurrent(); e.accepted = true }
        }
    }

    Rectangle {
        id: card
        anchors.centerIn: parent
        width: Math.min(1020, win.width - 80)
        height: Math.min(700, win.height - 80)
        radius: 24
        color: "#1e1e2e"
        border.width: 1
        border.color: "#45475a"
        clip: true

        MouseArea { anchors.fill: parent }        // chặn bấm xuyên xuống nền

        // ---------- Tiêu đề ----------
        Text {
            x: 24
            y: 20
            text: "📲  Nhận file từ điện thoại"
            color: win.fg
            font.pixelSize: 18
            font.bold: true
        }
        Rectangle {
            x: card.width - 54
            y: 14
            width: 36
            height: 36
            radius: 18
            color: xArea.containsMouse ? "#45475a" : "transparent"
            Text { anchors.centerIn: parent; text: "✕"; color: win.dim; font.pixelSize: 15 }
            MouseArea { id: xArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.close() }
        }

        // ---------- Cột trái: cách kết nối ----------
        Column {
            x: 24
            y: 68
            width: 250
            spacing: 12

            Row {
                spacing: 8
                Rectangle {
                    width: 10; height: 10; radius: 5
                    anchors.verticalCenter: parent.verticalCenter
                    color: !win.shell.shareOn ? "#6c7086" : (win.shell.shareUp ? "#a6e3a1" : "#f9e2af")
                }
                Text {
                    text: !win.shell.shareOn ? "Đang tắt" : (win.shell.shareUp ? "Đang chờ file từ điện thoại" : "Đang khởi động…")
                    color: win.fg
                    font.pixelSize: 13
                }
            }

            Text {
                width: parent.width
                text: "Điện thoại và máy tính dùng chung WiFi. Quét mã QR hoặc gõ địa chỉ này vào trình duyệt trên điện thoại:"
                color: win.dim
                font.pixelSize: 12
                wrapMode: Text.WordWrap
            }

            Text {
                width: parent.width
                text: win.shell.shareUrl !== "" ? win.shell.shareUrl : "—"
                color: win.accent
                font.pixelSize: 17
                font.bold: true
                elide: Text.ElideRight
            }

            Rectangle {
                width: 196
                height: 196
                radius: 14
                color: "#ffffff"
                visible: win.shell.shareQr.length > 0 && win.shell.shareOn
                Canvas {
                    id: qr
                    anchors.fill: parent
                    property var m: win.shell.shareQr
                    onMChanged: requestPaint()
                    onVisibleChanged: if (visible) requestPaint()
                    onPaint: {
                        const ctx = getContext("2d")
                        ctx.fillStyle = "#ffffff"
                        ctx.fillRect(0, 0, width, height)
                        const n = m ? m.length : 0
                        if (n === 0) return
                        const cell = Math.floor(width / (n + 6))
                        const off = Math.floor((width - cell * n) / 2)
                        ctx.fillStyle = "#000000"
                        for (let y = 0; y < n; y++)
                            for (let x = 0; x < n; x++)
                                if (m[y].charAt(x) === "1") ctx.fillRect(off + x * cell, off + y * cell, cell, cell)
                    }
                }
            }

            Row {
                spacing: 8
                Pill { label: "Sao chép"; visible: win.shell.shareUrl !== ""; onClicked: win.copyText(win.shell.shareUrl) }
                Pill { label: "📂 Mở thư mục"; onClicked: win.openDir() }
            }
            Pill {
                label: "📟 Gửi QR + local sang OLED"
                visible: win.shell.shareUrl !== "" && win.shell.shareQr.length > 0
                tint: "#3b3d61"
                onClicked: win.shell.sharePushToBuddy(true, false)
            }
            Pill {
                label: win.shell.shareOn ? "Tắt nhận file" : "Bật nhận file"
                tint: win.shell.shareOn ? "#313244" : "#3b5b3b"
                onClicked: win.shell.shareSetOn(!win.shell.shareOn)
            }

            Text {
                width: parent.width
                visible: win.shell.shareIps.length > 1
                text: "Địa chỉ khác: " + win.shell.shareIps.slice(1).join(", ")
                color: win.dim
                font.pixelSize: 11
                wrapMode: Text.WordWrap
            }
            Text {
                width: parent.width
                visible: win.shell.sharePin
                text: "🔒 Có mã PIN (file share.pin)"
                color: win.dim
                font.pixelSize: 11
            }
            Text {
                width: parent.width
                visible: win.shell.shareNote !== ""
                text: win.shell.shareNote
                color: "#f38ba8"
                font.pixelSize: 12
                wrapMode: Text.WordWrap
            }
            Text {
                width: parent.width
                text: "Ai cùng mạng WiFi cũng gửi được tới trang này (file chỉ vào share_png khi bạn bấm Lưu). Nếu điện thoại không vào được, kiểm tra tường lửa cổng 8765."
                color: "#6c7086"
                font.pixelSize: 10
                wrapMode: Text.WordWrap
            }
        }

        // ---------- Cột phải: file chờ + lưới file đã lưu ----------
        Item {
            id: right
            x: 300
            y: 68
            width: card.width - 324
            height: card.height - 88

            Column {
                id: topCol
                width: parent.width
                spacing: 10

                // Đang chờ quyết định
                Rectangle {
                    width: parent.width
                    height: 64
                    radius: 16
                    color: "#2a3250"
                    border.width: 1
                    border.color: "#4a5a90"
                    visible: win.shell.sharePending.length > 0
                    Text {
                        anchors { left: parent.left; leftMargin: 18; verticalCenter: parent.verticalCenter }
                        text: "Đang chờ " + win.shell.sharePending.length + " file"
                        color: win.fg
                        font.pixelSize: 14
                        font.bold: true
                    }
                    Row {
                        anchors { right: parent.right; rightMargin: 14; verticalCenter: parent.verticalCenter }
                        spacing: 8
                        Pill { label: "Lưu tất cả"; tint: win.accent; textColor: "#11111b"; onClicked: win.shell.shareFinish(true) }
                        Pill { label: "Bỏ qua"; onClicked: win.shell.shareFinish(false) }
                    }
                }

                Text {
                    text: "Đã lưu (" + files.count + ")  ·  share_png"
                    color: win.dim
                    font.pixelSize: 12
                }
            }

            GridView {
                id: grid
                anchors { top: topCol.bottom; topMargin: 8; left: parent.left; right: parent.right; bottom: parent.bottom }
                clip: true
                model: files
                readonly property int cols: Math.max(2, Math.floor(width / 150))
                cellWidth: Math.floor(width / cols)
                cellHeight: 136
                boundsBehavior: Flickable.StopAtBounds

                delegate: Item {
                    id: tile
                    required property int index
                    required property string fileName
                    required property string filePath
                    required property var fileSize
                    readonly property bool img: win.isImg(fileName)
                    property bool askDel: false
                    width: grid.cellWidth
                    height: grid.cellHeight

                    Timer { id: askTimer; interval: 2500; onTriggered: tile.askDel = false }

                    Rectangle {
                        anchors { fill: parent; margins: 5 }
                        radius: 14
                        color: "#181825"
                        border.width: tileArea.containsMouse ? 2 : 1
                        border.color: tileArea.containsMouse ? win.accent : "#313244"
                        clip: true

                        Image {
                            anchors.fill: parent
                            visible: tile.img
                            source: tile.img ? "file://" + tile.filePath : ""
                            fillMode: Image.PreserveAspectCrop
                            asynchronous: true
                            cache: false
                            sourceSize.width: 320
                            sourceSize.height: 260
                        }
                        Column {
                            anchors.centerIn: parent
                            anchors.verticalCenterOffset: -10
                            visible: !tile.img
                            spacing: 2
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: win.shell.fileIcon(tile.fileName); font.pixelSize: 38 }
                            Text {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: win.shell.fmtBytes(tile.fileSize)
                                color: win.dim
                                font.pixelSize: 10
                            }
                        }
                        Rectangle {
                            anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
                            height: 24
                            color: "#cc11111b"
                            Text {
                                anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                                verticalAlignment: Text.AlignVCenter
                                text: tile.fileName
                                color: win.fg
                                font.pixelSize: 11
                                elide: Text.ElideMiddle
                            }
                        }

                        MouseArea {
                            id: tileArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                if (tile.img) { win.confirmDel = false; win.viewIdx = tile.index }
                                else win.openFile(tile.filePath)
                            }
                        }

                        // Nút xoá (bấm hai lần)
                        Rectangle {
                            visible: tileArea.containsMouse || tile.askDel || trashArea.containsMouse
                            anchors { top: parent.top; right: parent.right; margins: 6 }
                            width: tile.askDel ? 64 : 28
                            height: 28
                            radius: 14
                            color: tile.askDel ? "#f38ba8" : "#cc11111b"
                            Text {
                                anchors.centerIn: parent
                                text: tile.askDel ? "Xoá?" : "🗑"
                                color: tile.askDel ? "#11111b" : win.fg
                                font.pixelSize: tile.askDel ? 12 : 13
                                font.bold: tile.askDel
                            }
                            MouseArea {
                                id: trashArea
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    if (tile.askDel) win.delFile(tile.filePath)
                                    else { tile.askDel = true; askTimer.restart() }
                                }
                            }
                        }
                    }
                }
            }

            Text {
                anchors.centerIn: grid
                visible: files.count === 0
                width: grid.width - 40
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                text: "Chưa có file nào.\nMở địa chỉ bên trái trên điện thoại rồi chọn file để gửi."
                color: "#6c7086"
                font.pixelSize: 13
            }
        }

        // ---------- Xem ảnh lớn ----------
        Rectangle {
            id: viewer
            anchors.fill: parent
            visible: win.viewIdx >= 0
            color: "#f2181825"
            radius: card.radius

            MouseArea { anchors.fill: parent; onClicked: win.viewIdx = -1 }

            Image {
                id: big
                anchors { fill: parent; margins: 28; bottomMargin: 92 }
                source: (win.viewIdx >= 0 && win.isImg(win.nameAt(win.viewIdx))) ? "file://" + win.pathAt(win.viewIdx) : ""
                fillMode: Image.PreserveAspectFit
                asynchronous: true
                cache: false
            }

            Rectangle {
                x: 14
                y: (parent.height - 92) / 2 - 24
                width: 48; height: 48; radius: 24
                color: lArea.containsMouse ? "#45475a" : "#99313244"
                Text { anchors.centerIn: parent; text: "‹"; color: win.fg; font.pixelSize: 30 }
                MouseArea { id: lArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.step(-1) }
            }
            Rectangle {
                x: parent.width - 62
                y: (parent.height - 92) / 2 - 24
                width: 48; height: 48; radius: 24
                color: rArea.containsMouse ? "#45475a" : "#99313244"
                Text { anchors.centerIn: parent; text: "›"; color: win.fg; font.pixelSize: 30 }
                MouseArea { id: rArea; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.step(1) }
            }

            Column {
                anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 18 }
                spacing: 10
                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: win.nameAt(win.viewIdx) + "   ·   " + (win.viewIdx + 1) + " / " + files.count
                    color: win.fg
                    font.pixelSize: 13
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 8
                    Pill { label: "Sao chép ảnh"; onClicked: win.copyImg(win.pathAt(win.viewIdx)) }
                    Pill { label: "Mở bằng ứng dụng"; onClicked: win.openFile(win.pathAt(win.viewIdx)) }
                    Pill {
                        label: win.confirmDel ? "Bấm lần nữa để xoá" : "🗑 Xoá"
                        tint: win.confirmDel ? "#f38ba8" : "#313244"
                        textColor: win.confirmDel ? "#11111b" : "#cdd6f4"
                        onClicked: win.deleteCurrent()
                    }
                    Pill { label: "Đóng"; onClicked: win.viewIdx = -1 }
                }
            }
        }
    }
}
