import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import QtQuick
import QtQuick.Layouts
import Qt.labs.folderlistmodel

// Thư viện ảnh kỷ niệm: lưới ảnh, bấm để xem to, có nút "Đặt làm nền".
// Ảnh lưu ở ~/.config/quickshell/study/memories
PanelWindow {
    id: win
    property var shell

    readonly property color accent: "#f5c2e7"
    readonly property color fg: "#cdd6f4"
    readonly property color dim: "#7f849c"
    readonly property string dir: shell.memDir

    property int viewIndex: -1          // -1 = đang ở lưới, >= 0 = đang xem to
    property bool addOpen: false
    property bool delArmed: false
    property string msg: ""

    visible: shell.memoryOpen
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "qs-memories"
    WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    color: "#b3000000"

    FolderListModel {
        id: photos
        folder: "file://" + win.dir
        nameFilters: ["*.png", "*.jpg", "*.jpeg", "*.webp", "*.PNG", "*.JPG", "*.JPEG", "*.WEBP"]
        showDirs: false
        sortField: FolderListModel.Time
        sortReversed: true              // ảnh mới nhất lên đầu
    }

    readonly property string viewPath:
        (viewIndex >= 0 && viewIndex < photos.count) ? photos.get(viewIndex, "filePath") : ""
    readonly property string viewName:
        (viewIndex >= 0 && viewIndex < photos.count) ? photos.get(viewIndex, "fileName") : ""

    function close() { viewIndex = -1; addOpen = false; shell.memoryOpen = false }

    function step(d) {
        if (photos.count === 0) return
        viewIndex = (viewIndex + d + photos.count) % photos.count
        delArmed = false
    }

    function toast(t) { msg = t; toastTimer.restart() }
    Timer { id: toastTimer; interval: 2600; onTriggered: win.msg = "" }

    onVisibleChanged: {
        viewIndex = -1
        addOpen = false
        delArmed = false
        msg = ""
        if (visible) keys.forceActiveFocus()
    }

    // ---------- Chạy lệnh (thêm / xoá ảnh) ----------
    Process {
        id: runner
        property string okMsg: ""
        onExited: (code, status) => win.toast(code === 0 ? okMsg : "Không thực hiện được")
    }

    function run(cmd, okMsg) {
        runner.okMsg = okMsg
        runner.command = cmd
        runner.running = true
    }

    // Thêm ảnh từ đường dẫn (file hoặc cả thư mục) -> chép vào thư mục kỷ niệm
    function addPath(text) {
        const p = text.trim().replace(/^["']|["']$/g, "").replace(/^~/, shell.home)
        if (p === "") return
        const script =
            'dest="$1"; shift; mkdir -p "$dest"; n=0\n' +
            'for p in "$@"; do\n' +
            '  if [ -d "$p" ]; then\n' +
            '    for f in "$p"/*.png "$p"/*.jpg "$p"/*.jpeg "$p"/*.webp; do [ -f "$f" ] && cp -n "$f" "$dest/" && n=$((n+1)); done\n' +
            '  elif [ -f "$p" ]; then cp -n "$p" "$dest/" && n=$((n+1)); fi\n' +
            'done\n' +
            '[ "$n" -gt 0 ]'
        run(["sh", "-c", script, "sh", dir, p], "Đã thêm vào kỷ niệm 💖")
    }

    // Dán ảnh đang có trong clipboard (cần wl-clipboard)
    function pasteClipboard() {
        const script =
            'mkdir -p "$1"; f="$1/$(date +%Y%m%d-%H%M%S).png"\n' +
            'wl-paste -t image/png > "$f" 2>/dev/null && [ -s "$f" ] || { rm -f "$f"; exit 1; }'
        run(["sh", "-c", script, "sh", dir], "Đã dán ảnh từ clipboard 💖")
    }

    function deleteCurrent() {
        if (viewPath === "") return
        if (!delArmed) { delArmed = true; return }
        const p = viewPath
        viewIndex = -1
        delArmed = false
        run(["sh", "-c", 'gio trash "$1" 2>/dev/null || rm -f "$1"', "sh", p], "Đã xoá ảnh")
    }

    // ---------- Nút bấm dùng chung ----------
    component Pill: Rectangle {
        id: pill
        property string label: ""
        property color tint: "#313244"
        property color textColor: "#cdd6f4"
        signal clicked()
        implicitWidth: pillText.implicitWidth + 28
        implicitHeight: 34
        radius: 17
        color: pillArea.containsMouse ? Qt.lighter(tint, 1.25) : tint
        Behavior on color { ColorAnimation { duration: 100 } }
        Text {
            id: pillText
            anchors.centerIn: parent
            text: pill.label
            color: pill.textColor
            font.pixelSize: 13
            font.bold: true
        }
        MouseArea {
            id: pillArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: pill.clicked()
        }
    }

    // ---------- Bàn phím ----------
    Item {
        id: keys
        focus: true
        Keys.onPressed: e => {
            if (e.key === Qt.Key_Escape) {
                if (win.viewIndex >= 0) win.viewIndex = -1
                else win.close()
                e.accepted = true
            } else if (win.viewIndex >= 0 && e.key === Qt.Key_Left) { win.step(-1); e.accepted = true }
            else if (win.viewIndex >= 0 && e.key === Qt.Key_Right) { win.step(1); e.accepted = true }
        }
    }

    // Click ra ngoài để đóng
    MouseArea { anchors.fill: parent; onClicked: win.close() }

    // ================= LƯỚI ẢNH =================
    Rectangle {
        id: panel
        width: 820
        height: 580
        anchors.centerIn: parent
        radius: 26
        color: "#f01e1e2e"
        border.color: "#585b70"
        border.width: 1

        MouseArea { anchors.fill: parent }   // chặn click xuyên xuống nền

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 12

            RowLayout {
                Layout.fillWidth: true
                spacing: 10

                Column {
                    Layout.fillWidth: true
                    spacing: 2
                    Text {
                        text: "💖  Kỷ niệm"
                        color: win.accent
                        font.pixelSize: 22
                        font.bold: true
                    }
                    Text {
                        text: photos.count + " ảnh · lưu tại ~/.config/quickshell/study/memories"
                        color: win.dim
                        font.pixelSize: 11
                    }
                }

                Pill { label: "＋ Thêm ảnh"; tint: win.accent; textColor: "#1e1e2e"
                       onClicked: { win.addOpen = !win.addOpen; if (win.addOpen) pathField.forceActiveFocus() } }
                Pill { label: "📋 Dán"; onClicked: win.pasteClipboard() }
                Pill { label: "✕"; onClicked: win.close() }
            }

            // Ô nhập đường dẫn để thêm ảnh
            Rectangle {
                visible: win.addOpen
                Layout.fillWidth: true
                Layout.preferredHeight: 42
                radius: 21
                color: "#313244"
                border.width: 1
                border.color: pathField.activeFocus ? win.accent : "transparent"

                TextInput {
                    id: pathField
                    anchors { fill: parent; leftMargin: 18; rightMargin: 18 }
                    verticalAlignment: TextInput.AlignVCenter
                    color: win.fg
                    font.pixelSize: 14
                    clip: true
                    selectByMouse: true

                    Text {
                        visible: pathField.text === ""
                        anchors.verticalCenter: parent.verticalCenter
                        text: "Dán đường dẫn ảnh hoặc cả thư mục rồi nhấn Enter…  (vd: ~/Pictures/chuyen-di)"
                        color: win.dim
                        font.pixelSize: 13
                    }
                    Keys.onPressed: e => {
                        if (e.key === Qt.Key_Escape) {
                            win.addOpen = false
                            pathField.text = ""
                            keys.forceActiveFocus()
                            e.accepted = true
                        } else if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) {
                            win.addPath(pathField.text)
                            pathField.text = ""
                            win.addOpen = false
                            keys.forceActiveFocus()
                            e.accepted = true
                        }
                    }
                }
            }

            Item {
                Layout.fillWidth: true
                Layout.fillHeight: true

                Text {
                    anchors.centerIn: parent
                    visible: photos.count === 0
                    horizontalAlignment: Text.AlignHCenter
                    color: win.dim
                    font.pixelSize: 14
                    lineHeight: 1.4
                    text: "Chưa có ảnh kỷ niệm nào\nBấm “＋ Thêm ảnh” để chọn ảnh, hoặc “📋 Dán” để dán ảnh từ clipboard"
                }

                GridView {
                    id: grid
                    anchors.fill: parent
                    clip: true
                    model: photos
                    cellWidth: Math.floor(width / 4)
                    cellHeight: Math.floor(cellWidth * 0.74)

                    delegate: Item {
                        id: cell
                        required property string filePath
                        required property string fileName
                        required property int index
                        width: grid.cellWidth
                        height: grid.cellHeight

                        Rectangle {
                            anchors.fill: parent
                            anchors.margins: 6
                            radius: 12
                            color: "#313244"
                            clip: true
                            scale: cellArea.containsMouse ? 1.04 : 1.0
                            Behavior on scale { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
                            border.width: cellArea.containsMouse ? 2 : 0
                            border.color: win.accent

                            Image {
                                anchors.fill: parent
                                anchors.margins: 2
                                source: "file://" + cell.filePath
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                sourceSize: Qt.size(380, 280)     // giải mã nhỏ cho nhẹ RAM
                            }

                            // Dải tên file mờ ở đáy
                            Rectangle {
                                anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
                                height: 24
                                color: "#99000000"
                                opacity: cellArea.containsMouse ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                                Text {
                                    anchors { fill: parent; leftMargin: 8; rightMargin: 8 }
                                    verticalAlignment: Text.AlignVCenter
                                    text: cell.fileName
                                    elide: Text.ElideMiddle
                                    color: "#ffffff"
                                    font.pixelSize: 10
                                }
                            }

                            MouseArea {
                                id: cellArea
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: { win.viewIndex = cell.index; win.delArmed = false }
                            }
                        }
                    }
                }
            }
        }
    }

    // ================= XEM TO =================
    Item {
        id: viewer
        anchors.fill: parent
        visible: win.viewIndex >= 0
        z: 10

        Rectangle { anchors.fill: parent; color: "#f2000000" }
        MouseArea { anchors.fill: parent; onClicked: win.viewIndex = -1 }   // click nền để quay lại

        Image {
            id: big
            anchors { fill: parent; margins: 48; bottomMargin: 128 }
            source: win.viewPath !== "" ? "file://" + win.viewPath : ""
            fillMode: Image.PreserveAspectFit
            asynchronous: true
            cache: false
            sourceSize: Qt.size(win.width, win.height)
            opacity: status === Image.Ready ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 260; easing.type: Easing.InOutSine } }
        }
        MouseArea { anchors.fill: big }   // click vào ảnh: không đóng

        Column {
            anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 28 }
            spacing: 12

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: (win.viewIndex + 1) + " / " + photos.count + "  ·  " + win.viewName
                color: win.dim
                font.pixelSize: 12
            }

            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 10
                Pill { label: "‹"; onClicked: win.step(-1) }
                Pill {
                    label: "🖼  Đặt làm nền"
                    tint: win.accent
                    textColor: "#1e1e2e"
                    onClicked: { win.shell.setWallpaperFile(win.viewPath); win.toast("Đã đặt làm nền ✓") }
                }
                Pill {
                    label: win.delArmed ? "Bấm lần nữa để xoá" : "🗑 Xoá"
                    tint: win.delArmed ? "#f38ba8" : "#313244"
                    textColor: win.delArmed ? "#1e1e2e" : "#cdd6f4"
                    onClicked: win.deleteCurrent()
                }
                Pill { label: "✕ Đóng"; onClicked: win.viewIndex = -1 }
                Pill { label: "›"; onClicked: win.step(1) }
            }
        }
    }

    // ---------- Thông báo nhỏ ----------
    Rectangle {
        visible: win.msg !== ""
        z: 30
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 28 }
        width: toastText.implicitWidth + 36
        height: 34
        radius: 17
        color: "#f01e1e2e"
        border.width: 1
        border.color: win.accent
        Text {
            id: toastText
            anchors.centerIn: parent
            text: win.msg
            color: win.fg
            font.pixelSize: 13
        }
    }
}
