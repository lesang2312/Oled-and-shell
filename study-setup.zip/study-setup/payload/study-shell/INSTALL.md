# Cài đặt bộ study-shell (Hyprland Lua + Quickshell)

Cấu trúc gói:
```
quickshell/study/   shell.qml Bar.qml Launcher.qml Wallpaper.qml Pomodoro.qml
hypr/hyprland.lua   cấu hình Hyprland (Lua, cần Hyprland 0.55+)
README.md           mô tả shell
```

## Cách nhanh nhất (khuyên dùng)
```sh
unzip -o study-shell.zip && cd study-shell && sh install.sh
pkill qs; qs -c study
```
Script xoá bản cũ, chép đúng chỗ, giữ lại ảnh chụp trong `scr/` và tự kiểm tra đúng bản.

## Làm tay (nếu không dùng script)
```sh
unzip study-shell.zip && cd study-shell

mkdir -p ~/.config/quickshell ~/.config/hypr ~/Pictures/Wallpapers ~/.cache/qs-study
rm -rf ~/.config/quickshell/study            # xoá bản cũ nếu có
mkdir -p ~/.config/quickshell/study
cp -r quickshell/study/. ~/.config/quickshell/study/   # dấu "/." để không bị lồng study/study
cp hypr/hyprland.lua ~/.config/hypr/hyprland.lua    # sao lưu file cũ trước nếu có
```
Kết quả phải là `~/.config/quickshell/study/shell.qml` (không lồng thêm thư mục).
Chạy thử: `pkill qs; qs -c study`.

## Gói cần cài
- Bắt buộc: `hyprland` (0.55+), `quickshell`, `pipewire` + `wireplumber`, `upower`
- Dùng trong hyprland.lua: `kitty`, `btop`, `grim`, `slurp`, `wl-clipboard`,
  `brightnessctl`, `libnotify`, `firefox`  (bảng ứng dụng đã có sẵn trong shell, không cần fuzzel)
- Icon cho bảng ứng dụng: `papirus-icon-theme` (shell dùng theme Papirus-Dark;
  Arch: `sudo pacman -S papirus-icon-theme`). Đổi theme: sửa dòng `//@ pragma IconTheme` đầu `shell.qml`
- Font cho widget mục tiêu: `inter-font` (Arch: `sudo pacman -S inter-font`), có đủ dấu tiếng Việt, đậm đẹp
- Thông báo: **không cần mako nữa**, Dynamic Island nhận thông báo trực tiếp. Chỉ cần `libnotify` để dùng `notify-send`
- Gõ tiếng Việt: `fcitx5`, `fcitx5-unikey` (hoặc `fcitx5-bamboo`), hoặc xoá các dòng fcitx

## Phím tắt chính
| Phím | Việc |
|---|---|
| Win+Enter | mở terminal kitty |
| Win+Q | đóng cửa sổ |
| Win+D hoặc Win+Space | mở bảng ứng dụng (cũng bấm được nút "Ứng dụng" trên bar) |
| Win+Shift+Esc | quản lý tiến trình (btop) |
| Win+N / Win+Shift+N (hoặc bấm 📶 / 🔵 ở bar) | bảng Wi-Fi / bảng Bluetooth: bấm mạng/thiết bị để kết nối hoặc ngắt, công tắc để bật/tắt, ⟳ để quét lại. Cần `networkmanager`, `bluez`, `bluez-utils` |
| Win+M hoặc bấm 💖 ở bar | thư viện ảnh kỷ niệm: bấm ảnh để xem to (‹ › hoặc phím ← → để chuyển), nút "Đặt làm nền", "＋ Thêm ảnh" (dán đường dẫn file hoặc cả thư mục), "📋 Dán" (ảnh trong clipboard). Ảnh lưu ở `~/.config/quickshell/study/memories` |
| Chuột phải vào widget 🎯 góc trên phải | sửa mục tiêu. Lần đặt đầu không tính; sau đó sửa tối đa 10 lần, lần thứ 10 xong là ghim cố định (📌). Dữ liệu ở `~/.config/quickshell/study/goal.json` |
| Win+X hoặc bấm ⏻ ở bar | menu nguồn: Ngủ / Đăng xuất / Khởi động lại / Tắt máy (Ngủ chạy ngay; 3 nút kia bấm 2 lần để xác nhận; phím S, L, R, P) |
| Win+W hoặc bấm 🖼 | mở ô chọn hình nền (ảnh xem trước, bấm để đặt; chuột phải vào 🖼 = ảnh kế) |
| Win+1..3 | chuyển workspace |
| Win+lăn chuột | đổi qua lại giữa workspace 1-2-3 (cũng lăn được trên cụm số ở bar) |
| Phím âm lượng / độ sáng | âm lượng tới 200% (số đỏ khi vượt 100%), độ sáng bước 5% |
| Lăn chuột trên 🔊 / 🔆 ở bar | chỉnh âm lượng / độ sáng |
| Win+Shift+1..3 | chuyển cửa sổ sang workspace |
| Win+F / V | toàn màn hình / cửa sổ nổi |
| Win+Shift+R | khởi động lại Quickshell |
| Win+Shift+E | thoát Hyprland |
| Print | chụp toàn màn hình (lưu file + copy) |
| Shift+Print hoặc Win+Shift+S | chọn vùng chụp (lưu file + copy) |
| Ctrl+Print | chọn vùng, chỉ copy nhanh bằng grim (không lưu file) |

## Đăng xuất = restart sddm (có ô nhập mật khẩu)
Nút "Đăng xuất" (bấm 2 lần) hiện ô nhập mật khẩu rồi chạy `sudo systemctl restart sddm`.
Mật khẩu được đưa vào `sudo -S` qua stdin, không nằm trong dòng lệnh và không ghi ra file.
Nếu tích "Nhớ cho lần sau" (mặc định bật), lần đầu shell tạo file `/etc/sudoers.d/qs-study-sddm`
chỉ cho phép đúng lệnh `systemctl restart sddm` không cần mật khẩu; các lần sau bấm Đăng xuất là chạy luôn.
Mật khẩu không được lưu ở đâu. Muốn bỏ quy tắc: `sudo rm /etc/sudoers.d/qs-study-sddm`. Tài khoản của bạn phải có quyền sudo (nhóm `wheel`).
Muốn bỏ bước nhập mật khẩu, thêm quy tắc sudoers:
```sh
echo "$USER ALL=(root) NOPASSWD: /usr/bin/systemctl restart sddm" | sudo tee /etc/sudoers.d/sddm-restart
sudo chmod 440 /etc/sudoers.d/sddm-restart
```

## Dynamic Island
Viên thuốc ở giữa trên cùng, co giãn bằng hiệu ứng lò xo có nảy.
- **Nghỉ**: giờ và ngày. Khi đang phát nhạc có thêm ảnh bìa nhỏ + sóng nhạc; thêm đồng hồ Pomodoro khi đang chạy, 🔕 khi bật chế độ tập trung.
- **Thông báo**: mọi thông báo hệ thống (notify-send, trình duyệt, Discord, ảnh chụp màn hình...) hiện trên island với icon, tên app, tiêu đề, nội dung.
  Bấm = mở/chạy hành động mặc định, chuột phải hoặc ✕ = bỏ, rê chuột vào = giữ lại. Thông báo khẩn cấp có viền đỏ và ở lâu hơn.
  Trong chế độ tập trung thông báo bị ẩn (trừ loại khẩn cấp), hết tập trung island báo có bao nhiêu thông báo đã bị ẩn.
  **Quickshell thay mako**: chỉ một chương trình được giữ dịch vụ thông báo, nên `mako`, `dunst`, `swaync` phải tắt (`install.sh` tự làm, và đã bỏ mako khỏi `hyprland.lua`).
- **Nhạc**: đổi bài hoặc bấm phát thì island bung ra ảnh bìa + tên bài + nghệ sĩ. Hoạt động với mọi trình phát có MPRIS
  (YouTube trên Cốc Cốc/Chrome/Firefox, Spotify, mpv, VLC...).
- **Sự kiện**: chỉnh âm lượng / độ sáng bằng phím, đổi hình nền, Pomodoro, mạng đổi trạng thái, bật/tắt chế độ tập trung.
- **Thẻ nhanh** (bấm vào island hoặc **Win+I**): giờ + CPU/RAM, **điều khiển nhạc** (⏮ ⏯ ⏭, kéo thanh để tua),
  **thanh trượt âm lượng** (vạch 100%, tới 200%, bấm 🔊 để tắt tiếng), **thanh trượt độ sáng**, Pomodoro, mục tiêu.
  Bấm vào đồng hồ hoặc chuột phải để thu lại; tự thu sau 12 giây nếu không rê chuột vào.
- Phím media (⏯ ⏭ ⏮) điều khiển trình phát đang chạy.
- Thử nhanh: `qs -c study ipc call island test` (sự kiện), `qs -c study ipc call island notify` (thông báo),
  `qs -c study ipc call media toggle` (phát/dừng).
- Chỉnh độ nảy: trong `Island.qml`, `spring` (độ cứng) và `damping` (độ tắt, càng nhỏ càng nảy).

### Island không hiện thông báo / nhạc?
- Thông báo: chạy `pkill mako; pkill dunst` rồi `pkill qs; qs -c study`, thử `notify-send "Thử" "ok"`.
  Kiểm tra ai đang giữ dịch vụ: `busctl --user status org.freedesktop.Notifications`.
- Nhạc: chạy `playerctl -l` (hoặc `busctl --user list | grep mpris`). Không thấy gì nghĩa là trình phát không bật MPRIS
  (Cốc Cốc/Chrome: vào `chrome://flags`, bật "Hardware Media Key Handling"; Firefox mặc định đã có).
- Độ sáng: cần `brightnessctl` và quyền ghi đèn nền (`sudo usermod -aG video $USER` rồi đăng nhập lại).
  Màn hình rời (desktop) thường không có đèn nền, khi đó thanh trượt bị mờ.

## Tính năng học tập / làm việc
| Phím / nút | Việc |
|---|---|
| Win+T hoặc bấm 📝 | danh sách việc cần làm (bấm để đánh dấu xong, rê chuột để xoá) kèm thống kê Pomodoro hôm nay. Lưu ở `todo.json` |
| Win+P | chạy / dừng Pomodoro (hoặc bấm vào đồng hồ trên bar; chuột phải = reset). Số "×N" là số phiên đã xong hôm nay, lưu ở `pomodoro.json` |
| Win+Z hoặc bấm 🔔 | chế độ tập trung: ẩn mọi thông báo. **Tự bật** trong lúc đang chạy phiên tập trung Pomodoro, hết phiên thì thông báo trở lại |
| Win+L, hoặc nút 🔒 trong menu nguồn (Win+X, phím K) | khoá màn hình bằng `hyprlock` (cần cài `hyprlock`, nếu chưa có thì dùng `loginctl lock-session`) |
| CPU/RAM trên bar | đo từ `/proc` mỗi 4 giây, chuyển đỏ khi CPU trên 85% hoặc RAM trên 90% |

## Khi Wi-Fi không kết nối được
Bấm 📶 (hoặc Win+N). Icon 📶 trên bar đổi theo tình trạng: 📶 ổn, 🌐 cần đăng nhập, ⚠ có Wi-Fi nhưng
không ra Internet, 📵 chưa nối mạng. Shell kiểm tra mỗi 20 giây và báo bằng thông báo khi vừa nối mà không dùng được.
- **Báo lý do lỗi bằng tiếng Việt**: sai mật khẩu, không thấy mạng, hết thời gian chờ, lỗi DHCP, Wi-Fi bị khoá…
- **🔑 Nhập lại mật khẩu**: xoá hồ sơ cũ rồi hỏi lại (dùng khi router đổi mật khẩu).
- **Quên mạng**: rê chuột vào mạng đã lưu, bấm "Quên".
- **＋ Mạng ẩn**: nhập tên mạng (SSID) và mật khẩu.
- **🌐 Đăng nhập**: mở trang đăng nhập khi Wi-Fi công cộng yêu cầu (quán cà phê, khách sạn…).
- **🩺 Chẩn đoán**: kiểm tra NetworkManager, công tắc rfkill, card Wi-Fi, bật/tắt, router, Internet, DNS, cổng đăng nhập;
  mỗi mục lỗi có nút sửa nhanh (mở khoá, bật Wi-Fi, làm mới, đổi DNS 1.1.1.1) hoặc sao chép lệnh để dán vào terminal.
Cần thêm: `curl`, `iproute2`, `util-linux` (rfkill), `xdg-utils` (xdg-open), `wl-clipboard`.

## Chụp màn hình
Ảnh lưu vào `~/.config/quickshell/study/scr/` (tên theo giờ, ví dụ `20261107-223015.png`).
Nút 📷 trên bar: chuột trái = chọn vùng, phải = toàn màn hình, giữa = chỉ copy.
Đổi thư mục lưu: sửa dòng `scrDir` ở đầu `shell.qml`. Cần `grim`, `slurp`, `wl-clipboard`.

## Trong bảng ứng dụng
Gõ để tìm, ↑/↓ chọn, Enter mở, Esc hoặc click ra ngoài để đóng.


### ESP32 Buddy: QR và sóng nhạc
- QR chia sẻ: bật nhận file (Win+A), sau đó mở **Menu → Chia sẻ ảnh (QR)** trên OLED. Điện thoại cùng Wi-Fi quét QR để mở trang gửi ảnh/file. Trang local trên điện thoại cũng hiển thị QR và URL hiện tại.
- EQ OLED: cần MPRIS để phát hiện trình phát đang chạy và PipeWire/PulseAudio monitor. Cài `pipewire-pulse` (cung cấp `parec`) hoặc dùng `pw-record`; script `buddy_eq.py` sẽ tự lấy 8 dải tần và gửi UDP qua Wi-Fi khi PC phát nhạc.
- PC và ESP32 phải cùng mạng Wi-Fi, không tranh cổng USB với việc gửi ghi chú/file. Trên OLED vào **Menu → Sóng nhạc EQ**, nhấn A/B đổi kiểu sóng.
- Firmware tương thích ở `firmware/esp32-oled-buddy/`; nạp bằng `cd firmware/esp32-oled-buddy && pio run -t upload`.
