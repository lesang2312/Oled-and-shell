#!/usr/bin/env python3
"""Cong cu PC cho ESP32 OLED Buddy (gui lenh qua cap USB / Serial).

Cai dat:  pip install pyserial pillow
Linux: them user vao nhom dialout  ->  sudo usermod -aG dialout $USER  (dang nhap lai)

Vi du:
  ./pc_tool.py sync                      # dong bo gio may tinh
  ./pc_tool.py note "Mua sua luc 5h"     # ghi chu (tu dong bo dau tieng Viet)
  ./pc_tool.py msg "Hop luc 9h"          # popup tam thoi, khong luu
  ./pc_tool.py wall anime.png            # dat nen anime (tu dong resize 128x64, dither)
  ./pc_tool.py ls | cat notes.txt | rm wall.bin | clearnotes
  ./pc_tool.py watch                     # tu gui gio moi 30s + gui clipboard-note tu stdin
Chon cong: --port /dev/ttyUSB0 (mac dinh tu tim CP210x)
"""
import argparse
import sys
import time
import unicodedata

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    sys.exit("Thieu pyserial:  pip install pyserial pillow")


def strip_accents(s: str) -> str:
    s = s.replace("đ", "d").replace("Đ", "D")
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return "".join(c if 32 <= ord(c) < 127 else " " for c in s)


def find_port():
    for p in list_ports.comports():
        desc = f"{p.description} {p.manufacturer} {p.hwid}".lower()
        if any(k in desc for k in ("cp210", "ch340", "ch910", "silicon labs", "usb serial", "ttyusb")):
            return p.device
    ports = list(list_ports.comports())
    return ports[0].device if ports else None


class Buddy:
    def __init__(self, port):
        port = port or find_port()
        if not port:
            sys.exit("Khong tim thay cong serial. Cam cap USB hoac dung --port.")
        # tat DTR/RTS de khong reset ESP32 moi lan mo cong
        self.ser = serial.Serial()
        self.ser.port = port
        self.ser.baudrate = 115200
        self.ser.timeout = 2
        self.ser.dtr = False
        self.ser.rts = False
        self.ser.open()
        time.sleep(0.2)
        self.ser.reset_input_buffer()

    def send(self, line: str, until=None, quiet=False):
        self.ser.write((line + "\n").encode("ascii", "ignore"))
        self.ser.flush()
        out = []
        end = time.time() + 5
        while time.time() < end:
            raw = self.ser.readline().decode("ascii", "ignore").rstrip("\r\n")
            if not raw:
                continue
            out.append(raw)
            if until is None and (raw.startswith("OK") or raw.startswith("ERR") or raw == "PONG"):
                break
            if until and raw == until:
                break
        if not quiet:
            print("\n".join(out))
        return out

    def sync_time(self):
        now = time.time()
        tz = -time.altzone if time.localtime().tm_isdst > 0 else -time.timezone
        return self.send(f"TIME {int(now)} {tz}")


def image_to_hex(path):
    try:
        from PIL import Image, ImageOps
    except ImportError:
        sys.exit("Thieu pillow:  pip install pillow")
    img = Image.open(path).convert("L")
    # cat/resize giu ti le de lap day 128x64
    img = ImageOps.fit(img, (128, 64), method=Image.LANCZOS, centering=(0.5, 0.35))
    img = ImageOps.autocontrast(img, cutoff=2)
    bw = img.convert("1")  # Floyd-Steinberg dither -> nhin giong anh hon tren OLED
    px = bw.load()
    data = bytearray(1024)
    for y in range(64):
        for x in range(128):
            if px[x, y]:  # trang
                data[y * 16 + x // 8] |= 0x80 >> (x % 8)
    return data.hex()


def main():
    ap = argparse.ArgumentParser(description="Dieu khien ESP32 OLED Buddy qua USB")
    ap.add_argument("--port", help="vd /dev/ttyUSB0 hoac COM3")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("ping")
    sub.add_parser("sync")
    sub.add_parser("ls")
    sub.add_parser("clearnotes")
    sub.add_parser("watch")
    for n in ("note", "msg"):
        sub.add_parser(n).add_argument("text", nargs="+")
    sub.add_parser("wall").add_argument("image")
    sub.add_parser("cat").add_argument("name")
    sub.add_parser("rm").add_argument("name")
    a = ap.parse_args()

    if a.cmd == "wall":  # kiem tra anh truoc khi mo cong
        hexdata = image_to_hex(a.image)

    b = Buddy(a.port)
    if a.cmd == "ping":
        b.send("PING")
    elif a.cmd == "sync":
        b.sync_time()
    elif a.cmd == "note":
        b.send("NOTE " + strip_accents(" ".join(a.text)))
    elif a.cmd == "msg":
        b.send("MSG " + strip_accents(" ".join(a.text)))
    elif a.cmd == "clearnotes":
        b.send("CLEARNOTES")
    elif a.cmd == "wall":
        b.send("WALL " + hexdata)
    elif a.cmd == "ls":
        b.send("LS", until="END")
    elif a.cmd == "cat":
        b.send("CAT " + a.name, until="END")
    elif a.cmd == "rm":
        b.send("DEL " + a.name)
    elif a.cmd == "watch":
        print("Dang chay: dong bo gio moi 30s. Go chu + Enter de gui ghi chu, '!chu' de gui popup. Ctrl+C de thoat.")
        import select
        last = 0
        try:
            while True:
                if time.time() - last > 30:
                    b.send("TIME %d %d" % (int(time.time()), -time.timezone), quiet=True)
                    last = time.time()
                r, _, _ = select.select([sys.stdin], [], [], 1)
                if r:
                    t = sys.stdin.readline().strip()
                    if t.startswith("!"):
                        b.send("MSG " + strip_accents(t[1:]))
                    elif t:
                        b.send("NOTE " + strip_accents(t))
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
