# ESP32 OLED Buddy v2

ESP32 + màn OLED SSD1306 128x64 (I2C) + 2 nút bấm. Lập trình bằng PlatformIO.

## Nối dây
| Linh kiện | Chân ESP32 |
|---|---|
| OLED SDA | D21 |
| OLED SCK/SCL | D22 |
| OLED VCC / GND | 3V3 / GND |
| Nút A | D4 và GND |
| Nút B | D18 và GND |
| Còi (tuỳ chọn) | đặt `PIN_BUZZ` trong `src/config.h` |

Nút nối vào 3V3 thay vì GND thì bỏ dấu `;` trước `-DBTN_ACTIVE_HIGH` trong `platformio.ini`.

## Nạp
    pio run -t upload
    pio device monitor        # đóng monitor trước khi dùng buddy.py

Nếu lỗi biên dịch Bluetooth: đổi `-DENABLE_BT=1` thành `-DENABLE_BT=0`.

## Điều khiển
| Thao tác | Việc |
|---|---|
| A (D4) bấm thường | LÊN |
| B (D18) bấm thường | XUỐNG |
| A giữ ~0,6 giây | CHỌN (OK) |
| B giữ ~0,6 giây | QUAY LẠI |
| Trong game: giữ nút B ~0,6 giây hoặc giữ cả hai nút ~0,7 giây | thoát game |

Màn hình chủ: LÊN/XUỐNG đổi kiểu (hình nền, số lớn, kim, bảng thông tin), CHỌN mở menu, QUAY LẠI mở ghi chú.
Vào menu → "Test nút bấm" để kiểm tra nút.

## Tính năng
- Đồng hồ 4 kiểu, hình nền anime 128x64, ghi chú, việc cần làm
- **Đọc file .txt** (21 cột x 6 dòng, nhớ trang đang đọc), quản lý file
- Bấm giờ có vòng, Pomodoro, đếm ngược, báo thức
- Game: Dino, Snake, Flappy, Pong, Breakout (lưu điểm cao)
- Xúc xắc, tung đồng xu, quả cầu 8, thử phản xạ, đôi mắt
- Thời tiết trực tuyến Open-Meteo (nhiệt độ, cảm nhận, độ ẩm, gió; icon OLED theo nắng/mây/mưa/giông), theo dõi CPU/RAM máy tính, trang mạng
- Cài đặt: độ sáng, đảo màu, lật, 12/24h, múi giờ, tự tắt, WiFi, Bluetooth

## Thời tiết
- ESP32 lấy dữ liệu hiện tại từ Open-Meteo khi có Wi-Fi Internet, tự cập nhật khoảng 30 phút/lần.
- Màn hình OLED có icon vẽ trực tiếp theo điều kiện: nắng, mây, sương, mưa, tuyết, giông; hiển thị nhiệt độ, cảm nhận, độ ẩm và gió.
- Cấu hình vị trí bằng `python3 tools/buddy.py geo <vi_do> <kinh_do>` hoặc trên trang web Buddy. Ví dụ `geo 21.3 105.2` chỉ là tọa độ mẫu, hãy thay bằng vị trí cần dự báo.
- Giữ nút A trong màn Thời tiết hoặc bấm nút cập nhật trên trang web để tải lại.

## Sửa lỗi giờ/ngày sai
ESP32 không có pin đồng hồ nên mất giờ mỗi lần cấp điện lại. Bản này:
- lưu giờ vào flash mỗi 10 phút và hiện dấu `~` khi giờ chỉ là ước lượng
- hiện `--:--` khi chưa có giờ nào
- tự lấy giờ NTP khi có WiFi; `buddy.py` luôn gửi giờ máy tính khi kết nối
- có cài đặt múi giờ (mặc định theo máy tính gửi sang)

## Kết nối
- USB: `tools/buddy.py` (python3; ảnh cần Pillow hoặc ImageMagick)
- WiFi: nhập SSID/mật khẩu bằng `buddy.py wifi ssid pass`. Không vào được mạng thì ESP32 tự phát WiFi `ESP32-Buddy` (mật khẩu `12345678`), trang web tại `http://192.168.4.1`. Khi đổi WiFi từ trang web, thiết bị sẽ ngắt mạng cũ sau khi gửi xác nhận; kết nối máy tính/điện thoại vào cùng router mới rồi mở `http://buddy.local` hoặc IP trong màn "Mạng".
- Bluetooth Serial: cùng bộ lệnh như USB
- Trang web không có mật khẩu: chỉ dùng trong mạng nhà

## buddy.py
    python3 tools/buddy.py sync | time | note "chữ" | msg "chữ" | wall anime.png
    python3 tools/buddy.py put bai.txt | puttext - "nội dung" | ls | get tên | rm tên | open tên
    python3 tools/buddy.py weather | todos | alarm 06:30 | timer 25 học | wifi ssid pass | geo 21.3 105.2 | info | net
Biến môi trường: `BUDDY_PORT`, `BUDDY_HOST`, `BUDDY_MODE=auto|usb|net`. Mã thoát 3 = không thấy thiết bị.
File .txt chỉ hiển thị ASCII trên OLED: dấu tiếng Việt được bỏ khi gửi (giới hạn 48KB; đọc và tải về hỗ trợ đến 48KB).

## Giao thức (mỗi lệnh một dòng)
PING, TIME epoch tz, TZ, NOTE, MSG, CLEARNOTES, WALL hex, LS, GET, PUT/APP/END, DEL, OPEN, TODOSET, ALARM, TIMER, PCSTAT, WIFI, GEO, WX (tai lai thoi tiet), NET, INFO, REBOOT.
Cũng dùng được qua `POST /api/cmd` và Bluetooth.


## Tính năng bổ sung v2.2
- Menu **Chia se anh (QR)** hiển thị QR + URL local do Study Shell gửi qua lệnh `SHARE <url>|<rows-slash-separated>`. QR nằm trong RAM, desktop sẽ đồng bộ lại khi share server khởi động.
- Menu **Song nhac EQ** nhận 8 dải tần qua UDP port 4211 từ `buddy_eq.py`; PC và ESP32 phải cùng Wi-Fi. A/B đổi BARS, WAVE, MIRROR, DOTS và PULSE.
