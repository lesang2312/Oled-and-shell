# ESP32 OLED Buddy - ghi chu ban sua

## Da sua

- WiFi: lenh `WIFI` khong con tat radio ngay khi HTTP handler chua gui xong phan hoi. Firmware doi 500 ms roi moi doi ket noi.
- WiFi: dung WebServer va mDNS cu truoc khi doi AP/STA, sau do cho `netLoop()` mo lai web server tren giao dien mang moi.
- WiFi: kiem tra SSID toi da 32 ky tu va mat khau 8-63 ky tu (hoac de trong cho mang mo) truoc khi luu.
- File TXT: thong nhat gioi han gui, doc tren OLED va tai ve la 48 KB; tu choi file vuot gioi han thay vi doc/tai ve thieu.
- File TXT: kiem tra so byte ghi thuc te qua web; neu ghi khong du thi xoa file loi va tra ve loi, khong bao thanh cong gia.
- File TXT: tu lam moi danh sach sau khi nhan file; chuan hoa CRLF va tab khi upload tu trinh duyet.
- Game: giu nut B (D18) khoang 0,6 giay de thoat; van giu duoc cach giu ca hai nut.
- Thoi tiet: bo sung icon ve truc tiep cho nang, trang, may, suong, mua, tuyet va giong; hien nhiet do cam nhan, do am, toc do gio.
- Thoi tiet: them the du lieu tren trang web, API `/api/weather`, nut cap nhat va cau hinh vi tri GEO co kiem tra gioi han toa do.
- Thoi tiet: bo sung lenh `WX`/`WEATHER` va `buddy.py weather`; tu cap nhat 30 phut khi co WiFi Internet.

## Kiem tra da chay

- `python3 -m py_compile tools/buddy.py`: dat.
- `node --check` cho JavaScript nhung trong trang web: dat.
- Kiem tra cac truong Open-Meteo `apparent_temperature`, `is_day`, `weather_code`, `relative_humidity_2m` va `wind_speed_10m` theo schema API: dat.
- Kiem tra dong nhat gioi han file 48,000 byte va cac nhanh WiFi/game: dat.

Chua the build firmware hoac nap thu tren phan cung trong moi truong nay vi khong co PlatformIO / bo toolchain ESP32. Can chay `pio run` va test tren board truoc khi dung chinh thuc.
