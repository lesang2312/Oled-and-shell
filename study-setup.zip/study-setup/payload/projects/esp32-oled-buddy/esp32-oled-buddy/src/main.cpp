// ============================================================
//  ESP32 OLED Buddy v2  -  SSD1306 128x64 (I2C) + 2 nut bam
//  Nut: A = D4 (bam ngan: LEN, giu: CHON)  |  B = D18 (bam ngan: XUONG, giu: QUAY LAI)
//  Tong quan tinh nang va cach noi day: xem README.md
// ============================================================
#include "config.h"
#include "core.h"
#include "apps.h"
#include "games.h"
#include "net.h"
#include "commands.h"
#include "ui.h"

void setup() {
  Serial.setRxBufferSize(4096);
  Serial.begin(115200);
  initButtons();
  if (PIN_BUZZ >= 0) { pinMode(PIN_BUZZ, OUTPUT); digitalWrite(PIN_BUZZ, LOW); }
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(400000);
  if (!oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    for (;;) delay(1000);          // khong thay man hinh: kiem tra day noi / dia chi I2C (0x3C hoac 0x3D)
  }
  LittleFS.begin(true);
  prefs.begin("buddy", false);
  loadSettings();
  reBest = prefs.getUInt("reac", 0);
  loadNotes();
  loadTodos();
  loadWall();
  applyDisplay();
  randomSeed(esp_random());

  // Khoi phuc gio gan nhat tu flash (ESP32 khong co pin dong ho): hien dau "~" cho toi khi dong bo that
  uint32_t ep = prefs.getUInt("ep", 0);
  if (ep > 1700000000UL) applyTime(ep + 1, 1, false);

  oled.clearDisplay();
  oled.setTextColor(C_ON);
  centerText("ESP32", 8, 2);
  centerText("Buddy v" FW_VER, 30, 2);
  centerText("^_^", 52, 1);
  oled.display();

  webSetup();
  xTaskCreate(weatherTask, "wx", 12288, nullptr, 1, nullptr);
  if (S.btOn) buddyBtStart();
  wifiStart();
  delay(700);
  lastActive = millis();
}

void loop() {
  pumpLines(Serial, usbLine, Serial);
#if ENABLE_BT
  if (btUp) pumpLines(SerialBT, btLine, SerialBT);
#endif
  netLoop();
  tickTimers();

  int e = readEvent();
  if (e != EV_NONE) {
    lastActive = millis();
    if (ringing) { stopRing(); dirty = true; e = EV_NONE; }
    else if (sleeping) { wakeScreen(); e = EV_NONE; }
    else if (popUntil > millis()) { popUntil = 0; dirty = true; e = EV_NONE; }
  }
  if (e != EV_NONE) handleEvent(e);

  bool isGame = (screen >= SC_DINO && screen <= SC_BREAK);
  bool keepOn = isGame || screen == SC_EYES || screen == SC_READER || screen == SC_EQ || screen == SC_SHARE || ringing || pmRun || cdState == 1 || swRun;
  if (!sleeping && S.sleepIdx > 0 && !keepOn && millis() - lastActive > (uint32_t)SLEEP_LV[S.sleepIdx] * 1000UL) {
    sleeping = true;
    oled.ssd1306_command(SSD1306_DISPLAYOFF);
  }
  if (sleeping) { delay(10); return; }

  uint32_t interval = isGame ? 30 : ((screen == SC_EYES || screen == SC_EQ) ? 40 : (screen == SC_DICE || screen == SC_COIN || screen == SC_REACT || ringing) ? 40 : 100);
  uint32_t now = millis();
  if (dirty || now - lastRender >= interval) {
    if (isGame) gameStep(screen);
    render();
    lastRender = now;
    dirty = false;
  }
  delay(2);
}
