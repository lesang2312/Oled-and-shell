// ============================================================
//  Lenh tu may tinh / web / Bluetooth (moi lenh 1 dong)
//  PING | TIME <epoch> <tz_giay> | TZ <giay> | NOTE <chu> | MSG <chu> | CLEARNOTES
//  WALL <2048 hex> | LS | GET <ten> | PUT <ten> | APP <ten> <hex> | END <ten> | DEL <ten> | OPEN <ten>
//  TODOSET 0:viec|1:viec | ALARM HH:MM [on|off] | ALARM off | TIMER <phut> [nhan]
//  PCSTAT cpu mem pomoState pomoConLai pomoHomNay | WIFI <ssid>\t<pass> | GEO <lat> <lon>
//  NET | INFO | REBOOT
// ============================================================
#pragma once
#include "core.h"
#include "apps.h"
#include "games.h"
#include "net.h"

const char *wfMode() {
  switch (wfState) { case WF_OFF: return "off"; case WF_CONNECTING: return "connecting"; case WF_STA: return "sta"; case WF_AP: return "ap"; }
  return "?";
}

void processLine(String l, Print &out) {
  l.trim();
  if (!l.length()) return;
  int sp = l.indexOf(' ');
  String cmd = (sp < 0) ? l : l.substring(0, sp);
  String arg = (sp < 0) ? String("") : l.substring(sp + 1);
  cmd.toUpperCase();

  if (cmd == "PING") {
    out.println("PONG");
  } else if (cmd == "TIME") {
    int sp2 = arg.indexOf(' ');
    long long epoch = atoll(arg.c_str());
    if (sp2 >= 0) { S.tz = arg.substring(sp2 + 1).toInt(); prefs.putInt("tz", S.tz); }
    if (epoch > 1700000000LL) applyTime((uint32_t)epoch, 2, true);
    dirty = true;
    out.println("OK TIME");
  } else if (cmd == "TZ") {
    S.tz = arg.toInt();
    prefs.putInt("tz", S.tz);
    dirty = true;
    out.println("OK TZ " + tzStr());
  } else if (cmd == "NOTE") {
    String t = sanitize(arg);
    if (!t.length()) { out.println("ERR empty"); return; }
    addNote(t);
    showPopup("Ghi chu moi", t);
    out.printf("OK NOTE %d\n", (int)notes.size());
  } else if (cmd == "MSG") {
    showPopup("Tin nhan", arg);
    out.println("OK MSG");
  } else if (cmd == "CLEARNOTES") {
    notes.clear(); saveNotes(); noteIdx = 0; dirty = true;
    out.println("OK CLEARNOTES");
  } else if (cmd == "WALL") {
    arg.trim();
    if (arg.length() != 2048) { out.printf("ERR wall length %d\n", (int)arg.length()); return; }
    for (int i = 0; i < 1024; i++) {
      int hi = hexVal(arg[i * 2]), lo = hexVal(arg[i * 2 + 1]);
      if (hi < 0 || lo < 0) { out.println("ERR wall hex"); return; }
      wall[i] = (uint8_t)((hi << 4) | lo);
    }
    hasWall = true; S.wall = true; homeMode = 0;
    saveWall(); saveSettings();
    wakeScreen();
    out.println("OK WALL");
  } else if (cmd == "LS") {
    File root = LittleFS.open("/");
    File f = root.openNextFile();
    while (f) {
      if (!f.isDirectory()) out.printf("%s\t%u\n", f.name(), (unsigned)f.size());
      f = root.openNextFile();
    }
    out.printf("TOTAL\t%u\t%u\n", (unsigned)LittleFS.usedBytes(), (unsigned)LittleFS.totalBytes());
    out.println("END");
  } else if (cmd == "GET") {                       // tra ve file dang hex: DATA <hex> ... END
    String p = cleanPath(arg);
    File f = p.length() ? LittleFS.open(p, "r") : File();
    if (!f) { out.println("ERR not found"); return; }
    if (f.size() > 48000) { f.close(); out.println("ERR file exceeds 48KB"); return; }
    uint8_t buf[96];
    char hx[200];
    uint32_t total = 0;
    while (f.available() && total < 48000) {
      size_t n = f.read(buf, sizeof(buf));
      if (!n) break;
      for (size_t i = 0; i < n; i++) snprintf(hx + i * 2, 3, "%02x", buf[i]);
      out.print("DATA ");
      out.println(hx);
      total += n;
    }
    f.close();
    out.println("END");
  } else if (cmd == "PUT") {                       // PUT ten -> tao/lam rong file
    String p = cleanPath(arg);
    if (!p.length()) { out.println("ERR name"); return; }
    File f = LittleFS.open(p, "w");
    if (!f) { out.println("ERR open"); return; }
    f.close();
    out.println("OK PUT " + p);
  } else if (cmd == "APP") {                       // APP ten hex -> noi them du lieu
    int sp2 = arg.indexOf(' ');
    if (sp2 < 0) { out.println("ERR args"); return; }
    String p = cleanPath(arg.substring(0, sp2));
    String hx = arg.substring(sp2 + 1);
    hx.trim();
    if (!p.length() || (hx.length() & 1)) { out.println("ERR args"); return; }
    if ((size_t)(LittleFS.totalBytes() - LittleFS.usedBytes()) < hx.length() / 2 + 4096) { out.println("ERR full"); return; }
    File f = LittleFS.open(p, "a");
    if (!f) { out.println("ERR open"); return; }
    if (f.size() + hx.length() / 2 > 48000) { f.close(); out.println("ERR file limit 48KB"); return; }
    uint8_t buf[128];
    size_t k = 0;
    for (unsigned i = 0; i + 1 < hx.length(); i += 2) {
      int hi = hexVal(hx[i]), lo = hexVal(hx[i + 1]);
      if (hi < 0 || lo < 0) { f.close(); out.println("ERR hex"); return; }
      buf[k++] = (uint8_t)((hi << 4) | lo);
      if (k == sizeof(buf)) { f.write(buf, k); k = 0; }
    }
    if (k) f.write(buf, k);
    f.close();
    out.println("OK APP");
  } else if (cmd == "END") {
    String p = cleanPath(arg);
    File f = p.length() ? LittleFS.open(p, "r") : File();
    if (!f) { out.println("ERR not found"); return; }
    size_t sz = f.size();
    f.close();
    if (p == "/notes.txt") loadNotes();
    if (p == "/todo.txt") loadTodos();
    if (p == "/wall.bin") loadWall();
    if (screen == SC_RDLIST) refreshTxt();
    if (screen == SC_FILES) refreshFiles();
    showPopup("Da nhan file", p.substring(1) + " " + String((unsigned long)sz) + "B");
    out.printf("OK END %s %u\n", p.c_str(), (unsigned)sz);
  } else if (cmd == "DEL") {
    String p = cleanPath(arg);
    if (p.length() && LittleFS.exists(p)) {
      deleteFile(p);
      if (screen == SC_FILES) refreshFiles();
      if (screen == SC_RDLIST) refreshTxt();
      dirty = true;
      out.println("OK DEL");
    } else out.println("ERR cannot delete");
  } else if (cmd == "OPEN") {                      // mo file de doc tren man hinh
    String p = cleanPath(arg);
    if (!p.length() || !LittleFS.exists(p)) { out.println("ERR not found"); return; }
    rdBack = SC_RDLIST;
    if (openReader(p)) { go(SC_READER); wakeScreen(); out.println("OK OPEN " + p); }
    else out.println("ERR open");
  } else if (cmd == "TODOSET") {
    setTodos(arg);
    dirty = true;
    out.printf("OK TODOSET %d\n", (int)todos.size());
  } else if (cmd == "ALARM") {
    String a = arg;
    a.trim();
    a.toLowerCase();
    int h = -1, m = -1;
    if (a == "off") { alOn = false; }
    else if (sscanf(a.c_str(), "%d:%d", &h, &m) == 2 && h >= 0 && h < 24 && m >= 0 && m < 60) {
      alH = (uint8_t)h; alM = (uint8_t)m;
      alOn = !(a.endsWith("off"));
      lastAlarmKey = -1;
    } else { out.println("ERR format HH:MM"); return; }
    saveAlarm();
    dirty = true;
    out.printf("OK ALARM %02d:%02d %s\n", alH, alM, alOn ? "on" : "off");
  } else if (cmd == "TIMER") {
    int mins = arg.toInt();
    if (mins <= 0) { cdState = 0; out.println("OK TIMER off"); return; }
    int sp2 = arg.indexOf(' ');
    cdStart(mins, sp2 < 0 ? String("") : arg.substring(sp2 + 1));
    showPopup("Dem nguoc", String(mins) + " phut");
    go(SC_COUNTDOWN);
    out.printf("OK TIMER %d\n", mins);
  } else if (cmd == "PCSTAT") {
    int c = 0, m = 0, ps = 0, pr = 0, pt = 0;
    if (sscanf(arg.c_str(), "%d %d %d %d %d", &c, &m, &ps, &pr, &pt) >= 2) {
      pcs.cpu = c; pcs.mem = m; pcs.pState = ps; pcs.pRem = pr; pcs.pToday = pt;
      pcs.at = millis();
      if (pcs.at == 0) pcs.at = 1;
      dirty = true;
      out.println("OK PCSTAT");
    } else out.println("ERR args");
  } else if (cmd == "WIFI") {
    int tab = arg.indexOf('\t');
    String ssid = (tab < 0) ? arg : arg.substring(0, tab);
    String pass = (tab < 0) ? String("") : arg.substring(tab + 1);
    ssid.trim();
    if (ssid.length() > 32 || pass.length() > 63 || (pass.length() > 0 && pass.length() < 8)) {
      out.println("ERR WIFI SSID toi da 32 ky tu; mat khau can 8-63 ky tu");
      return;
    }
    wifiSsid = ssid;
    wifiPass = pass;
    prefs.putString("ssid", wifiSsid);
    prefs.putString("pass", wifiPass);
    S.wifiOn = true;
    saveSettings();
    scheduleWifiRestart(500);
    out.println(ssid.length() ? "OK WIFI " + ssid : String("OK WIFI cleared"));
  } else if (cmd == "GEO") {
    float la = 0, lo = 0;
    if (sscanf(arg.c_str(), "%f %f", &la, &lo) == 2 && !isnan(la) && !isnan(lo) &&
        la >= -90.0f && la <= 90.0f && lo >= -180.0f && lo <= 180.0f) {
      geoLat = la; geoLon = lo;
      prefs.putFloat("lat", la); prefs.putFloat("lon", lo);
      wxFailed = false;
      wxReq = true;
      out.println("OK GEO");
    } else out.println("ERR GEO lat -90..90, lon -180..180");
  } else if (cmd == "WX" || cmd == "WEATHER") {
    wxFailed = false;
    wxReq = true;
    out.println("OK WEATHER refresh queued");
  } else if (cmd == "SHARE") {
    int sep = arg.indexOf('|');
    if (sep < 0) { out.println("ERR SHARE format"); return; }
    String url = arg.substring(0, sep);
    String matrix = arg.substring(sep + 1);
    url.trim();
    if (url.length() < 8 || url.length() > 120 || matrix.length() > 1800 ||
        (!url.startsWith("http://") && !url.startsWith("https://"))) {
      out.println("ERR SHARE length/url"); return;
    }
    std::vector<String> rows;
    int at = 0;
    while (at <= (int)matrix.length() && rows.size() <= 41) {
      int end = matrix.indexOf('/', at);
      if (end < 0) end = matrix.length();
      String row = matrix.substring(at, end);
      rows.push_back(row);
      at = end + 1;
      if (end >= (int)matrix.length()) break;
    }
    int n = (int)rows.size();
    if (n < 21 || n > 41) { out.println("ERR SHARE QR size"); return; }
    for (int y = 0; y < n; y++) {
      if ((int)rows[y].length() != n) { out.println("ERR SHARE QR shape"); return; }
      for (int x = 0; x < n; x++) if (rows[y][x] != '0' && rows[y][x] != '1') {
        out.println("ERR SHARE QR data"); return;
      }
    }
    buddyShareUrl = url;
    buddyShareQr = rows;
    shareView = 0;
    if (screen == SC_SHARE) dirty = true;
    out.println("OK SHARE");
  } else if (cmd == "NET") {
    out.printf("OK NET mode=%s ip=%s ssid=%s rssi=%d host=buddy.local bt=%d time=%s tz=%s\n", wfMode(), wfIp().c_str(),
               wifiSsid.c_str(), wfState == WF_STA ? (int)WiFi.RSSI() : 0, btUp ? 1 : 0, timeSrcTxt(), tzStr().c_str());
  } else if (cmd == "INFO") {
    out.printf("OK INFO v=%s up=%lu heap=%u fs=%u/%u notes=%d todos=%d src=%s now=%lu\n", FW_VER, (unsigned long)(millis() / 1000),
               (unsigned)ESP.getFreeHeap(), (unsigned)LittleFS.usedBytes(), (unsigned)LittleFS.totalBytes(), (int)notes.size(),
               (int)todos.size(), timeSrcTxt(), (unsigned long)time(nullptr));
  } else if (cmd == "REBOOT") {
    out.println("OK REBOOT");
    delay(100);
    ESP.restart();
  } else {
    out.println("ERR unknown command");
  }
}

// ---------- doc dong tu Serial va Bluetooth ----------
struct LineBuf { String b; };
LineBuf usbLine, btLine;
void pumpLines(Stream &s, LineBuf &lb, Print &out) {
  int budget = 2400;
  while (s.available() && budget-- > 0) {
    char c = (char)s.read();
    if (c == '\n') { String l = lb.b; lb.b = ""; processLine(l, out); }
    else if (c != '\r' && lb.b.length() < 2300) lb.b += c;
  }
}
