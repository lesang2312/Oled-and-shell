// ============================================================
//  Giao dien: menu, man hinh chinh, ve, xu ly nut
// ============================================================
#pragma once
#include "core.h"
#include "apps.h"
#include "games.h"
#include "net.h"

// ---------- menu ----------
struct MenuItem { const char *name; int target; };      // target >= 0: man hinh; < 0: menu con (-1 hen gio, -2 game, -3 tien ich)
struct MenuDef { const MenuItem *items; int n; const char *title; };

const MenuItem TOP_MENU[] = {
  {"Ghi chu", SC_NOTES}, {"Doc file txt", SC_RDLIST}, {"Viec can lam", SC_TODO},
  {"Hen gio >", -1}, {"Tro choi >", -2}, {"Tien ich >", -3},
  {"Thoi tiet", SC_WEATHER}, {"May tinh (PC)", SC_PCMON}, {"Mang & BT", SC_NET},
  {"Mat chop", SC_EYES}, {"Quan ly file", SC_FILES}, {"Cai dat", SC_SETTINGS},
  {"Thong tin", SC_INFO}, {"Test nut bam", SC_BTNTEST},
  {"Chia se anh (QR)", SC_SHARE}, {"Song nhac EQ", SC_EQ}};
const MenuItem TIME_MENU[] = {{"Bam gio", SC_STOPWATCH}, {"Pomodoro", SC_POMO}, {"Dem nguoc", SC_COUNTDOWN}, {"Bao thuc", SC_ALARM}};
const MenuItem GAME_MENU[] = {{"Dino nhay", SC_DINO}, {"Ran san moi", SC_SNAKE}, {"Flappy", SC_FLAPPY}, {"Pong", SC_PONG}, {"Pha gach", SC_BREAK}};
const MenuItem TOOL_MENU[] = {{"Xuc xac", SC_DICE}, {"Dong xu", SC_COIN}, {"Qua cau bi 8", SC_EIGHT}, {"Do phan xa", SC_REACT}};
const MenuDef MENUS[] = {
  {TOP_MENU, 16, "MENU"}, {TIME_MENU, 4, "HEN GIO"}, {GAME_MENU, 5, "TRO CHOI"}, {TOOL_MENU, 4, "TIEN ICH"}};
int menuId = 0;
int menuSel[4] = {0, 0, 0, 0};

void drawMenu() {
  const MenuDef &m = MENUS[menuId];
  oled.setCursor(0, 1);
  oled.print(m.title);
  if (haveTime()) {
    struct tm t;
    getTm(t);
    char b[8];
    fmtTime(b, sizeof(b), t, false);
    oled.setCursor(128 - 30, 1);
    oled.print(b);
  }
  oled.drawFastHLine(0, 10, 128, C_ON);
  std::vector<String> names;
  for (int i = 0; i < m.n; i++) names.push_back(m.items[i].name);
  drawRows(names, nullptr, menuSel[menuId], 13, 5);
}

// ---------- chuyen man hinh (khoi tao trang thai) ----------
void go(int sc) {
  screen = sc;
  dirty = true;
  btnGame = (sc >= SC_DINO && sc <= SC_BREAK);
  comboT = 0; comboDone = false;
  switch (sc) {
    case SC_NOTES: noteIdx = notes.empty() ? 0 : (int)notes.size() - 1; noteScroll = 0; noteDel = false; break;
    case SC_RDLIST: refreshTxt(); break;
    case SC_TODO: todoSel = 0; break;
    case SC_DINO: case SC_SNAKE: case SC_FLAPPY: case SC_PONG: case SC_BREAK: gameReset(sc); break;
    case SC_DICE: dv[0] = dv[1] = 1; diceEnd = 0; break;
    case SC_COIN: coinEnd = 0; break;
    case SC_EIGHT: eightRes = -1; break;
    case SC_REACT: reState = 0; break;
    case SC_WEATHER: if (wfState == WF_STA && (!wx.ok || millis() - wx.at > 600000UL)) wxReq = true; break;
    case SC_NET: netSel = 0; break;
    case SC_FILES: fileSel = 0; fileMode = 0; refreshFiles(); break;
    case SC_SETTINGS: setSel = 0; clearConfirm = false; break;
    case SC_ALARM: alField = -1; break;
    case SC_BTNTEST: lastEvTxt = "-"; break;
    case SC_SHARE: shareView = 0; break;
  }
}

// ---------- man hinh chinh ----------
void drawAnalog(const struct tm &t, int cx, int cy, int r) {
  oled.drawCircle(cx, cy, r, C_ON);
  for (int h = 0; h < 12; h++) {
    float a = h * PI / 6;
    oled.drawLine(cx + (int)(sinf(a) * (r - 3)), cy - (int)(cosf(a) * (r - 3)), cx + (int)(sinf(a) * r), cy - (int)(cosf(a) * r), C_ON);
  }
  float ah = ((t.tm_hour % 12) + t.tm_min / 60.0f) * PI / 6;
  float am = (t.tm_min + t.tm_sec / 60.0f) * PI / 30;
  float as = t.tm_sec * PI / 30;
  oled.drawLine(cx, cy, cx + (int)(sinf(ah) * r * 0.5f), cy - (int)(cosf(ah) * r * 0.5f), C_ON);
  oled.drawLine(cx, cy, cx + (int)(sinf(am) * r * 0.75f), cy - (int)(cosf(am) * r * 0.75f), C_ON);
  if (S.secs) oled.drawLine(cx, cy, cx + (int)(sinf(as) * r * 0.85f), cy - (int)(cosf(as) * r * 0.85f), C_ON);
  oled.fillCircle(cx, cy, 2, C_ON);
}

void drawHome() {
  struct tm t;
  getTm(t);
  bool ok = haveTime();
  char b[16], d[48];
  if (ok) fmtTime(b, sizeof(b), t, false); else strcpy(b, "--:--");
  if (ok) snprintf(d, sizeof(d), "%s %02d/%02d/%04d", DAYS[t.tm_wday], t.tm_mday, t.tm_mon + 1, t.tm_year + 1900);
  else strcpy(d, "Chua co gio");
  int mode = homeMode;
  if (mode == 0 && !(S.wall && hasWall)) mode = 1;

  if (mode == 0) {                                   // nen anime + dong ho goc tren
    oled.drawBitmap(0, 0, wall, 128, 64, C_ON, C_OFF);
    oled.fillRect(0, 0, 66, 28, C_OFF);
    oled.drawRect(0, 0, 66, 28, C_ON);
    oled.setTextSize(2);
    oled.setCursor(3, 3);
    oled.print(b);
    oled.setTextSize(1);
    oled.setCursor(3, 19);
    if (ok) oled.printf("%s %02d/%02d", DAYS[t.tm_wday], t.tm_mday, t.tm_mon + 1); else oled.print("Chua co gio");
  } else if (mode == 1) {                            // so lon
    oled.setTextSize(4);
    oled.setCursor(4, 6);
    oled.print(b);
    oled.setTextSize(1);
    oled.setCursor(4, 42);
    oled.print(d);
    if (ok && S.secs) { oled.setCursor(104, 42); oled.printf(":%02d", t.tm_sec); }
    if (ok && !S.h24) { oled.setCursor(104, 52); oled.print(t.tm_hour >= 12 ? "PM" : "AM"); }
    oled.setCursor(4, 54);
    if (!ok) oled.print("Cam USB hoac bat WiFi");
    else if (timeSrc == 1) oled.print("~ gio uoc luong");
    else if (alOn) oled.printf("Bao thuc %02d:%02d", alH, alM);
    else if (!notes.empty()) oled.printf("Ghi chu: %d", (int)notes.size());
  } else if (mode == 2) {                            // dong ho kim
    drawAnalog(t, 31, 32, 29);
    oled.setTextSize(2);
    oled.setCursor(68, 8);
    oled.print(ok ? b : "--:--");
    oled.setTextSize(1);
    oled.setCursor(68, 28);
    if (ok) oled.printf("%s %02d/%02d", DAYS[t.tm_wday], t.tm_mday, t.tm_mon + 1); else oled.print("Chua co gio");
    oled.setCursor(68, 38);
    if (ok) oled.printf("%04d%s", t.tm_year + 1900, timeSrc == 1 ? " ~" : "");
    if (alOn) { oled.setCursor(68, 54); oled.printf("AL %02d:%02d", alH, alM); }
  } else {                                           // bang tong hop
    oled.setTextSize(2);
    oled.setCursor(0, 0);
    oled.print(b);
    oled.setTextSize(1);
    oled.setCursor(66, 1);
    if (ok) oled.printf("%s %02d/%02d", DAYS[t.tm_wday], t.tm_mday, t.tm_mon + 1);
    oled.setCursor(66, 10);
    if (ok && S.secs) oled.printf(":%02d%s", t.tm_sec, timeSrc == 1 ? " ~" : "");
    oled.setCursor(0, 20);
    if (wx.ok && wfState == WF_STA) oled.printf("%.0fC %s", wx.t, wxText(wx.code));
    else oled.print(wfState == WF_STA ? "Thoi tiet: ..." : (wfState == WF_AP ? "Che do AP (cai WiFi)" : "Khong co mang"));
    bool pc = pcs.at != 0 && millis() - pcs.at < 30000UL;
    oled.setCursor(0, 31);
    if (pc) { oled.printf("CPU %d%%  RAM %d%%", pcs.cpu, pcs.mem); }
    else oled.print("PC: chua noi");
    oled.setCursor(0, 42);
    if (pc && pcs.pState) oled.printf("%s %02d:%02d", pcs.pState == 1 ? "Tap trung" : "Nghi", pcs.pRem / 60, pcs.pRem % 60);
    else if (!todos.empty()) {
      int open = 0;
      for (size_t i = 0; i < todos.size(); i++) if (!todos[i].d) open++;
      oled.printf("Viec con lai: %d", open);
    }
    oled.setCursor(0, 54);
    if (alOn) oled.printf("Bao thuc %02d:%02d", alH, alM);
    else oled.printf("Ghi chu: %d", (int)notes.size());
  }
}

// ---------- popup / chuong bao ----------
void drawPopup() {
  oled.fillRoundRect(3, 6, 122, 52, 6, C_ON);
  oled.setTextColor(C_OFF);
  oled.setTextSize(1);
  oled.setCursor(9, 10);
  oled.print(popTitle);
  oled.drawFastHLine(9, 20, 110, C_OFF);
  for (int i = 0; i < 3; i++) {
    if ((int)popText.length() <= i * 19) break;
    oled.setCursor(9, 25 + i * 10);
    oled.print(popText.substring(i * 19, i * 19 + 19));
  }
  oled.setTextColor(C_ON);
}
void drawRing() {
  bool on = ((millis() - ringStart) / 400) % 2 == 0;
  if (on) { oled.fillRect(0, 0, 128, 64, C_ON); oled.setTextColor(C_OFF); }
  centerText(ringTitle.substring(0, 21), 14, ringTitle.length() <= 10 ? 2 : 1);
  centerText("Bam nut de tat", 48, 1);
  oled.setTextColor(C_ON);
}

// ---------- ve / xu ly ----------
void render() {
  oled.clearDisplay();
  oled.setTextColor(C_ON);
  oled.setTextSize(1);
  oled.setTextWrap(true);
  switch (screen) {
    case SC_HOME: drawHome(); break;
    case SC_MENU: drawMenu(); break;
    case SC_NOTES: drawNotes(); break;
    case SC_RDLIST: drawRdList(); break;
    case SC_READER: drawReader(); break;
    case SC_TODO: drawTodo(); break;
    case SC_STOPWATCH: drawStopwatch(); break;
    case SC_POMO: drawPomo(); break;
    case SC_COUNTDOWN: drawCountdown(); break;
    case SC_ALARM: drawAlarm(); break;
    case SC_DINO: case SC_SNAKE: case SC_FLAPPY: case SC_PONG: case SC_BREAK: drawGame(screen); break;
    case SC_DICE: drawDice(); break;
    case SC_COIN: drawCoin(); break;
    case SC_EIGHT: drawEight(); break;
    case SC_REACT: drawReact(); break;
    case SC_WEATHER: drawWeather(); break;
    case SC_PCMON: drawPcMon(); break;
    case SC_NET: drawNet(); break;
    case SC_EYES: drawEyes(); break;
    case SC_FILES: drawFiles(); break;
    case SC_SETTINGS: drawSettings(); break;
    case SC_INFO: drawInfo(); break;
    case SC_BTNTEST: drawBtnTest(); break;
    case SC_SHARE: drawShare(); break;
    case SC_EQ: drawMusicEq(); break;
  }
  if (ringing) drawRing();
  else if (millis() < popUntil) drawPopup();
  oled.display();
}

void handleEvent(int e) {
  dirty = true;
  if (screen >= SC_DINO && screen <= SC_BREAK) {              // game: chi nhan LEN/XUONG, thoat bang giu ca hai nut
    if (e == EV_BACK) go(SC_MENU);
    else if (e == EV_UP || e == EV_DOWN) gameInput(screen, e);
    return;
  }
  switch (screen) {
    case SC_HOME:
      if (e == EV_UP) { homeMode = (homeMode + 3) % 4; prefs.putUChar("home", homeMode); }
      else if (e == EV_DOWN) { homeMode = (homeMode + 1) % 4; prefs.putUChar("home", homeMode); }
      else if (e == EV_OK) { menuId = 0; go(SC_MENU); }
      else if (e == EV_BACK && !notes.empty()) go(SC_NOTES);
      break;
    case SC_MENU: {
      const MenuDef &m = MENUS[menuId];
      int &sel = menuSel[menuId];
      if (e == EV_UP) sel = (sel + m.n - 1) % m.n;
      else if (e == EV_DOWN) sel = (sel + 1) % m.n;
      else if (e == EV_OK) { int t = m.items[sel].target; if (t < 0) menuId = -t; else go(t); }
      else if (e == EV_BACK) { if (menuId != 0) menuId = 0; else go(SC_HOME); }
      break;
    }
    case SC_NOTES: handleNotes(e); break;
    case SC_RDLIST: handleRdList(e); break;
    case SC_READER: handleReader(e); break;
    case SC_TODO: handleTodo(e); break;
    case SC_STOPWATCH: handleStopwatch(e); break;
    case SC_POMO: handlePomo(e); break;
    case SC_COUNTDOWN: handleCountdown(e); break;
    case SC_ALARM: handleAlarm(e); break;
    case SC_DICE: handleDice(e); break;
    case SC_COIN: handleCoin(e); break;
    case SC_EIGHT: handleEight(e); break;
    case SC_REACT: handleReact(e); break;
    case SC_WEATHER: handleWeather(e); break;
    case SC_PCMON: handlePcMon(e); break;
    case SC_NET: handleNet(e); break;
    case SC_EYES: handleEyes(e); break;
    case SC_FILES: handleFiles(e); break;
    case SC_SETTINGS: handleSettings(e); break;
    case SC_INFO: handleInfo(e); break;
    case SC_BTNTEST: handleBtnTest(e); break;
    case SC_SHARE: handleShare(e); break;
    case SC_EQ: handleMusicEq(e); break;
  }
}
