// ============================================================
//  ESP32 OLED Buddy v2  -  cau hinh chung
// ============================================================
#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <WiFi.h>
#include <WiFiUdp.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <esp_sntp.h>
#include <sys/time.h>
#include <time.h>
#include <vector>
#include <string.h>

// Bluetooth Serial (dien thoai gui lenh qua app "Serial Bluetooth Terminal").
// Neu bien dich loi / thieu flash: them  -DENABLE_BT=0  vao build_flags
#ifndef ENABLE_BT
#define ENABLE_BT 1
#endif
#if ENABLE_BT
#include <BluetoothSerial.h>
#endif

#define FW_VER "2.2"
#define OLED_ADDR 0x3C

// ---- Day noi ----
#define PIN_SDA 21     // OLED SDA
#define PIN_SCL 22     // OLED SCK
#define PIN_A 4        // Nut A = LEN (bam ngan) / CHON (giu)
#define PIN_B 18       // Nut B = XUONG (bam ngan) / QUAY LAI (giu)
#ifndef PIN_BUZZ
#define PIN_BUZZ -1    // chan coi bao (coi chu dong); -1 = khong co
#endif

#define C_ON SSD1306_WHITE
#define C_OFF SSD1306_BLACK

static inline int imin(int a, int b) { return a < b ? a : b; }
static inline int imax(int a, int b) { return a > b ? a : b; }
static inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Gom dau ra cua lenh vao String (dung cho Web API)
class StrOut : public Print {
 public:
  String s;
  size_t write(uint8_t c) override { s += (char)c; return 1; }
  size_t write(const uint8_t *b, size_t n) override { s.concat((const char *)b, (unsigned int)n); return n; }
};

// Su kien nut: A ngan = LEN, B ngan = XUONG, A giu = CHON, B giu = QUAY LAI
enum { EV_NONE, EV_UP, EV_DOWN, EV_OK, EV_BACK };

enum Screen {
  SC_HOME, SC_MENU, SC_NOTES, SC_RDLIST, SC_READER, SC_TODO,
  SC_STOPWATCH, SC_POMO, SC_COUNTDOWN, SC_ALARM,
  SC_DINO, SC_SNAKE, SC_FLAPPY, SC_PONG, SC_BREAK,
  SC_DICE, SC_COIN, SC_EIGHT, SC_REACT,
  SC_WEATHER, SC_PCMON, SC_NET, SC_EYES, SC_FILES, SC_SETTINGS, SC_INFO, SC_BTNTEST, SC_SHARE, SC_EQ
};

// Khai bao truoc (cac file .h goi cheo nhau)
void go(int sc);
void showPopup(const String &title, const String &text);
void processLine(String l, Print &out);
bool openReader(const String &path);
void loadNotes();
void loadTodos();
void wifiRestart();
void startRing(const String &title);
void ntpSync();
String wfIp();
