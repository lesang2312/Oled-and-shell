// ============================================================
//  Tro choi: Dino nhay, Ran san moi, Flappy, Pong, Pha gach
//  Trong game: nut tra su kien ngay khi bam; GIU CA HAI NUT 0.7s de thoat.
//  Pong/Pha gach dung trang thai nut (giu A = len/trai, giu B = xuong/phai)
// ============================================================
#pragma once
#include "core.h"

#define GROUND 56
static inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

void gameEnd(int g, uint32_t sc) {
  if (sc > hiScore[g]) {
    hiScore[g] = sc;
    char k[6];
    snprintf(k, sizeof(k), "hi%d", g);
    prefs.putUInt(k, sc);
  }
}
void drawOver(const char *title, uint32_t score, uint32_t hi) {
  oled.fillRect(10, 12, 108, 42, C_OFF);
  oled.drawRect(10, 12, 108, 42, C_ON);
  centerText(title, 16, 2);
  centerText("D:" + String((unsigned long)score) + "  HI:" + String((unsigned long)hi), 35, 1);
  centerText("Bam nut: choi lai", 44, 1);
}

// ============ Dino nhay ============
float dnH = 0, dnV = 0, dnSpd = 2.6f;
float dnX[2];
uint8_t dnW[2], dnHt[2];
uint32_t dnScore = 0;
bool dnOver = false, dnJump = false;

void dinoReset() {
  dnH = 0; dnV = 0; dnScore = 0; dnOver = false; dnJump = false;
  dnX[0] = 140; dnX[1] = 240;
  for (int i = 0; i < 2; i++) { dnW[i] = random(5, 10); dnHt[i] = random(8, 16); }
}
void dinoStep() {
  if (dnOver) return;
  if (dnJump && dnH == 0) dnV = 6.4f;
  dnJump = false;
  if (dnV != 0 || dnH > 0) {
    dnH += dnV; dnV -= 0.62f;
    if (dnH <= 0) { dnH = 0; dnV = 0; }
  }
  dnSpd = 2.6f + dnScore / 400.0f;
  if (dnSpd > 5.5f) dnSpd = 5.5f;
  for (int i = 0; i < 2; i++) {
    dnX[i] -= dnSpd;
    if (dnX[i] + dnW[i] < 0) {
      float farX = dnX[1 - i];
      if (farX < 128) farX = 128;
      dnX[i] = farX + random(55, 110);
      dnW[i] = random(5, 10); dnHt[i] = random(8, 16);
    }
  }
  dnScore++;
  for (int i = 0; i < 2; i++) {
    if (22 > dnX[i] && 14 < dnX[i] + dnW[i] && dnH < dnHt[i]) { dnOver = true; gameEnd(0, dnScore / 10); }
  }
}
void drawDino() {
  oled.drawFastHLine(0, GROUND, 128, C_ON);
  for (int k = 0; k < 4; k++) oled.drawPixel((int)((128 - (dnScore * 3) % 128) + k * 37) % 128, GROUND + 3, C_ON);
  int py = GROUND - (int)dnH;
  oled.fillRect(14, py - 10, 8, 10, C_ON);
  oled.drawPixel(19, py - 8, C_OFF);
  for (int i = 0; i < 2; i++) oled.fillRect((int)dnX[i], GROUND - dnHt[i], dnW[i], dnHt[i], C_ON);
  oled.setCursor(0, 0); oled.print(dnScore / 10);
  oled.setCursor(78, 0); oled.printf("HI %u", (unsigned)hiScore[0]);
  if (dnOver) drawOver("GAME OVER", dnScore / 10, hiScore[0]);
}

// ============ Ran san moi ============
#define SN_W 16
#define SN_H 7
int8_t snX[112], snY[112];
int snLen = 3, snDir = 0, snTurn = 0, snFx = 0, snFy = 0, snScore = 0;
uint32_t snNext = 0;
bool snOver = false;

void snFood() {
  for (int tries = 0; tries < 100; tries++) {
    int x = random(SN_W), y = random(SN_H);
    bool ok = true;
    for (int i = 0; i < snLen; i++) if (snX[i] == x && snY[i] == y) { ok = false; break; }
    if (ok) { snFx = x; snFy = y; return; }
  }
  snFx = 0; snFy = 0;
}
void snakeReset() {
  snLen = 3; snDir = 0; snTurn = 0; snScore = 0; snOver = false;
  for (int i = 0; i < snLen; i++) { snX[i] = 8 - i; snY[i] = 3; }
  snFood();
  snNext = millis() + 500;
}
void snakeStep() {
  if (snOver || millis() < snNext) return;
  snNext = millis() + imax(70, 230 - snScore * 7);
  if (snTurn) { snDir = (snDir + (snTurn > 0 ? 1 : 3)) % 4; snTurn = 0; }
  static const int8_t dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
  int nx = (snX[0] + dx[snDir] + SN_W) % SN_W;
  int ny = (snY[0] + dy[snDir] + SN_H) % SN_H;
  bool eat = (nx == snFx && ny == snFy);
  int chk = eat ? snLen : snLen - 1;
  for (int i = 0; i < chk; i++) if (snX[i] == nx && snY[i] == ny) { snOver = true; gameEnd(1, snScore); return; }
  if (eat && snLen < 110) snLen++;
  for (int i = snLen - 1; i > 0; i--) { snX[i] = snX[i - 1]; snY[i] = snY[i - 1]; }
  snX[0] = nx; snY[0] = ny;
  if (eat) { snScore++; snFood(); }
}
void drawSnake() {
  oled.setCursor(0, 0); oled.printf("Diem %d", snScore);
  oled.setCursor(78, 0); oled.printf("HI %u", (unsigned)hiScore[1]);
  oled.drawRect(0, 8, 128, 56, C_ON);
  for (int i = snLen - 1; i >= 0; i--) {
    if (i == 0) oled.fillRect(snX[i] * 8, 8 + snY[i] * 8, 8, 8, C_ON);
    else oled.fillRect(snX[i] * 8 + 1, 8 + snY[i] * 8 + 1, 6, 6, C_ON);
  }
  oled.drawRect(snFx * 8 + 2, 8 + snFy * 8 + 2, 4, 4, C_ON);
  if (snOver) drawOver("GAME OVER", snScore, hiScore[1]);
}

// ============ Flappy ============
float fbY = 28, fbV = 0;
int fpX[2], fpG[2], fbScore = 0;
bool fpPass[2], fbOver = false, fbStart = false;

void flappyReset() {
  fbY = 28; fbV = 0; fbScore = 0; fbOver = false; fbStart = false;
  fpX[0] = 130; fpX[1] = 200;
  for (int i = 0; i < 2; i++) { fpG[i] = random(8, 32); fpPass[i] = false; }
}
void flappyStep() {
  if (fbOver || !fbStart) return;
  fbV += 0.32f;
  fbY += fbV;
  for (int i = 0; i < 2; i++) {
    fpX[i] -= 2;
    if (fpX[i] < -12) { fpX[i] = imax(fpX[1 - i] + 70, 130); fpG[i] = random(8, 32); fpPass[i] = false; }
    if (!fpPass[i] && fpX[i] + 12 < 30) { fpPass[i] = true; fbScore++; }
    if (fpX[i] < 36 && fpX[i] + 12 > 30 && (fbY < fpG[i] || fbY + 5 > fpG[i] + 24)) fbOver = true;
  }
  if (fbY < 0 || fbY + 5 > 63) fbOver = true;
  if (fbOver) gameEnd(2, fbScore);
}
void drawFlappy() {
  for (int i = 0; i < 2; i++) {
    oled.fillRect(fpX[i], 0, 12, fpG[i], C_ON);
    oled.fillRect(fpX[i], fpG[i] + 24, 12, 64 - fpG[i] - 24, C_ON);
  }
  oled.fillRect(29, (int)fbY - 1, 8, 7, C_OFF);
  oled.fillRect(30, (int)fbY, 6, 5, C_ON);
  oled.drawPixel(34, (int)fbY + 1, C_OFF);
  oled.setCursor(0, 0); oled.print(fbScore);
  oled.setCursor(84, 0); oled.printf("HI %u", (unsigned)hiScore[2]);
  if (!fbStart && !fbOver) centerText("Bam de bay", 28, 1);
  if (fbOver) drawOver("GAME OVER", fbScore, hiScore[2]);
}

// ============ Pong (nguoi vs may) ============
float pbX = 64, pbY = 32, pvX = 2, pvY = 1, aY = 25;
int pPad = 25, pSc = 0, aSc = 0;
bool pOver = false;
uint32_t pServe = 0;

void pongServe(int dir) {
  pbX = 64; pbY = 32;
  pvX = 2.0f * dir;
  pvY = (random(2) ? 1 : -1) * (0.6f + random(0, 8) / 10.0f);
  pServe = millis() + 700;
}
void pongReset() { pPad = 25; aY = 25; pSc = 0; aSc = 0; pOver = false; pongServe(1); }
void pongStep() {
  if (pOver) return;
  if (btns[0].raw) pPad -= 2;
  if (btns[1].raw) pPad += 2;
  pPad = clampi(pPad, 0, 50);
  float target = (pvX > 0) ? pbY - 7 : 25;                  // may chi duoi theo bong khi bong bay ve phia no
  aY += clampf(target - aY, -1.4f, 1.4f);
  aY = clampf(aY, 0, 50);
  if (millis() < pServe) return;
  pbX += pvX; pbY += pvY;
  if (pbY < 1) { pbY = 1; pvY = -pvY; }
  if (pbY > 62) { pbY = 62; pvY = -pvY; }
  if (pvX < 0 && pbX <= 6 && pbX >= 2 && pbY >= pPad - 1 && pbY <= pPad + 15) {
    pvX = clampf(-pvX * 1.06f, -3.6f, 3.6f); pvY = (pbY - (pPad + 7)) * 0.22f; pbX = 6.5f;
  }
  if (pvX > 0 && pbX >= 121 && pbX <= 125 && pbY >= aY - 1 && pbY <= aY + 15) {
    pvX = clampf(-pvX * 1.03f, -3.6f, 3.6f); pvY = (pbY - (aY + 7)) * 0.22f; pbX = 120.5f;
  }
  if (pbX < -2) { aSc++; if (aSc >= 7) { pOver = true; gameEnd(3, 0); } else pongServe(1); }
  if (pbX > 130) {
    pSc++;
    if (pSc >= 7) { pOver = true; gameEnd(3, 7 - aSc); } else pongServe(-1);
  }
}
void drawPong() {
  for (int y = 0; y < 64; y += 6) oled.drawFastVLine(64, y, 3, C_ON);
  oled.fillRect(2, pPad, 3, 14, C_ON);
  oled.fillRect(123, (int)aY, 3, 14, C_ON);
  oled.fillRect((int)pbX - 1, (int)pbY - 1, 3, 3, C_ON);
  oled.setCursor(48, 0); oled.print(pSc);
  oled.setCursor(76, 0); oled.print(aSc);
  if (pOver) drawOver(pSc >= 7 ? "BAN THANG!" : "MAY THANG", pSc, hiScore[3]);
}

// ============ Pha gach ============
#define BR_C 8
#define BR_R 4
bool brk[BR_R][BR_C];
float bkX = 64, bkY = 57, bkVX = 1, bkVY = -2;
int bkPad = 53, bkLives = 3, bkScore = 0, bkLevel = 1, bkLeft = 0;
bool bkLaunch = false, bkOver = false;

void brFill() {
  for (int r = 0; r < BR_R; r++) for (int c = 0; c < BR_C; c++) brk[r][c] = true;
  bkLeft = BR_R * BR_C;
}
void breakReset() { bkPad = 53; bkLives = 3; bkScore = 0; bkLevel = 1; bkOver = false; bkLaunch = false; brFill(); }
void breakLaunch() {
  bkLaunch = true;
  bkVX = (random(2) ? 1 : -1) * 1.2f;
  bkVY = -clampf(1.8f + 0.2f * bkLevel, 1.8f, 3.2f);
}
void breakStep() {
  if (bkOver) return;
  if (btns[0].raw) bkPad -= 3;
  if (btns[1].raw) bkPad += 3;
  bkPad = clampi(bkPad, 0, 128 - 22);
  if (!bkLaunch) { bkX = bkPad + 11; bkY = 57; return; }
  bkX += bkVX; bkY += bkVY;
  if (bkX < 1) { bkX = 1; bkVX = -bkVX; }
  if (bkX > 126) { bkX = 126; bkVX = -bkVX; }
  if (bkY < 9) { bkY = 9; bkVY = -bkVY; }
  if (bkY >= 10 && bkY < 10 + BR_R * 6) {
    int r = (int)(bkY - 10) / 6, c = (int)bkX / 16;
    if (r >= 0 && r < BR_R && c >= 0 && c < BR_C && brk[r][c]) {
      brk[r][c] = false; bkLeft--; bkScore += 10; bkVY = -bkVY;
      if (bkLeft == 0) { bkLevel++; brFill(); bkLaunch = false; }
    }
  }
  if (bkVY > 0 && bkY >= 58 && bkY <= 61 && bkX >= bkPad - 1 && bkX <= bkPad + 23) {
    bkVY = -fabsf(bkVY);
    bkVX = clampf((bkX - (bkPad + 11)) * 0.18f, -2.6f, 2.6f);
  }
  if (bkY > 64) {
    bkLives--; bkLaunch = false;
    if (bkLives <= 0) { bkOver = true; gameEnd(4, bkScore); }
  }
}
void drawBreak() {
  for (int r = 0; r < BR_R; r++) for (int c = 0; c < BR_C; c++)
    if (brk[r][c]) oled.fillRect(c * 16 + 1, 10 + r * 6, 14, 4, C_ON);
  oled.fillRect(bkPad, 60, 22, 3, C_ON);
  oled.fillRect((int)bkX - 1, (int)bkY - 1, 3, 3, C_ON);
  oled.setCursor(0, 0); oled.print(bkScore);
  oled.setCursor(60, 0); oled.printf("L%d", bkLives);
  oled.setCursor(84, 0); oled.printf("HI %u", (unsigned)hiScore[4]);
  if (!bkLaunch && !bkOver) centerText("Bam de phat bong", 40, 1);
  if (bkOver) drawOver("GAME OVER", bkScore, hiScore[4]);
}

// ============ Dieu phoi ============
void gameReset(int sc) {
  switch (sc) {
    case SC_DINO: dinoReset(); break;
    case SC_SNAKE: snakeReset(); break;
    case SC_FLAPPY: flappyReset(); break;
    case SC_PONG: pongReset(); break;
    case SC_BREAK: breakReset(); break;
  }
}
void gameStep(int sc) {
  switch (sc) {
    case SC_DINO: dinoStep(); break;
    case SC_SNAKE: snakeStep(); break;
    case SC_FLAPPY: flappyStep(); break;
    case SC_PONG: pongStep(); break;
    case SC_BREAK: breakStep(); break;
  }
}
void drawGame(int sc) {
  switch (sc) {
    case SC_DINO: drawDino(); break;
    case SC_SNAKE: drawSnake(); break;
    case SC_FLAPPY: drawFlappy(); break;
    case SC_PONG: drawPong(); break;
    case SC_BREAK: drawBreak(); break;
  }
}
// e = EV_UP / EV_DOWN (nut vua duoc bam)
void gameInput(int sc, int e) {
  switch (sc) {
    case SC_DINO: if (dnOver) dinoReset(); else dnJump = true; break;
    case SC_SNAKE:
      if (snOver) snakeReset();
      else if (snTurn == 0) snTurn = (e == EV_UP) ? -1 : 1;
      break;
    case SC_FLAPPY:
      if (fbOver) flappyReset();
      else { fbStart = true; fbV = -3.3f; }
      break;
    case SC_PONG: if (pOver) pongReset(); break;
    case SC_BREAK:
      if (bkOver) breakReset();
      else if (!bkLaunch) breakLaunch();
      break;
  }
}
