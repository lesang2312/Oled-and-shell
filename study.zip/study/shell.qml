//@ pragma IconTheme Papirus-Dark
// Shell Quickshell nhẹ cho học tập / làm việc
// Chạy: qs -c study
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import Quickshell.Services.Pipewire
import Quickshell.Services.Mpris
import Quickshell.Services.Notifications
import QtQuick
import Qt.labs.folderlistmodel

ShellRoot {
    id: root

    // ---- Cấu hình ----
    readonly property string home: Quickshell.env("HOME")
    readonly property string wallDir: home + "/Pictures/Wallpapers"
    readonly property string stateFile: home + "/.cache/qs-study/wallpaper"
    // Thư mục lưu ảnh chụp: nằm trong thư mục shell (~/.config/quickshell/study/scr)
    // Muốn đổi chỗ khác, sửa duy nhất dòng này, ví dụ home + "/Pictures/Screenshots"
    readonly property string scrDir: home + "/.config/quickshell/study/scr"

    // ---- Trạng thái chung ----
    property string wallpaper: ""
    property int wallIndex: 0
    property bool launcherOpen: false
    property bool pickerOpen: false          // ô chọn hình nền

    property bool powerOpen: false           // menu nguồn
    property bool connectOpen: false         // bảng Wi-Fi / Bluetooth
    property int connectTab: 0               // 0 = Wi-Fi, 1 = Bluetooth

    function openConnect(tab) {
        if (connectOpen && connectTab === tab) { connectOpen = false; return }
        connectTab = tab
        connectOpen = true
    }

    property bool memoryOpen: false          // thư viện ảnh kỷ niệm

    // Chỉ mở một bảng tại một thời điểm
    property bool todoOpen: false            // việc cần làm
    property bool buddyOpen: false           // gửi chữ / hình sang màn OLED ESP32
    readonly property var panelFlags: ["launcherOpen", "pickerOpen", "powerOpen", "connectOpen", "memoryOpen", "todoOpen", "buddyOpen"]
    function onlyOpen(name) {
        for (const p of panelFlags) if (p !== name && root[p]) root[p] = false
    }
    onLauncherOpenChanged: if (launcherOpen) onlyOpen("launcherOpen")
    onPickerOpenChanged: if (pickerOpen) onlyOpen("pickerOpen")
    onPowerOpenChanged: if (powerOpen) onlyOpen("powerOpen")
    onConnectOpenChanged: if (connectOpen) onlyOpen("connectOpen")
    onMemoryOpenChanged: if (memoryOpen) onlyOpen("memoryOpen")
    onTodoOpenChanged: if (todoOpen) onlyOpen("todoOpen")
    onBuddyOpenChanged: if (buddyOpen) onlyOpen("buddyOpen")

    // ---- Dynamic Island: gọi notifyIsland(icon, chữ, giá trị 0..1 hoặc -1, màu) để island bung ra ----
    property string islandIcon: ""
    property string islandText: ""
    property real islandValue: -1
    property string islandTone: "#89b4fa"
    property int islandSeq: 0
    property bool islandPeek: false          // thẻ nhanh đang mở
    property bool islandReady: false         // tránh bung island lúc mới khởi động

    function notifyIsland(icon, text, value, tone) {
        islandIcon = icon
        islandText = text
        islandValue = (value === undefined) ? -1 : value
        islandTone = tone || "#89b4fa"
        islandSeq++
    }

    Timer { interval: 3500; running: true; onTriggered: root.islandReady = true }

    // ---- Thông báo hệ thống -> hiện trên island (thay mako) ----
    // Quickshell tự làm "máy chủ thông báo" (org.freedesktop.Notifications), nên PHẢI tắt mako/dunst.
    property var notifCur: null              // thông báo đang hiện
    property int notifSeq: 0
    property string nApp: ""
    property string nSummary: ""
    property string nBody: ""
    property string nIcon: ""
    property bool nCritical: false
    property int dndMissed: 0                // số thông báo bị ẩn trong lúc tập trung

    function notifIcon(n) {
        if (n.image && n.image !== "") return n.image
        const a = n.appIcon
        if (!a) return ""
        if (a.startsWith("/")) return "file://" + a
        if (a.startsWith("file:") || a.startsWith("http") || a.startsWith("image:")) return a
        return Quickshell.iconPath(a, true)
    }

    function releaseNotif() {
        if (notifCur) { try { notifCur.expire() } catch (e) {} notifCur = null }
    }

    function dismissNotif() {
        if (notifCur) { try { notifCur.dismiss() } catch (e) {} notifCur = null }
    }

    // Bấm vào thông báo: chạy hành động mặc định (nếu có, ví dụ mở cửa sổ app) rồi đóng
    function invokeNotif() {
        const n = notifCur
        if (!n) return
        try {
            for (let i = 0; i < n.actions.length; i++) {
                if (n.actions[i].identifier === "default") { n.actions[i].invoke(); break }
            }
        } catch (e) {}
        dismissNotif()
    }

    function pushNotif(n) {
        n.tracked = true
        const critical = n.urgency === NotificationUrgency.Critical
        if (dnd && !critical) {                      // đang tập trung: ẩn đi (khẩn cấp vẫn hiện)
            dndMissed++
            n.expire()
            return
        }
        releaseNotif()
        notifCur = n
        nApp = n.appName
        nSummary = n.summary
        nBody = (n.body || "").replace(/\s*\n\s*/g, " ")
        nIcon = notifIcon(n)
        nCritical = critical
        notifSeq++
    }

    NotificationServer {
        id: notifServer
        bodySupported: true
        bodyMarkupSupported: false
        imageSupported: true
        actionsSupported: true
        onNotification: n => root.pushNotif(n)
    }

    // ---- Nhạc (MPRIS: YouTube trong trình duyệt, Spotify, mpv, ...) ----
    // Ưu tiên trình phát đang chạy, không có thì lấy cái đầu tiên có bài.
    readonly property var player: {
        const l = Mpris.players.values
        let fallback = null
        for (let i = 0; i < l.length; i++) {
            if (l[i].isPlaying) return l[i]
            if (!fallback && l[i].trackTitle !== "") fallback = l[i]
        }
        return fallback
    }

    onWallpaperChanged: if (islandReady && wallpaper !== "") notifyIsland("🖼", "Đã đổi hình nền", -1, "#f5c2e7")

    // ---- Pomodoro: một đồng hồ chung (bar trên mọi màn hình cùng dùng) ----
    readonly property int focusMin: 25
    readonly property int breakMin: 5
    property bool pomoRunning: false
    property bool pomoBreak: false
    property int pomoRemaining: focusMin * 60
    property int pomoToday: 0            // số phiên tập trung đã xong hôm nay
    property int pomoMinutes: 0          // tổng phút tập trung hôm nay
    property string pomoDate: ""

    function todayStr() { return Qt.formatDate(new Date(), "yyyy-MM-dd") }
    function pomoToggle() {
        pomoRunning = !pomoRunning
        notifyIsland(pomoRunning ? "▶" : "⏸",
                     pomoRunning ? (pomoBreak ? "Đang nghỉ giải lao" : "Bắt đầu tập trung") : "Tạm dừng",
                     -1, "#f38ba8")
    }
    function pomoReset() { pomoRunning = false; pomoBreak = false; pomoRemaining = focusMin * 60 }
    function savePomo() {
        pomoFile.setText(JSON.stringify({ date: pomoDate, sessions: pomoToday, minutes: pomoMinutes }))
    }

    function pomoFinish() {
        if (!pomoBreak) {                                   // vừa xong một phiên tập trung
            if (pomoDate !== todayStr()) { pomoDate = todayStr(); pomoToday = 0; pomoMinutes = 0 }
            pomoToday++
            pomoMinutes += focusMin
            savePomo()
        }
        pomoBreak = !pomoBreak
        pomoRemaining = (pomoBreak ? breakMin : focusMin) * 60
        notifyIsland("🍅", pomoBreak ? "Xong một phiên! Nghỉ " + breakMin + " phút" : "Vào tập trung " + focusMin + " phút",
                     -1, pomoBreak ? "#a6e3a1" : "#f38ba8")
    }

    Timer {
        interval: 1000
        repeat: true
        running: root.pomoRunning
        onTriggered: {
            root.pomoRemaining--
            if (root.pomoRemaining <= 0) root.pomoFinish()
        }
    }

    FileView {
        id: pomoFile
        path: root.home + "/.config/quickshell/study/pomodoro.json"
        printErrors: false
        onLoaded: {
            try {
                const o = JSON.parse(text())
                if (o.date === root.todayStr()) {          // sang ngày mới thì bắt đầu lại từ 0
                    root.pomoDate = o.date
                    root.pomoToday = o.sessions || 0
                    root.pomoMinutes = o.minutes || 0
                }
            } catch (e) {}
        }
    }

    // ---- Chế độ tập trung: ẩn thông báo (trừ loại khẩn cấp) ----
    // Tự bật khi đang trong phiên tập trung của Pomodoro, hoặc bật tay bằng nút 🔔 trên bar.
    property bool manualDnd: false
    readonly property bool dnd: manualDnd || (pomoRunning && !pomoBreak)
    onDndChanged: {
        if (!dnd && dndMissed > 0) {
            const m = dndMissed
            dndMissed = 0
            if (islandReady) notifyIsland("🔔", "Hết tập trung · " + m + " thông báo bị ẩn", -1, "#94e2d5")
            return
        }
        if (islandReady) notifyIsland(dnd ? "🔕" : "🔔", dnd ? "Chế độ tập trung: bật" : "Đã tắt chế độ tập trung", -1, "#94e2d5")
    }

    // ---- Theo dõi CPU / RAM (đọc /proc mỗi 4 giây, rất nhẹ) ----
    property int sysCpu: 0
    property int sysMem: 0

    Process {
        id: sysProc
        command: ["sh", root.home + "/.config/quickshell/study/sysmon.sh"]
        stdout: StdioCollector {
            onStreamFinished: {
                const p = text.trim().split("|")
                root.sysCpu = parseInt(p[0]) || 0
                root.sysMem = parseInt(p[1]) || 0
            }
        }
    }

    Timer {
        interval: 4000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: sysProc.running = true
    }

    // ---- Trạng thái mạng (kiểm tra mỗi 20 giây bằng netcheck.sh) ----
    // online | portal (cần đăng nhập) | nonet (có Wi-Fi nhưng không ra Internet) | offline | unknown
    property string netState: "unknown"
    property string netName: ""

    function refreshNet() { netProc.running = true }

    Process {
        id: netProc
        command: ["sh", root.home + "/.config/quickshell/study/netcheck.sh"]
        stdout: StdioCollector {
            onStreamFinished: {
                const p = text.trim().split("|")
                root.netState = p[0] || "unknown"
                root.netName = p.slice(1).join("|")
            }
        }
    }

    Timer {
        interval: 20000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.refreshNet()
    }

    // Báo khi vừa nối Wi-Fi mà không dùng được
    property string prevNet: "unknown"

    onNetStateChanged: {
        if (netState === "portal") {
            notifyIsland("🌐", "Wi-Fi cần đăng nhập", -1, "#fab387")
        } else if (netState === "nonet") {
            notifyIsland("⚠", "Không có Internet", -1, "#fab387")
        } else if (netState === "online" && prevNet !== "unknown" && prevNet !== "online") {
            notifyIsland("📶", "Đã kết nối " + netName, -1, "#a6e3a1")
        } else if (netState === "offline" && prevNet === "online") {
            notifyIsland("📵", "Mất kết nối mạng", -1, "#f38ba8")
        }
        prevNet = netState
    }

    // ---- Ảnh kỷ niệm: lưu trong thư mục shell ----
    readonly property string memDir: home + "/.config/quickshell/study/memories"

    Process { command: ["mkdir", "-p", root.memDir]; running: true }

    // ---- Mục tiêu (widget góc trên phải) ----
    // Lần đặt đầu tiên không tính. Sau đó được sửa tối đa goalMaxEdits lần rồi ghim cố định.
    readonly property int goalMaxEdits: 10
    property string goalText: ""
    property int goalEdits: 0
    readonly property bool goalPinned: goalEdits >= goalMaxEdits

    FileView {
        id: goalFile
        path: root.home + "/.config/quickshell/study/goal.json"
        printErrors: false
        onLoaded: {
            try {
                const o = JSON.parse(text())
                root.goalText = o.text || ""
                root.goalEdits = parseInt(o.edits) || 0
            } catch (e) {}
        }
    }

    // Trả về true nếu đã lưu
    function saveGoal(t) {
        t = t.trim()
        if (goalPinned || t === "" || t === goalText) return false
        if (goalText !== "") goalEdits++            // lần đặt đầu không tính là "sửa"
        goalText = t
        goalFile.setText(JSON.stringify({ text: goalText, edits: goalEdits }))
        return true
    }

    function togglePicker() { pickerOpen = !pickerOpen }

    // ---- Workspace (chỉ dùng 3 ô) ----
    readonly property int wsCount: 3

    function gotoWs(n) {
        Hyprland.dispatch("hl.dsp.focus({ workspace = " + n + " })")
    }

    function cycleWs(step) {
        let cur = Hyprland.focusedWorkspace ? Hyprland.focusedWorkspace.id : 1
        if (cur < 1 || cur > wsCount) cur = 1
        gotoWs(((cur - 1 + step + wsCount) % wsCount) + 1)
    }

    // ---- Âm lượng (cho phép tới 200%) ----
    readonly property real maxVolume: 2.0
    readonly property var sink: Pipewire.defaultAudioSink
    PwObjectTracker { objects: [root.sink] }

    function changeVolume(delta) {
        if (!sink) return
        sink.audio.muted = false
        const v = Math.max(0, Math.min(maxVolume, sink.audio.volume + delta))
        sink.audio.volume = v
        notifyIsland(v === 0 ? "🔈" : "🔊", Math.round(v * 100) + "%", v / maxVolume, v > 1.0 ? "#f38ba8" : "#89b4fa")
    }

    // Kéo thanh trượt trên island (không bung sự kiện)
    function setVolume(v) {
        if (!sink) return
        sink.audio.muted = false
        sink.audio.volume = Math.max(0, Math.min(maxVolume, v))
    }

    function toggleMute() {
        if (!sink) return
        sink.audio.muted = !sink.audio.muted
        notifyIsland(sink.audio.muted ? "🔇" : "🔊", sink.audio.muted ? "Đã tắt tiếng" : "Đã bật tiếng", -1, "#89b4fa")
    }

    // ---- Độ sáng (cần brightnessctl; -1 = không có đèn nền) ----
    property int brightness: -1
    property bool brightnessPending: false   // vừa chỉnh -> đọc lại xong thì hiện lên island

    Process {
        id: getBrightness
        command: ["brightnessctl", "-c", "backlight", "-m"]
        running: true
        stdout: StdioCollector {
            onStreamFinished: {
                const f = text.trim().split(",")
                if (f.length > 3) root.brightness = parseInt(f[3])
                if (root.brightnessPending && root.brightness >= 0) {
                    root.brightnessPending = false
                    root.notifyIsland("🔆", root.brightness + "%", root.brightness / 100, "#f9e2af")
                }
            }
        }
    }

    Timer {
        id: brightnessRefresh
        interval: 200
        onTriggered: getBrightness.running = true
    }

    // Kéo thanh trượt độ sáng (gộp lệnh, 70ms/lần cho đỡ nặng)
    property int brightTarget: 50
    Timer {
        id: brightThrottle
        interval: 70
        onTriggered: Quickshell.execDetached(["brightnessctl", "-c", "backlight", "-n1", "set", root.brightTarget + "%"])
    }
    function setBrightness(p) {
        if (brightness < 0) return
        p = Math.max(1, Math.min(100, Math.round(p)))
        brightness = p
        brightTarget = p
        if (!brightThrottle.running) brightThrottle.start()
    }

    function changeBrightness(delta) {
        const arg = Math.abs(delta) + "%" + (delta > 0 ? "+" : "-")
        // -n1: không cho tụt xuống 0 (tránh màn hình đen hẳn)
        Quickshell.execDetached(["brightnessctl", "-c", "backlight", "-n1", "set", arg])
        brightnessPending = true
        brightnessRefresh.restart()
    }

    FolderListModel {
        id: walls
        folder: "file://" + root.wallDir
        nameFilters: ["*.png", "*.jpg", "*.jpeg", "*.webp"]
        showDirs: false
        sortField: FolderListModel.Name
        onCountChanged: if (root.wallpaper === "" && count > 0) root.wallpaper = get(0, "filePath")
    }

    FileView {
        id: state
        path: root.stateFile
        printErrors: false          // lần chạy đầu chưa có file -> không báo lỗi
        onLoaded: {
            const p = text().trim()
            if (p !== "") root.wallpaper = p
        }
    }

    function nextWallpaper(delta) {
        if (walls.count === 0) return
        wallIndex = (wallIndex + delta + walls.count) % walls.count
        wallpaper = walls.get(wallIndex, "filePath")
        state.setText(wallpaper)
    }

    // Đặt đúng ảnh được chọn trong ô chọn nền
    function setWallpaper(path, index) {
        wallIndex = index
        wallpaper = path
        state.setText(path)
    }

    // Đặt nền từ một file bất kỳ (ví dụ ảnh kỷ niệm)
    function setWallpaperFile(path) {
        for (let i = 0; i < walls.count; i++) {
            if (walls.get(i, "filePath") === path) { wallIndex = i; break }
        }
        wallpaper = path
        state.setText(path)
    }

    // ---- Chụp màn hình (cần grim, slurp, wl-clipboard, libnotify) ----
    // mode: "full" = toàn màn hình, "region" = chọn vùng (cả hai: lưu file + copy),
    //       "copy" = chọn vùng, chỉ copy nhanh vào clipboard, không lưu file
    function shot(mode) {
        const script = [
            'dir="$1"; mode="$2"; mkdir -p "$dir"',
            'f="$dir/$(date +%Y%m%d-%H%M%S).png"',
            'case "$mode" in',
            '  full)   grim "$f" && wl-copy < "$f" && notify-send -t 2000 "📷 Đã chụp" "Đã lưu và copy" ;;',
            '  region) g=$(slurp) || exit 0; grim -g "$g" "$f" && wl-copy < "$f" && notify-send -t 2000 "📷 Đã chụp vùng" "Đã lưu và copy" ;;',
            '  copy)   g=$(slurp) || exit 0; grim -g "$g" - | wl-copy && notify-send -t 2000 "📋 Đã copy" "Ctrl+V để dán" ;;',
            'esac'
        ].join("\n")
        Quickshell.execDetached(["sh", "-c", script, "sh", scrDir, mode])
    }

    IpcHandler {
        target: "screenshot"
        function full(): void { root.shot("full") }
        function region(): void { root.shot("region") }
        function copy(): void { root.shot("copy") }
    }

    // Phím tắt gọi vào shell:  qs -c study ipc call <target> <hàm>
    IpcHandler {
        target: "island"
        function peek(): void { root.islandPeek = !root.islandPeek }     // mở/đóng thẻ nhanh
        function test(): void { root.notifyIsland("✨", "Dynamic Island", -1, "#cba6f7") }
        function notify(): void { Quickshell.execDetached(["notify-send", "Thử thông báo", "Thông báo này hiện trên Dynamic Island"]) }
    }

    IpcHandler {
        target: "media"
        function toggle(): void { if (root.player) root.player.togglePlaying() }
        function next(): void { if (root.player) root.player.next() }
        function prev(): void { if (root.player) root.player.previous() }
    }

    IpcHandler {
        target: "todo"
        function toggle(): void { root.todoOpen = !root.todoOpen }
    }

    // ---- ESP32 Buddy: gửi chữ / hình / file .txt sang màn OLED qua USB hoặc WiFi (buddy.py) ----
    // buddyRun(["note","chữ"]) | ["msg",..] | ["wall","/ảnh"] | ["put","/file.txt"] | ["puttext","-","chữ"] | ["time"] | ["ls"]
    //          ["rm","tên"] | ["get","tên"] | ["open","tên"] | ["alarm","06:30"] | ["timer","25","nhãn"] | ["wifi","ssid","pass"] | ["geo","lat","lon"]
    // silent = true: không báo trên Island (dùng cho tự đồng bộ); thiết bị không có mặt (mã 3) thì im lặng.
    // Lệnh gửi liên tiếp được xếp hàng, chạy lần lượt.
    property bool buddyBusy: false
    property bool buddyOk: true
    property string buddyStatus: ""
    property var buddyQueue: []
    property var buddyFiles: []              // kết quả "ls": [{name, size}]
    property string buddyFsInfo: ""
    property var buddyCur: []
    property bool buddyCurSilent: false
    property bool buddyAuto: false           // tự đồng bộ giờ, CPU/RAM, Pomodoro, việc cần làm mỗi 15 giây
    property string buddyMode: "auto"        // auto | usb | net

    function buddyRun(args, silent) {
        if (buddyBusy) { buddyQueue = buddyQueue.concat([{ args: args, silent: !!silent }]); return }
        buddyBusy = true
        buddyCur = args
        buddyCurSilent = !!silent
        if (!silent) buddyStatus = "Đang gửi…"
        // Thêm dòng "::<mã thoát>" ở cuối để biết thành công (0), lỗi (1) hay không thấy thiết bị (3)
        buddyProc.command = ["env", "BUDDY_MODE=" + buddyMode, "sh", "-c", 'python3 "$@"; echo "::$?"', "sh",
                             home + "/.config/quickshell/study/buddy.py"].concat(args)
        buddyProc.running = true
    }

    function buddySaveCfg() { buddyCfg.setText(JSON.stringify({ auto: buddyAuto, mode: buddyMode })) }
    function buddySetAuto(on) { buddyAuto = on; buddySaveCfg(); notifyIsland("📟", on ? "Tự đồng bộ ESP32: bật" : "Tự đồng bộ ESP32: tắt", -1, "#cba6f7") }
    function buddySetMode(m) { buddyMode = m; buddySaveCfg() }
    function buddySyncArgs() {
        return ["sync", String(sysCpu), String(sysMem), String(pomoRunning ? (pomoBreak ? 2 : 1) : 0),
                String(pomoRemaining), String(pomoToday)]
    }

    FileView {
        id: buddyCfg
        path: root.home + "/.config/quickshell/study/buddy.json"
        printErrors: false
        onLoaded: {
            try {
                const o = JSON.parse(text())
                root.buddyAuto = !!o.auto
                if (o.mode === "usb" || o.mode === "net" || o.mode === "auto") root.buddyMode = o.mode
            } catch (e) {}
        }
    }

    Process {
        id: buddyProc
        stdout: StdioCollector {
            onStreamFinished: {
                const lines = text.trim().split("\n")
                const last = lines.pop() || ""
                const code = last.startsWith("::") ? parseInt(last.slice(2)) : 1
                const msg = lines.join("\n").trim()
                const cur = root.buddyCur
                const silent = root.buddyCurSilent

                if (cur[0] === "ls" && code === 0) {                      // danh sách file -> mô hình cho bảng
                    const files = []
                    let info = ""
                    lines.forEach(l => {
                        const p = l.split("\t")
                        if (p[0] === "TOTAL" && p.length === 3) info = (parseInt(p[1]) / 1024).toFixed(1) + "K / " + Math.round(parseInt(p[2]) / 1024) + "K"
                        else if (p.length === 2 && /^\d+$/.test(p[1])) files.push({ name: p[0], size: parseInt(p[1]) })
                    })
                    root.buddyFiles = files
                    root.buddyFsInfo = info
                    root.buddyOk = true
                    root.buddyStatus = files.length + " file" + (info !== "" ? " · đã dùng " + info : "")
                } else {
                    if (!(silent && code === 3)) root.buddyOk = (code === 0)
                    const text0 = msg !== "" ? msg : (code === 0 ? "Xong" : "Lỗi: không chạy được buddy.py (cần python3)")
                    if (!(silent && code === 0)) root.buddyStatus = text0
                    if (!silent)
                        root.notifyIsland(code === 0 ? "📟" : "⚠", (msg.split("\n")[0] || "ESP32").slice(0, 42), -1,
                                          code === 0 ? "#a6e3a1" : "#f38ba8")
                }
                // Sau khi gửi/xoá file thì làm mới danh sách
                if (code === 0 && (cur[0] === "put" || cur[0] === "puttext" || cur[0] === "rm"))
                    root.buddyQueue = root.buddyQueue.concat([{ args: ["ls"], silent: true }])
                buddyNext.start()      // chờ tiến trình thoát hẳn rồi mới chạy lệnh kế
            }
        }
    }

    Timer {
        id: buddyNext
        interval: 120
        onTriggered: {
            root.buddyBusy = false
            if (root.buddyQueue.length > 0) {
                const q = root.buddyQueue.slice()
                const next = q.shift()
                root.buddyQueue = q
                root.buddyRun(next.args, next.silent)
            }
        }
    }

    // Tự đồng bộ: giờ, CPU/RAM, Pomodoro, việc cần làm
    Timer {
        interval: 15000
        running: root.buddyAuto
        repeat: true
        triggeredOnStart: true
        onTriggered: if (!root.buddyBusy) root.buddyRun(root.buddySyncArgs(), true)
    }

    IpcHandler {
        target: "buddy"
        function toggle(): void { root.buddyOpen = !root.buddyOpen }
        function note(text: string): void { root.buddyRun(["note", text]) }
        function msg(text: string): void { root.buddyRun(["msg", text]) }
        function wall(): void { root.buddyRun(["wall", root.wallpaper]) }                 // gửi hình nền hiện tại
        function time(): void { root.buddyRun(["time"]) }
        function put(path: string): void { root.buddyRun(["put", path]) }                // gửi file .txt
        function open(name: string): void { root.buddyRun(["open", name]) }              // mở file trên màn OLED
        function alarm(hhmm: string): void { root.buddyRun(["alarm", hhmm]) }            // "06:30" hoặc "off"
        function timer(minutes: string, label: string): void { root.buddyRun(["timer", minutes, label]) }
        function sync(): void { root.buddyRun(root.buddySyncArgs()) }
        function autosync(on: bool): void { root.buddySetAuto(on) }
    }

    IpcHandler {
        target: "focus"
        function toggle(): void { root.manualDnd = !root.manualDnd }
        function pomodoro(): void { root.pomoToggle() }
    }

    IpcHandler {
        target: "memory"
        function toggle(): void { root.memoryOpen = !root.memoryOpen }
    }

    IpcHandler {
        target: "connect"
        function wifi(): void { root.openConnect(0) }
        function bluetooth(): void { root.openConnect(1) }
    }

    IpcHandler {
        target: "power"
        function toggle(): void { root.powerOpen = !root.powerOpen }
    }

    IpcHandler {
        target: "wallpaper"
        function toggle(): void { root.togglePicker() }
        function next(): void { root.nextWallpaper(1) }
        function prev(): void { root.nextWallpaper(-1) }
    }

    IpcHandler {
        target: "workspace"
        function next(): void { root.cycleWs(1) }
        function prev(): void { root.cycleWs(-1) }
    }

    IpcHandler {
        target: "audio"
        function up(): void { root.changeVolume(0.05) }
        function down(): void { root.changeVolume(-0.05) }
        function mute(): void { root.toggleMute() }
    }

    IpcHandler {
        target: "brightness"
        function up(): void { root.changeBrightness(5) }
        function down(): void { root.changeBrightness(-5) }
    }

    // Bật/tắt bảng ứng dụng từ phím tắt:  qs -c study ipc call launcher toggle
    IpcHandler {
        target: "launcher"
        function toggle(): void { root.launcherOpen = !root.launcherOpen }
        function open(): void { root.launcherOpen = true }
        function close(): void { root.launcherOpen = false }
    }

    // ---- Mỗi màn hình: nền + bar ----
    Variants {
        model: Quickshell.screens
        Wallpaper { shell: root }
    }

    Variants {
        model: Quickshell.screens
        Bar { shell: root }
    }

    // ---- Bảng ứng dụng (một cửa sổ, trên màn hình chính) ----
    Launcher { shell: root }

    // ---- Menu nguồn ----
    PowerMenu { shell: root }

    // ---- Wi-Fi & Bluetooth ----
    ConnectPanel { shell: root }

    // ---- Ảnh kỷ niệm ----
    MemoryGallery { shell: root }

    // ---- Việc cần làm ----
    TodoPanel { shell: root }

    // ---- Gửi chữ / hình sang màn OLED ESP32 ----
    BuddyPanel { shell: root; model: walls }

    // ---- Dynamic Island (giữa trên cùng) ----
    Variants {
        model: Quickshell.screens
        Island { shell: root }
    }

    // ---- Widget mục tiêu (góc trên phải) ----
    Variants {
        model: Quickshell.screens
        GoalWidget { shell: root }
    }

    // ---- Ô chọn hình nền ----
    WallpaperPicker { shell: root; model: walls }
}
