import Quickshell
import Quickshell.Hyprland
import Quickshell.Services.Pipewire
import Quickshell.Services.UPower
import QtQuick
import QtQuick.Layouts

// Bar nổi, chia thành các "viên thuốc" (pill)
PanelWindow {
    id: bar
    required property var modelData
    property var shell

    // Màu (Catppuccin Mocha)
    readonly property color base: "#1e1e2e"
    readonly property color pill: "#ee1e1e2e"
    readonly property color fg: "#cdd6f4"
    readonly property color dim: "#7f849c"
    readonly property color accent: "#89b4fa"
    readonly property color green: "#a6e3a1"
    readonly property color red: "#f38ba8"
    readonly property color mauve: "#cba6f7"
    readonly property color orange: "#fab387"

    screen: modelData
    anchors { top: true; left: true; right: true }
    margins { top: 6; left: 8; right: 8 }
    implicitHeight: 34
    color: "transparent"

    readonly property var sink: shell ? shell.sink : null

    SystemClock { id: clock; precision: SystemClock.Minutes }

    // Workspace có cửa sổ hay không
    function hasWindows(n) {
        const v = Hyprland.workspaces.values
        for (let i = 0; i < v.length; i++) if (v[i].id === n) return true
        return false
    }

    // ================= TRÁI: Ứng dụng + 3 workspace =================
    Row {
        anchors { left: parent.left; verticalCenter: parent.verticalCenter }
        spacing: 8

        // Nút mở bảng ứng dụng
        Rectangle {
            height: 32
            width: 32                       // nút tròn gọn, chỉ có biểu tượng
            radius: 16
            color: bar.shell.launcherOpen ? Qt.lighter(bar.accent, 1.2) : bar.accent

            Row {
                id: appRow
                anchors.centerIn: parent
                spacing: 7
                Text { text: "▦"; color: bar.base; font.pixelSize: 15; anchors.verticalCenter: parent.verticalCenter }
            }
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: bar.shell.launcherOpen = !bar.shell.launcherOpen
            }
        }

        // 3 ô workspace
        Rectangle {
            height: 32
            width: wsRow.implicitWidth + 16
            radius: 16
            color: bar.pill

            // Lăn chuột trên cụm workspace để đổi qua lại
            WheelHandler {
                onWheel: e => bar.shell.cycleWs(e.angleDelta.y < 0 ? 1 : -1)
            }

            Row {
                id: wsRow
                anchors.centerIn: parent
                spacing: 6

                Repeater {
                    model: [1, 2, 3]
                    delegate: Rectangle {
                        id: ws
                        required property var modelData
                        readonly property bool focused: Hyprland.focusedWorkspace !== null
                                                        && Hyprland.focusedWorkspace.id === modelData
                        readonly property bool occupied: bar.hasWindows(modelData)

                        width: focused ? 38 : 26
                        height: 22
                        radius: 11
                        color: focused ? bar.accent : (occupied ? "#45475a" : "transparent")
                        Behavior on width { NumberAnimation { duration: 120 } }

                        Text {
                            anchors.centerIn: parent
                            text: ws.modelData
                            font.pixelSize: 13
                            font.bold: ws.focused
                            color: ws.focused ? bar.base : (ws.occupied ? bar.fg : bar.dim)
                        }
                        MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: bar.shell.gotoWs(ws.modelData)
                        }
                    }
                }
            }
        }
    }

    // ================= GIỮA: đồng hồ =================
    Rectangle {
        visible: false          // đồng hồ giờ nằm trong Dynamic Island (Island.qml)
        anchors.centerIn: parent
        height: 32
        width: clockRow.implicitWidth + 28
        radius: 16
        color: bar.pill

        Row {
            id: clockRow
            anchors.centerIn: parent
            spacing: 8
            Text {
                text: Qt.formatDateTime(clock.date, "HH:mm")
                color: bar.fg; font.pixelSize: 14; font.bold: true
                anchors.verticalCenter: parent.verticalCenter
            }
            Text {
                text: Qt.formatDateTime(clock.date, "ddd dd/MM")
                color: bar.dim; font.pixelSize: 12
                anchors.verticalCenter: parent.verticalCenter
            }
        }
    }

    // ================= PHẢI: Pomodoro + hệ thống =================
    Row {
        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
        spacing: 8

        // Nút nguồn: mở menu Ngủ / Đăng xuất / Khởi động lại / Tắt máy
        Rectangle {
            height: 32
            width: 32
            radius: 16
            color: bar.shell.powerOpen ? bar.red : bar.pill
            Text {
                anchors.centerIn: parent
                text: "⏻"
                font.pixelSize: 16
                color: bar.shell.powerOpen ? bar.base : bar.red
            }
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.PointingHandCursor
                onClicked: bar.shell.powerOpen = !bar.shell.powerOpen
            }
        }

        Rectangle {
            height: 32
            width: pomo.implicitWidth + 12
            radius: 16
            color: bar.pill
            Pomodoro { id: pomo; shell: bar.shell; anchors.centerIn: parent }
        }

        Rectangle {
            height: 32
            width: sysRow.implicitWidth + 24
            radius: 16
            color: bar.pill

            Row {
                id: sysRow
                anchors.centerIn: parent
                spacing: 12

                // CPU / RAM
                Text {
                    text: "CPU " + bar.shell.sysCpu + "%  RAM " + bar.shell.sysMem + "%"
                    color: (bar.shell.sysCpu > 85 || bar.shell.sysMem > 90) ? bar.red : bar.dim
                    font.pixelSize: 11
                    anchors.verticalCenter: parent.verticalCenter
                }

                // Việc cần làm
                Text {
                    text: "📝"
                    color: bar.fg
                    font.pixelSize: 14
                    anchors.verticalCenter: parent.verticalCenter
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: bar.shell.todoOpen = !bar.shell.todoOpen
                    }
                }

                // ESP32 Buddy (màn OLED): trái = mở bảng gửi chữ/hình, phải = gửi hình nền hiện tại sang OLED
                // Màu: tím khi đang gửi, đỏ nếu lần gửi gần nhất bị lỗi
                Text {
                    text: "📟"
                    color: bar.shell.buddyBusy ? bar.accent : (bar.shell.buddyOk ? bar.fg : bar.red)
                    font.pixelSize: 14
                    anchors.verticalCenter: parent.verticalCenter
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                        onClicked: m => m.button === Qt.RightButton ? bar.shell.buddyRun(["wall", bar.shell.wallpaper])
                                                                    : bar.shell.buddyOpen = !bar.shell.buddyOpen
                    }
                }

                // Chế độ tập trung (tắt thông báo): 🔕 khi đang bật, tự bật trong phiên Pomodoro
                Text {
                    text: bar.shell.dnd ? "🔕" : "🔔"
                    color: bar.shell.dnd ? bar.accent : bar.fg
                    font.pixelSize: 14
                    anchors.verticalCenter: parent.verticalCenter
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: bar.shell.manualDnd = !bar.shell.manualDnd
                    }
                }

                // Ảnh kỷ niệm
                Text {
                    text: "💖"
                    color: bar.fg
                    font.pixelSize: 14
                    anchors.verticalCenter: parent.verticalCenter
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: bar.shell.memoryOpen = !bar.shell.memoryOpen
                    }
                }

                // Wi-Fi và Bluetooth: bấm để mở bảng kết nối
                Text {
                    // Icon đổi theo tình trạng mạng: 📶 ổn, 🌐 cần đăng nhập, ⚠ không có Internet, 📵 chưa nối
                    text: bar.shell.netState === "portal" ? "🌐"
                          : (bar.shell.netState === "nonet" ? "⚠" : (bar.shell.netState === "offline" ? "📵" : "📶"))
                    color: (bar.shell.netState === "portal" || bar.shell.netState === "nonet") ? bar.orange
                           : (bar.shell.netState === "offline" ? bar.red : bar.fg)
                    font.pixelSize: 14
                    anchors.verticalCenter: parent.verticalCenter
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: bar.shell.openConnect(0)
                    }
                }
                Text {
                    text: "🔵"
                    color: bar.fg
                    font.pixelSize: 13
                    anchors.verticalCenter: parent.verticalCenter
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: bar.shell.openConnect(1)
                    }
                }

                // Chụp màn hình: trái = chọn vùng (lưu + copy), phải = toàn màn hình,
                // giữa = chọn vùng chỉ copy nhanh
                Text {
                    text: "📷"
                    color: bar.accent
                    font.pixelSize: 14
                    anchors.verticalCenter: parent.verticalCenter
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
                        onClicked: m => bar.shell.shot(m.button === Qt.RightButton ? "full"
                                                       : (m.button === Qt.MiddleButton ? "copy" : "region"))
                    }
                }

                // Hình nền: trái = mở ô chọn nền, phải = đổi nhanh sang ảnh kế
                Text {
                    text: "🖼"
                    color: bar.mauve
                    font.pixelSize: 14
                    anchors.verticalCenter: parent.verticalCenter
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.LeftButton | Qt.RightButton
                        onClicked: m => m.button === Qt.RightButton ? bar.shell.nextWallpaper(1)
                                                                    : bar.shell.togglePicker()
                    }
                }

                // Âm lượng: click = tắt tiếng, cuộn = chỉnh
                Text {
                    color: !bar.sink ? bar.fg : (bar.sink.audio.muted ? bar.dim
                           : (bar.sink.audio.volume > 1.0 ? bar.red : bar.fg))   // đỏ khi vượt 100%
                    font.pixelSize: 13
                    anchors.verticalCenter: parent.verticalCenter
                    text: !bar.sink ? "" : (bar.sink.audio.muted ? "🔇 --"
                          : "🔊 " + Math.round(bar.sink.audio.volume * 100) + "%")
                    MouseArea {
                        anchors.fill: parent
                        onClicked: bar.shell.toggleMute()
                        onWheel: w => bar.shell.changeVolume(w.angleDelta.y > 0 ? 0.05 : -0.05)   // tối đa 200%
                    }
                }

                // Độ sáng: cuộn để chỉnh (chỉ hiện nếu máy có đèn nền)
                Text {
                    visible: bar.shell.brightness >= 0
                    color: bar.fg
                    font.pixelSize: 13
                    anchors.verticalCenter: parent.verticalCenter
                    text: "🔆 " + bar.shell.brightness + "%"
                    MouseArea {
                        anchors.fill: parent
                        onWheel: w => bar.shell.changeBrightness(w.angleDelta.y > 0 ? 5 : -5)
                    }
                }

                // Pin (chỉ hiện nếu có pin)
                Text {
                    visible: UPower.displayDevice.ready && UPower.displayDevice.isLaptopBattery
                    font.pixelSize: 13
                    anchors.verticalCenter: parent.verticalCenter
                    color: UPower.displayDevice.state === UPowerDeviceState.Charging ? bar.green
                           : (UPower.displayDevice.percentage < 0.2 ? bar.red : bar.fg)
                    text: (UPower.displayDevice.state === UPowerDeviceState.Charging ? "⚡ " : "🔋 ")
                          + Math.round(UPower.displayDevice.percentage * 100) + "%"
                }
            }
        }
    }
}
